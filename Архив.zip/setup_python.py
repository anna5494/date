#!/usr/bin/env python3
"""
Скрипт установки для English Teacher Telegram Bot (Python версия)
"""

import os
import sys
import subprocess
import platform
from pathlib import Path


def run_command(command, check=True):
    """Выполняет команду в терминале"""
    print(f"🔧 Выполняю: {command}")
    try:
        result = subprocess.run(command, shell=True, check=check, capture_output=True, text=True)
        if result.stdout:
            print(result.stdout)
        return result.returncode == 0
    except subprocess.CalledProcessError as e:
        print(f"❌ Ошибка: {e}")
        if e.stderr:
            print(e.stderr)
        return False


def check_python_version():
    """Проверяет версию Python"""
    version = sys.version_info
    if version.major != 3 or version.minor < 8:
        print(f"❌ Требуется Python 3.8+, у вас {version.major}.{version.minor}")
        print("💡 Установите Python 3.8+ с https://python.org/")
        return False
    
    print(f"✅ Python {version.major}.{version.minor}.{version.micro} найден")
    return True


def check_pip():
    """Проверяет наличие pip"""
    if run_command("pip --version", check=False):
        print("✅ pip найден")
        return True
    else:
        print("❌ pip не найден")
        print("💡 Установите pip: python -m ensurepip --upgrade")
        return False


def create_venv():
    """Создает виртуальное окружение"""
    venv_path = Path("venv")
    
    if venv_path.exists():
        print("✅ Виртуальное окружение уже существует")
        return True
    
    print("🔧 Создаю виртуальное окружение...")
    if run_command("python -m venv venv"):
        print("✅ Виртуальное окружение создано")
        return True
    else:
        print("❌ Не удалось создать виртуальное окружение")
        return False


def get_activation_command():
    """Возвращает команду активации виртуального окружения"""
    if platform.system() == "Windows":
        return "venv\\Scripts\\activate"
    else:
        return "source venv/bin/activate"


def install_dependencies():
    """Устанавливает зависимости"""
    print("📦 Устанавливаю зависимости...")
    
    # Определяем команду pip в виртуальном окружении
    if platform.system() == "Windows":
        pip_cmd = "venv\\Scripts\\pip"
    else:
        pip_cmd = "venv/bin/pip"
    
    # Обновляем pip
    if not run_command(f"{pip_cmd} install --upgrade pip"):
        print("⚠️ Не удалось обновить pip")
    
    # Устанавливаем зависимости
    if run_command(f"{pip_cmd} install -r requirements.txt"):
        print("✅ Зависимости установлены")
        return True
    else:
        print("❌ Не удалось установить зависимости")
        return False


def setup_env_file():
    """Настраивает файл окружения"""
    env_file = Path(".env")
    env_example = Path(".env.example.py")
    
    if env_file.exists():
        print("✅ Файл .env уже существует")
        return True
    
    if env_example.exists():
        print("⚙️ Создаю файл .env...")
        try:
            env_example.rename(".env")
            print("✅ Файл .env создан из шаблона")
            print("💡 Отредактируйте .env файл и добавьте ваши API ключи:")
            print("   - TELEGRAM_BOT_TOKEN (получите от @BotFather)")
            print("   - OPENAI_API_KEY (получите от OpenAI)")
            return True
        except Exception as e:
            print(f"❌ Ошибка создания .env файла: {e}")
            return False
    else:
        print("⚠️ Файл .env.example.py не найден")
        return False


def create_directories():
    """Создает необходимые директории"""
    dirs = ["data", "logs"]
    
    for dir_name in dirs:
        dir_path = Path(dir_name)
        if not dir_path.exists():
            dir_path.mkdir(parents=True)
            print(f"✅ Создана директория {dir_name}/")
        else:
            print(f"✅ Директория {dir_name}/ уже существует")
    
    return True


def print_next_steps():
    """Выводит следующие шаги"""
    activation_cmd = get_activation_command()
    
    print("\n" + "="*60)
    print("🎉 Установка завершена успешно!")
    print("="*60)
    print("\nСледующие шаги:")
    print("1. Активируйте виртуальное окружение:")
    print(f"   {activation_cmd}")
    print("\n2. Отредактируйте файл .env и добавьте ваши API ключи")
    print("\n3. Запустите бота:")
    print("   python main.py")
    print("\n💡 Нужна помощь? Посмотрите README.md")
    print("\n🔗 Полезные ссылки:")
    print("   • Создать Telegram бота: https://t.me/BotFather")
    print("   • Получить OpenAI API ключ: https://platform.openai.com/api-keys")


def main():
    """Основная функция установки"""
    print("🤖 Установка English Teacher Telegram Bot (Python версия)")
    print("=" * 60)
    
    # Проверки системы
    if not check_python_version():
        sys.exit(1)
    
    if not check_pip():
        sys.exit(1)
    
    # Создание виртуального окружения
    if not create_venv():
        sys.exit(1)
    
    # Установка зависимостей
    if not install_dependencies():
        sys.exit(1)
    
    # Настройка окружения
    if not setup_env_file():
        print("⚠️ Не удалось настроить файл окружения")
    
    # Создание директорий
    create_directories()
    
    # Вывод следующих шагов
    print_next_steps()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n❌ Установка прервана пользователем")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ Критическая ошибка: {e}")
        sys.exit(1)