#!/usr/bin/env python3
"""
Simple isolated test for OpenAI import issue
"""

import sys
from pathlib import Path

# Add project path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

def test_openai_import():
    """Test OpenAI import specifically"""
    try:
        import openai
        print("✅ OpenAI imported successfully")
        
        # Test client creation
        client = openai.OpenAI(api_key="test_key")
        print("✅ OpenAI client created successfully")
        
        return True
    except Exception as e:
        print(f"❌ OpenAI error: {e}")
        return False

def test_gpt_service_import():
    """Test GPT service import"""
    try:
        # First test config
        from bot.config.settings import config
        print("✅ Config imported")
        
        # Then test GPT service
        from bot.services.gpt_service import gpt_service
        print("✅ GPT service imported successfully")
        
        return True
    except Exception as e:
        print(f"❌ GPT service error: {e}")
        return False

if __name__ == "__main__":
    print("🧪 Isolated OpenAI Test")
    print("=" * 30)
    
    tests = [
        ("OpenAI Import", test_openai_import),
        ("GPT Service Import", test_gpt_service_import),
    ]
    
    for test_name, test_func in tests:
        print(f"\n🔍 {test_name}:")
        test_func()