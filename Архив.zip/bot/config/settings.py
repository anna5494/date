"""
Конфигурация для English Teacher Telegram Bot
"""

import os
from typing import List, Optional
from dotenv import load_dotenv

# Загружаем переменные окружения
load_dotenv()


class Config:
    """Основной класс конфигурации"""
    
    # Telegram Bot настройки
    TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
    TELEGRAM_WEBHOOK_URL: Optional[str] = os.getenv("TELEGRAM_WEBHOOK_URL")
    BOT_USERNAME: Optional[str] = os.getenv("BOT_USERNAME")
    ADMIN_CHAT_ID: Optional[str] = os.getenv("ADMIN_CHAT_ID")
    
    # OpenAI настройки
    OPENAI_API_KEY: str = os.getenv("OPENAI_API_KEY", "")
    OPENAI_MODEL: str = os.getenv("OPENAI_MODEL", "gpt-3.5-turbo")
    OPENAI_MAX_TOKENS: int = int(os.getenv("OPENAI_MAX_TOKENS", "1500"))
    OPENAI_TEMPERATURE: float = float(os.getenv("OPENAI_TEMPERATURE", "0.7"))
    
    # Серверные настройки
    PORT: int = int(os.getenv("PORT", "8000"))
    DEBUG: bool = os.getenv("DEBUG", "True").lower() == "true"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    
    # База данных
    DATABASE_URL: str = os.getenv("DATABASE_URL", "./data/bot.db")
    
    # Языковые настройки
    DEFAULT_LANGUAGE: str = os.getenv("DEFAULT_LANGUAGE", "ru")
    SUPPORTED_LANGUAGES: List[str] = os.getenv("SUPPORTED_LANGUAGES", "ru,en").split(",")
    
    # Логирование
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE: str = os.getenv("LOG_FILE", "./logs/bot.log")
    
    # Лимиты приложения
    MAX_MESSAGE_LENGTH: int = int(os.getenv("MAX_MESSAGE_LENGTH", "4000"))
    MAX_LESSON_PLAN_LENGTH: int = int(os.getenv("MAX_LESSON_PLAN_LENGTH", "2000"))
    MAX_QUIZ_QUESTIONS: int = int(os.getenv("MAX_QUIZ_QUESTIONS", "20"))
    SESSION_TIMEOUT: int = int(os.getenv("SESSION_TIMEOUT", "3600"))
    
    # Функции бота
    FEATURES = {
        "max_translation_length": 500,
        "max_grammar_text_length": 2000,
        "default_quiz_count": 5,
        "max_vocabulary_words": 15,
    }
    
    # Лимиты запросов
    RATE_LIMITS = {
        "requests_per_minute": 20,
        "requests_per_hour": 100,
        "requests_per_day": 1000,
    }

    @classmethod
    def validate(cls) -> None:
        """Проверяет обязательные настройки"""
        required_settings = [
            ("TELEGRAM_BOT_TOKEN", cls.TELEGRAM_BOT_TOKEN),
            ("OPENAI_API_KEY", cls.OPENAI_API_KEY),
        ]
        
        missing = []
        for name, value in required_settings:
            if not value:
                missing.append(name)
        
        if missing:
            raise ValueError(f"Отсутствуют обязательные переменные окружения: {', '.join(missing)}")

    @classmethod
    def is_production(cls) -> bool:
        """Проверяет, запущен ли бот в продакшн режиме"""
        return cls.ENVIRONMENT.lower() == "production"
    
    @classmethod
    def is_development(cls) -> bool:
        """Проверяет, запущен ли бот в режиме разработки"""
        return cls.ENVIRONMENT.lower() == "development"


class Messages:
    """Сообщения бота на русском языке"""
    
    WELCOME = """🎉 Добро пожаловать в помощник учителя английского языка!

Я помогу вам:
📚 Создавать планы уроков
📝 Проверять грамматику
🧩 Генерировать викторины и упражнения
🔄 Переводить тексты
🔊 Объяснять произношение
📊 Отслеживать прогресс учеников

Используйте команды или просто пишите мне на русском языке!"""

    HELP = """❓ Доступные команды:

/lesson - 📚 Создать план урока
/grammar - 📝 Проверить грамматику
/quiz - 🧩 Создать викторину
/translate - 🔄 Перевести текст
/pronunciation - 🔊 Помощь с произношением
/progress - 📊 Посмотреть прогресс
/settings - ⚙️ Настройки

Также вы можете просто написать мне вопрос или текст для проверки!"""

    PROCESSING = "⏳ Обрабатываю ваш запрос..."
    ERROR = "❌ Произошла ошибка. Попробуйте еще раз."
    NOT_UNDERSTOOD = "🤔 Не понял ваш запрос. Используйте /help для списка команд."
    TEXT_TOO_LONG = "❌ Текст слишком длинный. Максимум {} символов."
    SESSION_EXPIRED = "❌ Сессия истекла. Начните заново."


# Глобальный экземпляр конфигурации
config = Config()

# Валидируем конфигурацию при импорте (только если есть токен)
if config.TELEGRAM_BOT_TOKEN:
    try:
        config.validate()
    except ValueError as e:
        print(f"⚠️  Ошибка конфигурации: {e}")
        print("💡 Проверьте файл .env и убедитесь, что все обязательные переменные установлены")