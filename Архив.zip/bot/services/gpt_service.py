"""
Сервис интеграции с OpenAI GPT для English Teacher Bot
"""

import openai
from typing import Dict, Any, Optional
from dataclasses import dataclass

from bot.config.settings import config
from bot.utils.logger import services_logger, log_gpt_request, log_error


@dataclass
class GPTResponse:
    """Ответ от GPT"""
    content: str
    tokens_used: Optional[int] = None
    model: Optional[str] = None


class GPTService:
    """Сервис для работы с OpenAI GPT"""
    
    def __init__(self):
        openai.api_key = config.OPENAI_API_KEY
        self.model = config.OPENAI_MODEL
        self.max_tokens = config.OPENAI_MAX_TOKENS
        self.temperature = config.OPENAI_TEMPERATURE
        
        self.system_prompts = {
            'general': """Ты - помощник учителя английского языка в России. Ты помогаешь создавать планы уроков, проверять грамматику, объяснять правила английского языка и создавать упражнения. Отвечай на русском языке, будь полезным и дружелюбным. Всегда предлагай практические решения для обучения английскому языку.""",
            
            'lesson_plan': """Ты - эксперт по планированию уроков английского языка. Создавай детальные, структурированные планы уроков для российских школьников. Учитывай возраст, уровень владения языком и цели обучения. Включай разминку, основную часть, практические упражнения и домашнее задание. Отвечай на русском языке.""",
            
            'grammar': """Ты - эксперт по английской грамматике. Проверяй тексты на ошибки, объясняй правила простым языком на русском языке. Предлагай исправления и альтернативные варианты. Будь терпеливым и объясняй сложные концепции простыми словами.""",
            
            'quiz': """Ты - создатель образовательных викторин и упражнений по английскому языку. Создавай интересные и полезные задания разного типа: выбор правильного ответа, заполнение пропусков, перевод, и т.д. Вопросы должны соответствовать уровню учащихся. Отвечай на русском языке.""",
            
            'translation': """Ты - эксперт по переводу между русским и английским языками. Предлагай точные переводы, объясняй культурные особенности и идиомы. Предлагай альтернативные варианты перевода если это уместно. Отвечай на русском языке.""",
            
            'pronunciation': """Ты - эксперт по английскому произношению. Объясняй произношение английских слов и фраз для русскоговорящих учеников. Используй транскрипцию IPA и предлагай мнемонические приемы для запоминания. Указывай на частые ошибки русскоговорящих. Отвечай на русском языке."""
        }
    
    async def _make_request(self, prompt: str, system_prompt_type: str = 'general', 
                          max_tokens: Optional[int] = None, user_id: Optional[int] = None) -> GPTResponse:
        """Выполняет запрос к GPT API"""
        try:
            system_prompt = self.system_prompts.get(system_prompt_type, self.system_prompts['general'])
            
            response = openai.ChatCompletion.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=max_tokens or self.max_tokens,
                temperature=self.temperature
            )
            
            content = response.choices[0].message.content.strip()
            tokens_used = response.usage.total_tokens if response.usage else None
            
            # Логируем запрос
            if user_id:
                log_gpt_request(user_id, system_prompt_type, tokens_used)
            
            return GPTResponse(
                content=content,
                tokens_used=tokens_used,
                model=self.model
            )
            
        except Exception as e:
            log_error(e, f"GPT запрос ({system_prompt_type})", user_id)
            raise Exception("Ошибка при обращении к AI сервису")
    
    async def process_general_query(self, user_message: str, user_id: int) -> str:
        """Обрабатывает общий запрос пользователя"""
        prompt = f"""Пользователь спрашивает: "{user_message}"
        
Ответь как помощник учителя английского языка. Если вопрос не связан с английским языком, вежливо направь разговор к образовательным темам."""
        
        response = await self._make_request(prompt, 'general', user_id=user_id)
        return response.content
    
    async def create_lesson_plan(self, requirements: Dict[str, Any], user_id: int) -> str:
        """Создает план урока"""
        topic = requirements.get('topic', 'Общая тема')
        level = requirements.get('level', 'B1')
        duration = requirements.get('duration', '45')
        students_age = requirements.get('students_age', '12-15 лет')
        goals = requirements.get('goals', 'Изучить новую тему')
        additional_info = requirements.get('additional_info', '')
        
        prompt = f"""Создай план урока английского языка со следующими параметрами:
- Тема: {topic}
- Уровень: {level}
- Продолжительность: {duration} минут
- Возраст учеников: {students_age}
- Цели урока: {goals}
{f'- Дополнительная информация: {additional_info}' if additional_info else ''}

Структура плана должна включать:
1. Цели и задачи урока
2. Разминка (Warm-up) - 5-10 минут
3. Введение новой темы (Presentation) - 15-20 минут
4. Практика (Practice) - 15-20 минут
5. Производство (Production) - 10-15 минут
6. Заключение и домашнее задание - 5 минут

Добавь конкретные упражнения и активности для каждого этапа."""
        
        response = await self._make_request(prompt, 'lesson_plan', max_tokens=1800, user_id=user_id)
        return response.content
    
    async def check_grammar(self, text: str, user_id: int) -> str:
        """Проверяет грамматику текста"""
        prompt = f"""Проверь следующий английский текст на грамматические ошибки:

"{text}"

Предоставь:
1. Исправленный текст
2. Объяснение каждой ошибки на русском языке
3. Правила грамматики, которые были нарушены
4. Советы для избежания подобных ошибок в будущем

Если ошибок нет, похвали и дай советы по улучшению стиля."""
        
        response = await self._make_request(prompt, 'grammar', max_tokens=1500, user_id=user_id)
        return response.content
    
    async def create_quiz(self, topic: str, level: str, num_questions: int, 
                         quiz_type: str, user_id: int) -> str:
        """Создает викторину"""
        prompt = f"""Создай викторину по английскому языку:
- Тема: {topic}
- Уровень: {level}
- Количество вопросов: {num_questions}
- Тип викторины: {quiz_type}

Типы вопросов могут включать:
- Множественный выбор
- Заполнение пропусков
- Перевод с русского на английский
- Исправление ошибок
- Сопоставление

Для каждого вопроса предоставь:
1. Сам вопрос
2. Варианты ответов (если применимо)
3. Правильный ответ
4. Краткое объяснение

Сделай викторину интересной и познавательной!"""
        
        response = await self._make_request(prompt, 'quiz', max_tokens=1800, user_id=user_id)
        return response.content
    
    async def translate_text(self, text: str, direction: str, user_id: int) -> str:
        """Переводит текст"""
        directions = {
            'ru-en': 'с русского на английский',
            'en-ru': 'с английского на русский'
        }
        
        direction_text = directions.get(direction, 'с русского на английский')
        
        prompt = f"""Переведи следующий текст {direction_text}:

"{text}"

Предоставь:
1. Основной перевод
2. Альтернативные варианты (если есть)
3. Объяснение сложных фраз или идиом
4. Культурные особенности (если применимо)
5. Грамматические заметки о переводе"""
        
        response = await self._make_request(prompt, 'translation', max_tokens=1200, user_id=user_id)
        return response.content
    
    async def explain_pronunciation(self, word: str, user_id: int) -> str:
        """Объясняет произношение слова"""
        prompt = f"""Объясни произношение английского слова или фразы: "{word}"

Предоставь:
1. Фонетическую транскрипцию (IPA)
2. Русскую транскрипцию (приблизительное произношение)
3. Разбивку по слогам
4. Советы для русскоговорящих учеников
5. Частые ошибки и как их избегать
6. Примеры предложений с этим словом
7. Мнемонические приемы для запоминания произношения"""
        
        response = await self._make_request(prompt, 'pronunciation', max_tokens=1000, user_id=user_id)
        return response.content
    
    async def generate_vocabulary_exercise(self, topic: str, level: str, 
                                         exercise_type: str, user_id: int) -> str:
        """Создает упражнение на словарный запас"""
        prompt = f"""Создай упражнение на изучение словарного запаса:
- Тема: {topic}
- Уровень: {level}
- Тип упражнения: {exercise_type}

Включи:
1. 10-15 новых слов с переводом
2. Упражнения на закрепление (сопоставление, заполнение пропусков, составление предложений)
3. Контекстные примеры использования
4. Проверочные вопросы

Сделай упражнение интерактивным и интересным!"""
        
        response = await self._make_request(prompt, 'quiz', max_tokens=1500, user_id=user_id)
        return response.content
    
    async def analyze_student_level(self, student_text: str, user_id: int) -> str:
        """Анализирует уровень владения языком"""
        prompt = f"""Проанализируй уровень владения английским языком ученика на основе его текста:

"{student_text}"

Определи:
1. Примерный уровень (A1-C2)
2. Сильные стороны
3. Слабые места
4. Рекомендации для улучшения
5. Подходящие темы для изучения
6. Предложения по методам обучения

Будь конструктивным и мотивирующим в оценке."""
        
        response = await self._make_request(prompt, 'general', max_tokens=1200, user_id=user_id)
        return response.content
    
    async def create_dialogue(self, topic: str, level: str, num_speakers: int, user_id: int) -> str:
        """Создает диалог"""
        prompt = f"""Создай диалог на английском языке:
- Тема: {topic}
- Уровень: {level}
- Количество собеседников: {num_speakers}

Диалог должен:
1. Быть естественным и реалистичным
2. Соответствовать заданному уровню сложности
3. Включать полезные фразы и выражения
4. Иметь четкую структуру (начало, развитие, завершение)

После диалога добавь:
- Словарь новых слов с переводом
- Полезные фразы из диалога
- Вопросы на понимание
- Задания для ролевой игры"""
        
        response = await self._make_request(prompt, 'lesson_plan', max_tokens=1500, user_id=user_id)
        return response.content


# Глобальный экземпляр сервиса
gpt_service = GPTService()