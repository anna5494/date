"""
Analytics service for English Teacher Bot
Handles user progress tracking, statistics, and reporting
"""

from typing import Dict, List, Any, Optional, Tuple
from datetime import datetime, timedelta
from dataclasses import dataclass

from bot.models.database import db_manager, activity_repo, user_repo, ActivityType
from bot.utils.logger import services_logger


@dataclass
class UserStats:
    """User statistics data structure"""
    total_activities: int
    activity_counts: Dict[str, int]
    daily_activities: List[Dict[str, Any]]
    recent_activities: List[Dict[str, Any]]
    user_level: str
    progress_percentage: int
    days_active: int
    streak_days: int


@dataclass
class GlobalStats:
    """Global bot statistics"""
    total_users: int
    active_users_week: int
    active_users_month: int
    total_activities: int
    popular_features: List[Tuple[str, int]]
    daily_activities: List[Dict[str, Any]]


class AnalyticsService:
    """Service for handling user analytics and progress tracking"""
    
    def __init__(self):
        self.activity_labels = {
            ActivityType.LESSON_PLAN: "📖 Планы уроков",
            ActivityType.GRAMMAR_CHECK: "📝 Проверки грамматики", 
            ActivityType.QUIZ: "🧩 Викторины",
            ActivityType.TRANSLATION: "🔄 Переводы",
            ActivityType.PRONUNCIATION: "🔊 Произношение",
            ActivityType.VOCABULARY: "📚 Словарь",
            ActivityType.DIALOGUE: "💬 Диалоги"
        }
        
        self.level_thresholds = {
            "Новичок": 0,
            "Начинающий": 5,
            "Опытный": 20,
            "Продвинутый": 50,
            "Эксперт": 100
        }
    
    def get_user_statistics(self, user_id: int) -> UserStats:
        """Get comprehensive user statistics"""
        try:
            # Get raw stats from database
            raw_stats = activity_repo.get_user_stats(user_id)
            
            activity_counts = raw_stats.get('activity_counts', {})
            daily_activity = raw_stats.get('daily_activity', [])
            recent_activities = raw_stats.get('recent_activities', [])
            
            total_activities = sum(activity_counts.values())
            days_active = len(daily_activity)
            
            # Calculate user level and progress
            user_level, progress_percentage = self._calculate_user_level(total_activities)
            
            # Calculate streak
            streak_days = self._calculate_streak(daily_activity)
            
            return UserStats(
                total_activities=total_activities,
                activity_counts=activity_counts,
                daily_activities=daily_activity,
                recent_activities=recent_activities,
                user_level=user_level,
                progress_percentage=progress_percentage,
                days_active=days_active,
                streak_days=streak_days
            )
            
        except Exception as e:
            services_logger.error(f"Error getting user statistics for {user_id}: {e}")
            # Return empty stats on error
            return UserStats(
                total_activities=0,
                activity_counts={},
                daily_activities=[],
                recent_activities=[],
                user_level="Новичок",
                progress_percentage=0,
                days_active=0,
                streak_days=0
            )
    
    def _calculate_user_level(self, total_activities: int) -> Tuple[str, int]:
        """Calculate user level and progress to next level"""
        current_level = "Новичок"
        
        for level, threshold in self.level_thresholds.items():
            if total_activities >= threshold:
                current_level = level
        
        # Calculate progress to next level
        level_names = list(self.level_thresholds.keys())
        current_index = level_names.index(current_level)
        
        if current_index < len(level_names) - 1:
            next_level = level_names[current_index + 1]
            next_threshold = self.level_thresholds[next_level]
            current_threshold = self.level_thresholds[current_level]
            
            progress = ((total_activities - current_threshold) / 
                       (next_threshold - current_threshold)) * 100
            progress_percentage = min(100, max(0, int(progress)))
        else:
            progress_percentage = 100
        
        return current_level, progress_percentage
    
    def _calculate_streak(self, daily_activity: List[Dict[str, Any]]) -> int:
        """Calculate consecutive days streak"""
        if not daily_activity:
            return 0
        
        # Sort activities by date (most recent first)
        sorted_activities = sorted(
            daily_activity, 
            key=lambda x: x['date'], 
            reverse=True
        )
        
        streak = 0
        current_date = datetime.now().date()
        
        for activity in sorted_activities:
            activity_date = datetime.strptime(activity['date'], '%Y-%m-%d').date()
            
            # Check if this date is consecutive
            expected_date = current_date - timedelta(days=streak)
            
            if activity_date == expected_date:
                streak += 1
            else:
                break
        
        return streak
    
    def generate_user_report(self, user_id: int) -> str:
        """Generate comprehensive user progress report"""
        try:
            stats = self.get_user_statistics(user_id)
            user_info = user_repo.find_or_create_user(type('User', (), {'id': user_id})())
            
            report = f"""📊 *Ваш прогресс в изучении английского*

👤 *Пользователь:* {user_info.first_name or 'Пользователь'}
🏆 *Уровень:* {stats.user_level}
📈 *Прогресс до следующего уровня:* {stats.progress_percentage}%
📅 *Активных дней:* {stats.days_active}
🔥 *Текущая серия:* {stats.streak_days} дней
🎯 *Всего активностей:* {stats.total_activities}

📚 *Статистика по активностям:*"""
            
            # Add activity breakdown
            for activity_type, count in stats.activity_counts.items():
                label = self.activity_labels.get(activity_type, activity_type)
                report += f"\n• {label}: {count}"
            
            # Add recent activities if available
            if stats.recent_activities:
                report += f"\n\n🕐 *Последние активности:*"
                for activity in stats.recent_activities[:5]:
                    date = datetime.fromisoformat(activity['created_at']).strftime('%d.%m')
                    label = self.activity_labels.get(activity['activity_type'], activity['activity_type'])
                    report += f"\n• {date} - {label}"
            
            # Add recommendations
            report += self._generate_recommendations(stats)
            
            return report
            
        except Exception as e:
            services_logger.error(f"Error generating user report for {user_id}: {e}")
            return "❌ Ошибка при создании отчета о прогрессе"
    
    def _generate_recommendations(self, stats: UserStats) -> str:
        """Generate personalized recommendations based on user stats"""
        recommendations = ["\n\n💡 *Рекомендации:*"]
        
        activity_counts = stats.activity_counts
        
        # Check for missing activities
        if activity_counts.get(ActivityType.LESSON_PLAN, 0) < 5:
            recommendations.append("• Создайте больше планов уроков для структурированного обучения")
        
        if activity_counts.get(ActivityType.GRAMMAR_CHECK, 0) < 10:
            recommendations.append("• Проверяйте грамматику чаще для улучшения письменной речи")
        
        if activity_counts.get(ActivityType.PRONUNCIATION, 0) < 5:
            recommendations.append("• Изучайте произношение для улучшения устной речи")
        
        if activity_counts.get(ActivityType.QUIZ, 0) < 3:
            recommendations.append("• Создавайте викторины для интерактивного обучения")
        
        # Check activity frequency
        if stats.days_active < 7:
            recommendations.append("• Занимайтесь регулярно для лучших результатов")
        
        if stats.streak_days == 0:
            recommendations.append("• Попробуйте заниматься каждый день для формирования привычки")
        elif stats.streak_days >= 7:
            recommendations.append("• Отличная серия! Продолжайте в том же духе! 🔥")
        
        # Level-specific recommendations
        if stats.user_level == "Новичок":
            recommendations.append("• Начните с проверки грамматики простых предложений")
        elif stats.user_level == "Продвинутый":
            recommendations.append("• Попробуйте создавать сложные планы уроков")
        
        return "\n".join(recommendations) if len(recommendations) > 1 else ""
    
    def get_global_statistics(self) -> GlobalStats:
        """Get global bot usage statistics"""
        try:
            with db_manager._get_connection() as conn:
                cursor = conn.cursor()
                
                # Total users
                cursor.execute("SELECT COUNT(*) FROM users")
                total_users = cursor.fetchone()[0]
                
                # Active users in last week
                cursor.execute("""
                    SELECT COUNT(DISTINCT user_id) 
                    FROM user_progress 
                    WHERE created_at >= date('now', '-7 days')
                """)
                active_users_week = cursor.fetchone()[0]
                
                # Active users in last month
                cursor.execute("""
                    SELECT COUNT(DISTINCT user_id) 
                    FROM user_progress 
                    WHERE created_at >= date('now', '-30 days')
                """)
                active_users_month = cursor.fetchone()[0]
                
                # Total activities
                cursor.execute("SELECT COUNT(*) FROM user_progress")
                total_activities = cursor.fetchone()[0]
                
                # Popular features
                cursor.execute("""
                    SELECT activity_type, COUNT(*) as count
                    FROM user_progress
                    GROUP BY activity_type
                    ORDER BY count DESC
                    LIMIT 5
                """)
                popular_features = [(row[0], row[1]) for row in cursor.fetchall()]
                
                # Daily activities (last 30 days)
                cursor.execute("""
                    SELECT DATE(created_at) as date, COUNT(*) as count
                    FROM user_progress
                    WHERE created_at >= date('now', '-30 days')
                    GROUP BY DATE(created_at)
                    ORDER BY date
                """)
                daily_activities = [
                    {'date': row[0], 'count': row[1]} 
                    for row in cursor.fetchall()
                ]
                
                return GlobalStats(
                    total_users=total_users,
                    active_users_week=active_users_week,
                    active_users_month=active_users_month,
                    total_activities=total_activities,
                    popular_features=popular_features,
                    daily_activities=daily_activities
                )
                
        except Exception as e:
            services_logger.error(f"Error getting global statistics: {e}")
            return GlobalStats(
                total_users=0,
                active_users_week=0,
                active_users_month=0,
                total_activities=0,
                popular_features=[],
                daily_activities=[]
            )
    
    def generate_teacher_analytics(self, user_id: int) -> str:
        """Generate analytics report specifically for teachers"""
        try:
            user_stats = self.get_user_statistics(user_id)
            global_stats = self.get_global_statistics()
            
            report = f"""👩‍🏫 *Аналитика для учителя*

📚 *Ваша активность:*
• Планов уроков создано: {user_stats.activity_counts.get(ActivityType.LESSON_PLAN, 0)}
• Текстов проверено: {user_stats.activity_counts.get(ActivityType.GRAMMAR_CHECK, 0)}
• Викторин создано: {user_stats.activity_counts.get(ActivityType.QUIZ, 0)}
• Переводов выполнено: {user_stats.activity_counts.get(ActivityType.TRANSLATION, 0)}

📈 *Продуктивность:*
• Активных дней: {user_stats.days_active}
• Текущая серия: {user_stats.streak_days} дней
• Среднее активностей в день: {user_stats.total_activities / max(user_stats.days_active, 1):.1f}

🏆 *Ваш уровень:* {user_stats.user_level}
📊 *Прогресс:* {user_stats.progress_percentage}%"""
            
            # Most used features
            if user_stats.activity_counts:
                sorted_activities = sorted(
                    user_stats.activity_counts.items(),
                    key=lambda x: x[1],
                    reverse=True
                )[:3]
                
                report += f"\n\n🎯 *Самые используемые функции:*"
                for i, (activity_type, count) in enumerate(sorted_activities, 1):
                    label = self.activity_labels.get(activity_type, activity_type)
                    report += f"\n{i}. {label}: {count}"
            
            # Global context
            report += f"\n\n🌍 *Общая статистика:*"
            report += f"\n• Всего пользователей: {global_stats.total_users}"
            report += f"\n• Активных за неделю: {global_stats.active_users_week}"
            report += f"\n• Активных за месяц: {global_stats.active_users_month}"
            
            # Teacher-specific recommendations
            report += self._generate_teacher_recommendations(user_stats)
            
            return report
            
        except Exception as e:
            services_logger.error(f"Error generating teacher analytics for {user_id}: {e}")
            return "❌ Ошибка при создании аналитики"
    
    def _generate_teacher_recommendations(self, stats: UserStats) -> str:
        """Generate recommendations specifically for teachers"""
        recommendations = ["\n\n💡 *Рекомендации для учителя:*"]
        
        activity_counts = stats.activity_counts
        lesson_plans = activity_counts.get(ActivityType.LESSON_PLAN, 0)
        quizzes = activity_counts.get(ActivityType.QUIZ, 0)
        
        if lesson_plans < 10:
            recommendations.append("• Попробуйте создать планы уроков для разных уровней")
        
        if quizzes < 5:
            recommendations.append("• Создавайте больше викторин для интерактивного обучения")
        
        if stats.days_active < 14:
            recommendations.append("• Используйте бота регулярно для максимальной эффективности")
        
        if stats.streak_days >= 7:
            recommendations.append("• Отличная регулярность! Ваши ученики это оценят")
        
        # Advanced features suggestions
        if stats.total_activities >= 20:
            recommendations.append("• Попробуйте создавать диалоги для развития речи учеников")
        
        return "\n".join(recommendations) if len(recommendations) > 1 else ""
    
    def track_feature_usage(self, user_id: int, feature: str, metadata: Dict[str, Any] = None):
        """Track feature usage for analytics"""
        try:
            activity_repo.track_activity(
                user_id=user_id,
                activity_type=feature,
                activity_data=metadata or {},
                score=None
            )
            services_logger.info(f"Tracked feature usage: {feature} for user {user_id}")
        except Exception as e:
            services_logger.error(f"Error tracking feature usage: {e}")


# Global analytics service instance
analytics_service = AnalyticsService()