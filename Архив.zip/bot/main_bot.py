"""
Основной класс English Teacher Telegram Bot
"""

import asyncio
from typing import Dict, Any, Optional
import signal
import sys

from telegram import Update, BotCommand
from telegram.ext import (
    Application, 
    CommandHandler, 
    MessageHandler, 
    CallbackQueryHandler,
    ConversationHandler,
    filters
)
from telegram.constants import ParseMode
from flask import Flask, request

from bot.config.settings import config, Messages
from bot.utils.logger import main_logger, log_startup, log_shutdown, log_user_action, log_error
from bot.models.database import user_repo, session_repo
from bot.handlers.command_handlers import setup_command_handlers
from bot.handlers.message_handlers import setup_message_handlers
from bot.handlers.callback_handlers import setup_callback_handlers


class EnglishTeacherBot:
    """Главный класс Telegram бота для учителей английского языка"""
    
    def __init__(self):
        self.application: Optional[Application] = None
        self.flask_app: Optional[Flask] = None
        self.is_running = False
        
        # Настройка обработчиков сигналов для graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
    
    def _signal_handler(self, signum, frame):
        """Обрабатывает сигналы остановки"""
        main_logger.info(f"Получен сигнал {signum}, останавливаем бота...")
        self.stop()
    
    async def initialize(self) -> 'EnglishTeacherBot':
        """Инициализирует бота"""
        try:
            log_startup()
            
            # Проверяем конфигурацию
            config.validate()
            
            # Создаем приложение
            self.application = (
                Application.builder()
                .token(config.TELEGRAM_BOT_TOKEN)
                .build()
            )
            
            # Настраиваем обработчики
            await self._setup_handlers()
            
            # Настраиваем команды бота
            await self._setup_bot_commands()
            
            # Настраиваем веб-сервер для вебхуков (если нужно)
            if config.is_production():
                self._setup_webhook_server()
            
            main_logger.info("Бот инициализирован успешно")
            return self
            
        except Exception as e:
            log_error(e, "инициализация бота")
            raise
    
    async def _setup_handlers(self):
        """Настраивает обработчики команд и сообщений"""
        main_logger.info("Настройка обработчиков...")
        
        # Обработчики команд
        setup_command_handlers(self.application)
        
        # Обработчики сообщений
        setup_message_handlers(self.application)
        
        # Обработчики callback кнопок
        setup_callback_handlers(self.application)
        
        main_logger.info("Обработчики настроены")
    
    async def _setup_bot_commands(self):
        """Устанавливает команды бота"""
        commands = [
            BotCommand("start", "🚀 Начать работу с ботом"),
            BotCommand("help", "❓ Получить помощь"),
            BotCommand("lesson", "📚 Создать план урока"),
            BotCommand("grammar", "📝 Проверить грамматику"),
            BotCommand("quiz", "🧩 Создать викторину"),
            BotCommand("translate", "🔄 Перевести текст"),
            BotCommand("pronunciation", "🔊 Помощь с произношением"),
            BotCommand("progress", "📊 Посмотреть прогресс"),
            BotCommand("settings", "⚙️ Настройки")
        ]
        
        await self.application.bot.set_my_commands(commands)
        main_logger.info("Команды бота установлены")
    
    def _setup_webhook_server(self):
        """Настраивает Flask сервер для вебхуков"""
        if not config.TELEGRAM_WEBHOOK_URL:
            main_logger.warning("TELEGRAM_WEBHOOK_URL не настроен для продакшн режима")
            return
        
        self.flask_app = Flask(__name__)
        
        @self.flask_app.route(f"/webhook/{config.TELEGRAM_BOT_TOKEN}", methods=['POST'])
        async def webhook():
            update = Update.de_json(request.get_json(), self.application.bot)
            await self.application.process_update(update)
            return 'ok'
        
        main_logger.info("Flask сервер для вебхуков настроен")
    
    async def start(self):
        """Запускает бота"""
        if self.is_running:
            main_logger.warning("Бот уже запущен")
            return
        
        try:
            if config.is_production() and config.TELEGRAM_WEBHOOK_URL:
                # Продакшн режим с вебхуками
                await self._start_webhook_mode()
            else:
                # Режим разработки с polling
                await self._start_polling_mode()
            
            self.is_running = True
            main_logger.info("English Teacher Bot запущен и готов помогать учителям! 🎓")
            
        except Exception as e:
            log_error(e, "запуск бота")
            raise
    
    async def _start_polling_mode(self):
        """Запускает бота в режиме polling (для разработки)"""
        main_logger.info("Запуск в режиме polling...")
        
        # Инициализируем приложение
        await self.application.initialize()
        await self.application.start()
        
        # Запускаем polling
        await self.application.updater.start_polling(
            allowed_updates=Update.ALL_TYPES,
            drop_pending_updates=True
        )
        
        main_logger.info(f"Polling запущен на порту {config.PORT}")
    
    async def _start_webhook_mode(self):
        """Запускает бота в режиме вебхуков (для продакшн)"""
        main_logger.info("Запуск в режиме вебхуков...")
        
        # Инициализируем приложение
        await self.application.initialize()
        await self.application.start()
        
        # Устанавливаем вебхук
        webhook_url = f"{config.TELEGRAM_WEBHOOK_URL}/webhook/{config.TELEGRAM_BOT_TOKEN}"
        await self.application.bot.set_webhook(url=webhook_url)
        
        # Запускаем Flask сервер
        if self.flask_app:
            self.flask_app.run(
                host='0.0.0.0',
                port=config.PORT,
                debug=config.DEBUG
            )
        
        main_logger.info(f"Webhook установлен: {webhook_url}")
    
    async def stop(self):
        """Останавливает бота"""
        if not self.is_running:
            return
        
        try:
            main_logger.info("Остановка бота...")
            
            if self.application:
                # Удаляем вебхук если был установлен
                if config.is_production():
                    await self.application.bot.delete_webhook()
                
                # Останавливаем polling если запущен
                if self.application.updater.running:
                    await self.application.updater.stop()
                
                # Останавливаем приложение
                await self.application.stop()
                await self.application.shutdown()
            
            self.is_running = False
            log_shutdown()
            
        except Exception as e:
            log_error(e, "остановка бота")
        finally:
            sys.exit(0)
    
    def get_application(self) -> Application:
        """Возвращает экземпляр Telegram Application"""
        return self.application


class BotContext:
    """Контекст для передачи данных между обработчиками"""
    
    def __init__(self, update: Update, context: Any):
        self.update = update
        self.context = context
        self.user = None
        self.session = None
        self._loaded = False
    
    async def load_user_data(self):
        """Загружает данные пользователя и сессию"""
        if self._loaded:
            return
        
        if self.update.effective_user:
            # Находим или создаем пользователя
            self.user = user_repo.find_or_create_user(self.update.effective_user)
            
            # Загружаем сессию
            self.session = session_repo.get_session(self.user.id)
            
            # Логируем активность
            if hasattr(self.update, 'message') and self.update.message:
                log_user_action(
                    self.user.id, 
                    "message", 
                    self.update.message.text[:50] if self.update.message.text else "media"
                )
            elif hasattr(self.update, 'callback_query') and self.update.callback_query:
                log_user_action(
                    self.user.id,
                    "callback",
                    self.update.callback_query.data
                )
        
        self._loaded = True
    
    async def set_session(self, session_data: Dict[str, Any], expires_in: int = None):
        """Устанавливает сессию пользователя"""
        if not self.user:
            await self.load_user_data()
        
        if self.user:
            session_repo.set_session(self.user.id, session_data, expires_in)
            self.session = session_data
    
    async def clear_session(self):
        """Очищает сессию пользователя"""
        if not self.user:
            await self.load_user_data()
        
        if self.user:
            session_repo.clear_session(self.user.id)
            self.session = None
    
    async def send_message(self, text: str, **kwargs):
        """Отправляет сообщение пользователю"""
        if len(text) > config.MAX_MESSAGE_LENGTH:
            # Разбиваем длинное сообщение
            chunks = [text[i:i+config.MAX_MESSAGE_LENGTH] 
                     for i in range(0, len(text), config.MAX_MESSAGE_LENGTH)]
            
            for i, chunk in enumerate(chunks):
                if i == len(chunks) - 1:  # Последний chunk
                    await self.update.effective_chat.send_message(
                        text=chunk,
                        parse_mode=ParseMode.MARKDOWN,
                        **kwargs
                    )
                else:
                    await self.update.effective_chat.send_message(
                        text=chunk,
                        parse_mode=ParseMode.MARKDOWN
                    )
        else:
            await self.update.effective_chat.send_message(
                text=text,
                parse_mode=ParseMode.MARKDOWN,
                **kwargs
            )
    
    async def edit_message(self, text: str, **kwargs):
        """Редактирует сообщение"""
        if hasattr(self.update, 'callback_query') and self.update.callback_query:
            await self.update.callback_query.edit_message_text(
                text=text,
                parse_mode=ParseMode.MARKDOWN,
                **kwargs
            )
    
    async def answer_callback_query(self, text: str = None):
        """Отвечает на callback query"""
        if hasattr(self.update, 'callback_query') and self.update.callback_query:
            await self.update.callback_query.answer(text=text)


async def create_bot() -> EnglishTeacherBot:
    """Создает и инициализирует бота"""
    bot = EnglishTeacherBot()
    await bot.initialize()
    return bot