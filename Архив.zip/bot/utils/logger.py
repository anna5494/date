"""
Модуль логирования для English Teacher Bot
"""

import logging
import logging.handlers
import os
from pathlib import Path
from typing import Optional

import colorlog

from bot.config.settings import config


class BotLogger:
    """Настроенный логгер для бота"""
    
    def __init__(self, name: str = "english_teacher_bot"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, config.LOG_LEVEL.upper(), logging.INFO))
        
        # Очищаем существующие обработчики
        self.logger.handlers.clear()
        
        # Настраиваем обработчики
        self._setup_console_handler()
        self._setup_file_handler()
    
    def _setup_console_handler(self):
        """Настраивает цветной вывод в консоль"""
        console_handler = colorlog.StreamHandler()
        console_handler.setLevel(logging.DEBUG if config.DEBUG else logging.INFO)
        
        # Цветной формат для консоли
        color_formatter = colorlog.ColoredFormatter(
            "%(log_color)s%(levelname)-8s%(reset)s %(blue)s%(asctime)s%(reset)s %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
            log_colors={
                'DEBUG': 'cyan',
                'INFO': 'green',
                'WARNING': 'yellow',
                'ERROR': 'red',
                'CRITICAL': 'red,bg_white',
            }
        )
        
        console_handler.setFormatter(color_formatter)
        self.logger.addHandler(console_handler)
    
    def _setup_file_handler(self):
        """Настраивает запись в файл с ротацией"""
        # Создаем директорию для логов
        log_file_path = Path(config.LOG_FILE)
        log_file_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Ротирующий файловый обработчик
        file_handler = logging.handlers.RotatingFileHandler(
            config.LOG_FILE,
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        file_handler.setLevel(logging.DEBUG)
        
        # Формат для файла
        file_formatter = logging.Formatter(
            "[%(asctime)s] [%(levelname)s] %(name)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S"
        )
        
        file_handler.setFormatter(file_formatter)
        self.logger.addHandler(file_handler)
    
    def get_logger(self) -> logging.Logger:
        """Возвращает настроенный логгер"""
        return self.logger


# Создаем глобальные экземпляры логгеров
main_logger = BotLogger("bot.main").get_logger()
handlers_logger = BotLogger("bot.handlers").get_logger()
services_logger = BotLogger("bot.services").get_logger()
models_logger = BotLogger("bot.models").get_logger()


def get_logger(name: str) -> logging.Logger:
    """
    Получить логгер с указанным именем
    
    Args:
        name: Имя логгера
        
    Returns:
        Настроенный логгер
    """
    return BotLogger(name).get_logger()


def log_user_action(user_id: int, action: str, details: Optional[str] = None):
    """
    Логирует действие пользователя
    
    Args:
        user_id: ID пользователя
        action: Выполненное действие
        details: Дополнительные детали
    """
    message = f"Пользователь {user_id} выполнил действие: {action}"
    if details:
        message += f" | Детали: {details}"
    
    handlers_logger.info(message)


def log_gpt_request(user_id: int, prompt_type: str, tokens_used: Optional[int] = None):
    """
    Логирует запрос к GPT
    
    Args:
        user_id: ID пользователя
        prompt_type: Тип промпта
        tokens_used: Количество использованных токенов
    """
    message = f"GPT запрос от пользователя {user_id}: {prompt_type}"
    if tokens_used:
        message += f" | Токенов: {tokens_used}"
    
    services_logger.info(message)


def log_error(error: Exception, context: str = "", user_id: Optional[int] = None):
    """
    Логирует ошибку с контекстом
    
    Args:
        error: Исключение
        context: Контекст ошибки
        user_id: ID пользователя (если применимо)
    """
    message = f"Ошибка"
    if user_id:
        message += f" для пользователя {user_id}"
    if context:
        message += f" в {context}"
    message += f": {str(error)}"
    
    main_logger.error(message, exc_info=True)


def log_startup():
    """Логирует запуск бота"""
    main_logger.info("=" * 50)
    main_logger.info("🤖 English Teacher Bot запускается...")
    main_logger.info(f"📍 Режим: {config.ENVIRONMENT}")
    main_logger.info(f"🔧 Debug: {config.DEBUG}")
    main_logger.info(f"📊 Уровень логирования: {config.LOG_LEVEL}")
    main_logger.info("=" * 50)


def log_shutdown():
    """Логирует остановку бота"""
    main_logger.info("=" * 50)
    main_logger.info("🛑 English Teacher Bot останавливается...")
    main_logger.info("=" * 50)