"""
Grammar checking handlers for English Teacher Bot
Provides comprehensive grammar checking with detailed explanations and rules
"""

import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass

from bot.main_bot import BotContext
from bot.services.gpt_service import gpt_service
from bot.services.analytics_service import analytics_service
from bot.models.database import ActivityType
from bot.utils.logger import handlers_logger
from bot.config.settings import config


@dataclass
class GrammarCheckResult:
    """Grammar check result structure"""
    original_text: str
    corrected_text: str
    explanation: str
    error_count: int
    difficulty_level: str
    suggestions: List[str]


class GrammarRulesDatabase:
    """Database of English grammar rules and explanations"""
    
    @staticmethod
    def get_tenses_explanation() -> str:
        return """⏰ *Времена в английском языке*

*Настоящее время:*
• Present Simple: I work (регулярные действия)
  - Формула: I/You/We/They + V1, He/She/It + V1+s
  - Пример: I work every day. She works at home.

• Present Continuous: I am working (происходит сейчас)
  - Формула: am/is/are + V-ing
  - Пример: I am working now. They are studying.

• Present Perfect: I have worked (результат в настоящем)
  - Формула: have/has + V3
  - Пример: I have finished my homework.

*Прошедшее время:*
• Past Simple: I worked (законченное действие)
  - Формула: V2 (правильные глаголы + ed)
  - Пример: I worked yesterday. He went to school.

• Past Continuous: I was working (процесс в прошлом)
  - Формула: was/were + V-ing
  - Пример: I was sleeping when you called.

• Past Perfect: I had worked (действие до другого в прошлом)
  - Формула: had + V3
  - Пример: I had finished before he arrived.

*Будущее время:*
• Future Simple: I will work
  - Формула: will + V1
  - Пример: I will call you tomorrow.

• Future Continuous: I will be working
  - Формула: will be + V-ing
  - Пример: I will be working at 5 PM.

• Future Perfect: I will have worked
  - Формула: will have + V3
  - Пример: I will have finished by tomorrow."""
    
    @staticmethod
    def get_articles_explanation() -> str:
        return """📄 *Артикли в английском языке*

*A/An (неопределенный артикль):*
• Используется с исчисляемыми существительными в единственном числе
• A - перед согласными звуками: a cat, a university
• An - перед гласными звуками: an apple, an hour

*Правила использования A/An:*
• Первое упоминание: I saw a dog
• Профессия: He is a teacher
• Восклицания: What a beautiful day!

*The (определенный артикль):*
• Конкретный предмет: The book on the table
• Уникальные предметы: The sun, the moon, the Earth
• Превосходная степень: The best student
• Музыкальные инструменты: play the piano
• Океаны, моря, реки: the Pacific Ocean

*Без артикля (нулевой артикль):*
• Множественное число: Cats are animals
• Неисчисляемые: Water is important
• Имена собственные: Moscow, John
• Названия языков: I speak English
• Виды спорта: I play football
• Приемы пищи: breakfast, lunch, dinner"""
    
    @staticmethod
    def get_prepositions_explanation() -> str:
        return """🔗 *Предлоги в английском языке*

*Предлоги времени:*
• At: точное время
  - at 5 o'clock, at night, at Christmas
• In: месяцы, годы, времена года
  - in January, in 2023, in winter, in the morning
• On: дни недели, даты
  - on Monday, on Christmas Day, on 15th May

*Предлоги места:*
• At: точка, адрес
  - at home, at school, at the station
• In: внутри, города, страны
  - in the room, in Moscow, in Russia
• On: поверхность, улицы
  - on the table, on the wall, on Main Street

*Предлоги направления:*
• To: направление к цели
  - go to school, come to me
• Into: движение внутрь
  - go into the room, jump into the water
• From: исходная точка
  - come from work, a letter from friend

*Другие важные предлоги:*
• With: с кем-то/чем-то
  - with friends, with a pen
• Without: без чего-то
  - without money, without help
• For: для, в течение
  - for you, for 3 hours
• Since: с какого-то времени
  - since 2020, since Monday"""
    
    @staticmethod
    def get_word_order_explanation() -> str:
        return """🔄 *Порядок слов в английском языке*

*Утвердительное предложение:*
Подлежащее + Сказуемое + Дополнение + Обстоятельство
- I read books at home
- She speaks English fluently

*Вопросительное предложение:*
Вспомогательный глагол + Подлежащее + Основной глагол + Остальное
- Do you read books?
- Where does she live?
- What are you doing?

*Отрицательное предложение:*
Подлежащее + Вспомогательный глагол + not + Основной глагол + Остальное
- I do not read books
- She doesn't speak English
- They aren't working

*Специальные вопросы:*
Вопросительное слово + Вспомогательный глагол + Подлежащее + Основной глагол
- What do you do?
- Where does he live?
- When did they arrive?

*Порядок определений:*
Мнение + Размер + Возраст + Форма + Цвет + Происхождение + Материал + Цель + Существительное
- A beautiful small old round red Chinese wooden dining table"""


class GrammarTextAnalyzer:
    """Analyzes English text for grammar patterns and issues"""
    
    @staticmethod
    def is_english_text(text: str) -> bool:
        """Check if text is primarily in English"""
        # Remove punctuation and numbers for analysis
        clean_text = re.sub(r'[^\w\s]', ' ', text)
        words = clean_text.split()
        
        if not words:
            return False
        
        # Check for Cyrillic characters
        cyrillic_pattern = r'[а-яё]'
        if re.search(cyrillic_pattern, text, re.IGNORECASE):
            return False
        
        # Check if majority of characters are Latin
        latin_chars = len(re.findall(r'[a-zA-Z]', text))
        total_chars = len(re.sub(r'\s', '', text))
        
        return latin_chars > total_chars * 0.7 if total_chars > 0 else False
    
    @staticmethod
    def estimate_difficulty(text: str) -> str:
        """Estimate text difficulty level"""
        words = text.split()
        word_count = len(words)
        
        # Count complex structures
        sentence_count = len(re.findall(r'[.!?]+', text))
        avg_words_per_sentence = word_count / max(sentence_count, 1)
        
        # Count complex words (3+ syllables approximately)
        complex_words = len([word for word in words if len(word) > 8])
        complex_ratio = complex_words / max(word_count, 1)
        
        # Estimate level
        if avg_words_per_sentence <= 8 and complex_ratio < 0.1:
            return "A1-A2 (Beginner)"
        elif avg_words_per_sentence <= 12 and complex_ratio < 0.2:
            return "B1 (Intermediate)"
        elif avg_words_per_sentence <= 16 and complex_ratio < 0.3:
            return "B2 (Upper-Intermediate)"
        else:
            return "C1-C2 (Advanced)"
    
    @staticmethod
    def get_suggestions_for_text(text: str) -> List[str]:
        """Generate improvement suggestions for the text"""
        suggestions = []
        
        words = text.split()
        sentences = re.split(r'[.!?]+', text)
        
        # Check sentence length
        if any(len(sentence.split()) > 20 for sentence in sentences):
            suggestions.append("Попробуйте разбить длинные предложения на более короткие")
        
        # Check for repeated words
        word_freq = {}
        for word in words:
            word_lower = word.lower()
            word_freq[word_lower] = word_freq.get(word_lower, 0) + 1
        
        repeated_words = [word for word, count in word_freq.items() if count > 3 and len(word) > 3]
        if repeated_words:
            suggestions.append(f"Используйте синонимы для часто повторяющихся слов: {', '.join(repeated_words[:3])}")
        
        # Check for passive voice overuse
        passive_indicators = ['was', 'were', 'been', 'being']
        passive_count = sum(1 for word in words if word.lower() in passive_indicators)
        if passive_count > len(words) * 0.15:
            suggestions.append("Попробуйте использовать больше активного залога")
        
        # Check punctuation
        if not re.search(r'[.!?]$', text.strip()):
            suggestions.append("Убедитесь, что предложения заканчиваются знаками препинания")
        
        return suggestions


class GrammarHandler:
    """Comprehensive grammar checking handler"""
    
    def __init__(self):
        self.rules_db = GrammarRulesDatabase()
        self.analyzer = GrammarTextAnalyzer()
        
        # Common grammar examples for testing
        self.example_texts = {
            "simple": [
                "I go to school yesterday",
                "She don't like coffee", 
                "They was happy"
            ],
            "intermediate": [
                "I have been living in Moscow since 5 years",
                "If I would have money, I will buy a car",
                "The book what I read was interesting"
            ],
            "advanced": [
                "Despite of being tired, he continued working",
                "I would rather you don't smoke here",
                "Neither of students have completed their homework"
            ]
        }
    
    async def check_grammar_text(self, bot_context: BotContext, text: str) -> bool:
        """Check grammar of provided text"""
        try:
            # Validate text
            validation_result = self._validate_text(text)
            if validation_result:
                await bot_context.send_message(validation_result)
                return False
            
            # Analyze text difficulty
            difficulty = self.analyzer.estimate_difficulty(text)
            
            await bot_context.send_message("⏳ Проверяю грамматику...")
            
            # Get grammar check from GPT
            grammar_result = await gpt_service.check_grammar(text, bot_context.user.id)
            
            # Get improvement suggestions
            suggestions = self.analyzer.get_suggestions_for_text(text)
            
            # Send formatted result
            await self._send_grammar_result(
                bot_context, 
                text, 
                grammar_result, 
                difficulty, 
                suggestions
            )
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.GRAMMAR_CHECK,
                {
                    "text_length": len(text),
                    "word_count": len(text.split()),
                    "difficulty": difficulty
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error checking grammar: {e}")
            await bot_context.send_message("❌ Ошибка при проверке грамматики. Попробуйте еще раз.")
            return False
    
    def _validate_text(self, text: str) -> Optional[str]:
        """Validate input text"""
        if len(text.strip()) < 3:
            return "❌ Текст слишком короткий. Пожалуйста, отправьте хотя бы несколько слов."
        
        if len(text) > 2000:
            return "❌ Текст слишком длинный. Максимум 2000 символов."
        
        if not self.analyzer.is_english_text(text):
            return ("🤔 Похоже, что текст не на английском языке. "
                   "Пожалуйста, отправьте английский текст для проверки.")
        
        return None
    
    async def _send_grammar_result(self, bot_context: BotContext, original_text: str, 
                                 result: str, difficulty: str, suggestions: List[str]):
        """Send formatted grammar check result"""
        # Create result message
        message = f"""📝 *Результат проверки грамматики*

📋 *Исходный текст:*
`{original_text}`

🎯 *Уровень сложности:* {difficulty}

{result}"""
        
        # Add suggestions if available
        if suggestions:
            message += f"\n\n💡 *Дополнительные советы:*\n"
            for suggestion in suggestions[:3]:  # Limit to 3 suggestions
                message += f"• {suggestion}\n"
        
        # Send main result
        await bot_context.send_message(message)
        
        # Send action buttons
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("📚 Изучить правила", callback_data="grammar_rules"),
                InlineKeyboardButton("📋 Примеры", callback_data="grammar_examples")
            ],
            [
                InlineKeyboardButton("🔄 Проверить еще", callback_data="grammar_new"),
                InlineKeyboardButton("📤 Поделиться", callback_data="grammar_share")
            ]
        ])
        
        await bot_context.send_message(
            "✨ Хотите проверить еще один текст или изучить правила грамматики?",
            reply_markup=keyboard
        )
    
    async def show_grammar_examples(self, bot_context: BotContext, level: str = "all"):
        """Show grammar examples for practice"""
        if level == "all" or level not in self.example_texts:
            examples_message = "📋 *Примеры текстов для проверки:*\n\n"
            
            for level_name, examples in self.example_texts.items():
                level_labels = {
                    "simple": "Простые предложения",
                    "intermediate": "Средний уровень", 
                    "advanced": "Продвинутый уровень"
                }
                
                examples_message += f"*{level_labels.get(level_name, level_name)}:*\n"
                for example in examples:
                    examples_message += f"• `{example}`\n"
                examples_message += "\n"
            
            examples_message += "Выберите любой пример или отправьте свой текст!"
        else:
            examples = self.example_texts.get(level, [])
            examples_message = f"📋 *Примеры для уровня {level}:*\n\n"
            for example in examples:
                examples_message += f"• `{example}`\n"
        
        await bot_context.send_message(examples_message)
    
    async def explain_grammar_rule(self, bot_context: BotContext, rule_type: str):
        """Explain specific grammar rule"""
        explanations = {
            "tenses": self.rules_db.get_tenses_explanation(),
            "articles": self.rules_db.get_articles_explanation(),
            "prepositions": self.rules_db.get_prepositions_explanation(),
            "word_order": self.rules_db.get_word_order_explanation()
        }
        
        explanation = explanations.get(rule_type)
        if not explanation:
            await bot_context.send_message("❌ Правило не найдено")
            return
        
        # Send explanation in chunks if too long
        if len(explanation) > config.MAX_MESSAGE_LENGTH:
            chunks = self._split_text(explanation)
            for chunk in chunks:
                await bot_context.send_message(chunk)
        else:
            await bot_context.send_message(explanation)
        
        # Add back button
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("⬅️ К правилам", callback_data="grammar_rules")]
        ])
        
        await bot_context.send_message("📚 Изучите другие правила:", reply_markup=keyboard)
    
    def _split_text(self, text: str) -> List[str]:
        """Split long text into manageable chunks"""
        max_length = config.MAX_MESSAGE_LENGTH - 100
        chunks = []
        current_chunk = ""
        
        lines = text.split('\n')
        for line in lines:
            if len(current_chunk + line + '\n') > max_length and current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = line + '\n'
            else:
                current_chunk += line + '\n'
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks


# Global grammar handler instance
grammar_handler = GrammarHandler()