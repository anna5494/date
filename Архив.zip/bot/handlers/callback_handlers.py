"""
Обработчики callback кнопок для English Teacher Bot
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, CallbackQueryHandler

from bot.main_bot import BotContext
from bot.utils.logger import handlers_logger


async def handle_callback_query(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Основной обработчик callback запросов"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    query = update.callback_query
    data = query.data
    
    await bot_context.answer_callback_query()
    
    try:
        if data.startswith("lesson_"):
            await handle_lesson_callback(bot_context, data)
        elif data.startswith("grammar_"):
            await handle_grammar_callback(bot_context, data)
        elif data.startswith("quiz_"):
            await handle_quiz_callback(bot_context, data)
        elif data.startswith("translate_") or data.startswith("pronunciation_"):
            await handle_translation_callback(bot_context, data)
        elif data.startswith("settings_"):
            await handle_settings_callback(bot_context, data)
        else:
            await bot_context.edit_message("❌ Неизвестная команда")
    
    except Exception as e:
        handlers_logger.error(f"Ошибка обработки callback: {e}")
        await bot_context.edit_message("❌ Произошла ошибка")


async def handle_lesson_callback(bot_context: BotContext, data: str):
    """Обрабатывает callback для планов уроков"""
    if data == "lesson_quick":
        message = """⚡ *Быстрый план урока*

Напишите тему урока и уровень учеников в формате:
`Тема: [ваша тема]
Уровень: [A1/A2/B1/B2/C1/C2]`

Например:
`Тема: Прошедшее время (Past Simple)
Уровень: A2`"""
        
        await bot_context.edit_message(message)
        await bot_context.set_session({
            "waiting_for": "lesson_quick_details",
            "flow": "lesson_plan"
        })
    
    elif data == "lesson_detailed":
        message = """🎯 *Детальный план урока*

Функция находится в разработке.
Пожалуйста, используйте быстрый план урока."""
        
        await bot_context.edit_message(message)
    
    elif data == "lesson_templates":
        keyboard = [
            [
                InlineKeyboardButton("📖 Грамматика", callback_data="template_grammar"),
                InlineKeyboardButton("💬 Разговор", callback_data="template_speaking")
            ],
            [
                InlineKeyboardButton("📚 Чтение", callback_data="template_reading"),
                InlineKeyboardButton("✍️ Письмо", callback_data="template_writing")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await bot_context.edit_message(
            "📋 *Шаблоны планов уроков*\n\nВыберите тип урока:",
            reply_markup=reply_markup
        )


async def handle_grammar_callback(bot_context: BotContext, data: str):
    """Обрабатывает callback для грамматики"""
    if data == "grammar_examples":
        message = """📋 *Примеры текстов для проверки:*

*Простые предложения:*
• `I go to school yesterday`
• `She don't like coffee`
• `They was happy`

*Средний уровень:*
• `I have been living in Moscow since 5 years`
• `If I would have money, I will buy a car`

Выберите любой пример или отправьте свой текст!"""
        
        await bot_context.edit_message(message)
    
    elif data == "grammar_rules":
        keyboard = [
            [
                InlineKeyboardButton("⏰ Времена", callback_data="rule_tenses"),
                InlineKeyboardButton("📄 Артикли", callback_data="rule_articles")
            ],
            [
                InlineKeyboardButton("🔗 Предлоги", callback_data="rule_prepositions"),
                InlineKeyboardButton("🔄 Порядок слов", callback_data="rule_word_order")
            ]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await bot_context.edit_message(
            "📚 *Основные правила английской грамматики*\n\nВыберите раздел:",
            reply_markup=reply_markup
        )


async def handle_quiz_callback(bot_context: BotContext, data: str):
    """Обрабатывает callback для викторин"""
    quiz_types = {
        "quiz_multiple_choice": "Множественный выбор",
        "quiz_fill_blanks": "Заполнение пропусков",
        "quiz_translation": "Перевод",
        "quiz_matching": "Сопоставление",
        "quiz_vocabulary": "Словарный запас"
    }
    
    if data == "quiz_quick":
        message = """⚡ *Быстрая викторина*

Просто назовите тему, и я создам викторину из 5 вопросов уровня B1:

*Примеры тем:*
• Irregular verbs
• Present Perfect
• Food and drinks

Напишите тему:"""
        
        await bot_context.edit_message(message)
        await bot_context.set_session({
            "waiting_for": "quiz_quick_topic",
            "flow": "quiz_creation"
        })
    
    elif data in quiz_types:
        message = f"""🧩 *Создание викторины: {quiz_types[data]}*

Функция находится в разработке.
Пожалуйста, используйте быструю викторину."""
        
        await bot_context.edit_message(message)


async def handle_translation_callback(bot_context: BotContext, data: str):
    """Обрабатывает callback для переводов"""
    if data == "translate_ru_en":
        message = """🔄 *Русский → Английский*

Введите русский текст для перевода на английский:

Пример: "Я изучаю английский язык"

💡 Советы:
• Отправляйте предложения или короткие тексты
• Я объясню сложные фразы и идиомы"""
        
        await bot_context.edit_message(message)
        await bot_context.set_session({
            "waiting_for": "translation_text",
            "flow": "translation",
            "direction": "ru-en"
        })
    
    elif data == "translate_en_ru":
        message = """🔄 *Английский → Русский*

Введите английский текст для перевода на русский:

Example: "I am learning English"

💡 Tips:
• Send sentences or short texts
• I'll explain complex phrases and idioms"""
        
        await bot_context.edit_message(message)
        await bot_context.set_session({
            "waiting_for": "translation_text",
            "flow": "translation",
            "direction": "en-ru"
        })
    
    elif data == "pronunciation_help":
        message = """🔊 *Помощь с произношением*

Отправьте английское слово или фразу, и я объясню:
• 📝 Фонетическую транскрипцию
• 🗣️ Как произносить по-русски
• 💡 Советы для запоминания

*Примеры:*
• `thought`
• `comfortable`
• `What time is it?`"""
        
        await bot_context.edit_message(message)
        await bot_context.set_session({
            "waiting_for": "pronunciation_text",
            "flow": "pronunciation"
        })


async def handle_settings_callback(bot_context: BotContext, data: str):
    """Обрабатывает callback для настроек"""
    if data == "settings_language":
        keyboard = [
            [InlineKeyboardButton("🇷🇺 Русский", callback_data="lang_ru")],
            [InlineKeyboardButton("🇺🇸 English", callback_data="lang_en")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await bot_context.edit_message(
            "🌍 Выберите язык интерфейса:",
            reply_markup=reply_markup
        )
    
    elif data == "settings_level":
        keyboard = [
            [InlineKeyboardButton("A1 Beginner", callback_data="level_a1")],
            [InlineKeyboardButton("A2 Elementary", callback_data="level_a2")],
            [InlineKeyboardButton("B1 Intermediate", callback_data="level_b1")],
            [InlineKeyboardButton("B2 Upper-Intermediate", callback_data="level_b2")],
            [InlineKeyboardButton("C1 Advanced", callback_data="level_c1")]
        ]
        reply_markup = InlineKeyboardMarkup(keyboard)
        
        await bot_context.edit_message(
            "🎯 Выберите уровень по умолчанию:",
            reply_markup=reply_markup
        )


def setup_callback_handlers(application):
    """Настраивает обработчики callback кнопок"""
    handlers_logger.info("Настройка обработчиков callback...")
    
    application.add_handler(CallbackQueryHandler(handle_callback_query))
    
    handlers_logger.info("Обработчики callback настроены")