"""
Translation and pronunciation handlers for English Teacher Bot
Provides comprehensive translation services and pronunciation assistance
"""

import re
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

from bot.main_bot import BotContext
from bot.services.gpt_service import gpt_service
from bot.services.analytics_service import analytics_service
from bot.models.database import ActivityType
from bot.utils.logger import handlers_logger
from bot.config.settings import config


class TranslationDirection(Enum):
    """Translation direction enumeration"""
    RU_TO_EN = "ru-en"
    EN_TO_RU = "en-ru"


@dataclass
class TranslationResult:
    """Translation result structure"""
    original_text: str
    translated_text: str
    direction: TranslationDirection
    alternatives: List[str]
    explanations: List[str]
    difficulty_level: str


@dataclass
class PronunciationResult:
    """Pronunciation result structure"""
    word: str
    ipa_transcription: str
    russian_transcription: str
    syllables: List[str]
    tips: List[str]
    common_mistakes: List[str]
    example_sentences: List[str]


class LanguageDetector:
    """Simple language detection for Russian and English"""
    
    @staticmethod
    def detect_language(text: str) -> str:
        """Detect if text is Russian or English"""
        # Remove punctuation and numbers
        clean_text = re.sub(r'[^\w\s]', '', text)
        
        # Count Cyrillic and Latin characters
        cyrillic_count = len(re.findall(r'[а-яё]', clean_text, re.IGNORECASE))
        latin_count = len(re.findall(r'[a-z]', clean_text, re.IGNORECASE))
        
        if cyrillic_count > latin_count:
            return "ru"
        elif latin_count > cyrillic_count:
            return "en"
        else:
            return "unknown"
    
    @staticmethod
    def is_english_word(word: str) -> bool:
        """Check if word is English"""
        # Basic check for English characters
        return bool(re.match(r'^[a-zA-Z\s\'-]+$', word.strip()))
    
    @staticmethod
    def is_russian_text(text: str) -> bool:
        """Check if text is Russian"""
        cyrillic_pattern = r'[а-яё]'
        return bool(re.search(cyrillic_pattern, text, re.IGNORECASE))


class UsefulPhrasesDatabase:
    """Database of useful phrases for English teachers"""
    
    @staticmethod
    def get_classroom_phrases() -> Dict[str, List[Tuple[str, str]]]:
        """Get categorized classroom phrases"""
        return {
            "starting_lesson": [
                ("Let's start the lesson", "Давайте начнем урок"),
                ("Good morning/afternoon, class", "Доброе утро/день, класс"),
                ("Please take your seats", "Пожалуйста, садитесь на свои места"),
                ("Open your books to page...", "Откройте учебники на странице..."),
                ("Today we're going to learn about...", "Сегодня мы изучаем...")
            ],
            "instructions": [
                ("Pay attention, please", "Обратите внимание, пожалуйста"),
                ("Listen carefully", "Слушайте внимательно"),
                ("Repeat after me", "Повторяйте за мной"),
                ("Work in pairs", "Работайте в парах"),
                ("Complete the exercise", "Выполните упражнение")
            ],
            "questions": [
                ("Any questions?", "Есть вопросы?"),
                ("Do you understand?", "Понятно?"),
                ("Can you repeat that?", "Можете повторить?"),
                ("What does this word mean?", "Что означает это слово?"),
                ("How do you say... in English?", "Как сказать... по-английски?")
            ],
            "encouragement": [
                ("Well done!", "Отлично!"),
                ("Good job!", "Хорошая работа!"),
                ("Excellent!", "Превосходно!"),
                ("Keep it up!", "Так держать!"),
                ("You're making progress", "Вы делаете успехи")
            ],
            "corrections": [
                ("Not quite", "Не совсем"),
                ("Try again", "Попробуйте еще раз"),
                ("Almost correct", "Почти правильно"),
                ("Let me help you", "Позвольте помочь"),
                ("The correct answer is...", "Правильный ответ...")
            ]
        }


class TranslationHandler:
    """Comprehensive translation handler"""
    
    def __init__(self):
        self.detector = LanguageDetector()
        self.phrases_db = UsefulPhrasesDatabase()
        self.max_translation_length = 500
    
    async def handle_translation_request(self, bot_context: BotContext, 
                                       text: str, direction: TranslationDirection) -> bool:
        """Handle translation request"""
        try:
            # Validate input
            validation_error = self._validate_translation_input(text, direction)
            if validation_error:
                await bot_context.send_message(validation_error)
                return False
            
            await bot_context.send_message("⏳ Перевожу текст...")
            
            # Get translation from GPT
            translation_result = await gpt_service.translate_text(
                text, 
                direction.value, 
                bot_context.user.id
            )
            
            # Send formatted result
            await self._send_translation_result(
                bot_context, 
                text, 
                translation_result, 
                direction
            )
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.TRANSLATION,
                {
                    "direction": direction.value,
                    "text_length": len(text),
                    "word_count": len(text.split())
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error handling translation: {e}")
            await bot_context.send_message("❌ Ошибка при переводе. Попробуйте еще раз.")
            return False
    
    async def auto_detect_and_translate(self, bot_context: BotContext, text: str) -> bool:
        """Auto-detect language and translate"""
        try:
            detected_lang = self.detector.detect_language(text)
            
            if detected_lang == "ru":
                direction = TranslationDirection.RU_TO_EN
            elif detected_lang == "en":
                direction = TranslationDirection.EN_TO_RU
            else:
                await bot_context.send_message(
                    "❓ Не удалось определить язык. Пожалуйста, выберите направление перевода."
                )
                return False
            
            return await self.handle_translation_request(bot_context, text, direction)
            
        except Exception as e:
            handlers_logger.error(f"Error in auto-detection: {e}")
            return False
    
    def _validate_translation_input(self, text: str, direction: TranslationDirection) -> Optional[str]:
        """Validate translation input"""
        if len(text.strip()) < 1:
            return "❌ Пожалуйста, введите текст для перевода."
        
        if len(text) > self.max_translation_length:
            return f"❌ Текст слишком длинный. Максимум {self.max_translation_length} символов."
        
        # Basic language validation
        if direction == TranslationDirection.RU_TO_EN:
            if not self.detector.is_russian_text(text):
                return "❌ Для перевода с русского введите текст на русском языке."
        elif direction == TranslationDirection.EN_TO_RU:
            if self.detector.is_russian_text(text):
                return "❌ Для перевода с английского введите текст на английском языке."
        
        return None
    
    async def _send_translation_result(self, bot_context: BotContext, 
                                     original_text: str, translation_result: str, 
                                     direction: TranslationDirection):
        """Send formatted translation result"""
        direction_emoji = {
            TranslationDirection.RU_TO_EN: "🇷🇺➡️🇺🇸",
            TranslationDirection.EN_TO_RU: "🇺🇸➡️🇷🇺"
        }
        
        message = f"""{direction_emoji[direction]} *Результат перевода*

📝 *Исходный текст:*
`{original_text}`

{translation_result}"""
        
        # Send result
        await bot_context.send_message(message)
        
        # Send action buttons
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔄 Перевести еще", callback_data="translate_new"),
                InlineKeyboardButton("🔊 Произношение", callback_data="pronunciation_help")
            ],
            [
                InlineKeyboardButton("📤 Поделиться", callback_data="translation_share"),
                InlineKeyboardButton("📚 Фразы", callback_data="useful_phrases")
            ]
        ])
        
        await bot_context.send_message(
            "✨ Хотите перевести еще текст или изучить произношение?",
            reply_markup=keyboard
        )
    
    async def show_useful_phrases(self, bot_context: BotContext, category: str = "all"):
        """Show useful phrases for teachers"""
        phrases = self.phrases_db.get_classroom_phrases()
        
        if category != "all" and category in phrases:
            # Show specific category
            category_phrases = phrases[category]
            category_names = {
                "starting_lesson": "Начало урока",
                "instructions": "Инструкции",
                "questions": "Вопросы",
                "encouragement": "Поощрение",
                "corrections": "Исправления"
            }
            
            message = f"📚 *{category_names.get(category, category)}*\n\n"
            for english, russian in category_phrases:
                message += f"• `{english}`\n  {russian}\n\n"
            
        else:
            # Show all categories overview
            message = "📚 *Полезные фразы для учителя*\n\n"
            
            category_names = {
                "starting_lesson": "🚀 Начало урока",
                "instructions": "📋 Инструкции",
                "questions": "❓ Вопросы",
                "encouragement": "👏 Поощрение",
                "corrections": "✏️ Исправления"
            }
            
            for cat_id, cat_name in category_names.items():
                message += f"*{cat_name}:*\n"
                category_phrases = phrases[cat_id]
                
                # Show first 2-3 phrases from each category
                for english, russian in category_phrases[:2]:
                    message += f"• `{english}` - {russian}\n"
                message += "\n"
        
        # Create category selection buttons
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🚀 Начало урока", callback_data="phrases_starting_lesson"),
                InlineKeyboardButton("📋 Инструкции", callback_data="phrases_instructions")
            ],
            [
                InlineKeyboardButton("❓ Вопросы", callback_data="phrases_questions"),
                InlineKeyboardButton("👏 Поощрение", callback_data="phrases_encouragement")
            ],
            [
                InlineKeyboardButton("✏️ Исправления", callback_data="phrases_corrections"),
                InlineKeyboardButton("🔊 Произношение фраз", callback_data="phrases_pronunciation")
            ]
        ])
        
        await bot_context.send_message(message, reply_markup=keyboard)


class PronunciationHandler:
    """Comprehensive pronunciation assistance handler"""
    
    def __init__(self):
        self.detector = LanguageDetector()
    
    async def handle_pronunciation_request(self, bot_context: BotContext, word: str) -> bool:
        """Handle pronunciation assistance request"""
        try:
            # Validate input
            validation_error = self._validate_pronunciation_input(word)
            if validation_error:
                await bot_context.send_message(validation_error)
                return False
            
            await bot_context.send_message("⏳ Анализирую произношение...")
            
            # Get pronunciation explanation from GPT
            pronunciation_result = await gpt_service.explain_pronunciation(
                word, 
                bot_context.user.id
            )
            
            # Send formatted result
            await self._send_pronunciation_result(bot_context, word, pronunciation_result)
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.PRONUNCIATION,
                {
                    "word": word,
                    "word_length": len(word),
                    "syllable_count": len(word.split())
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error handling pronunciation: {e}")
            await bot_context.send_message("❌ Ошибка при анализе произношения. Попробуйте еще раз.")
            return False
    
    def _validate_pronunciation_input(self, word: str) -> Optional[str]:
        """Validate pronunciation input"""
        if len(word.strip()) < 1:
            return "❌ Пожалуйста, введите английское слово или фразу."
        
        if len(word) > 100:
            return "❌ Слишком длинная фраза. Максимум 100 символов."
        
        if not self.detector.is_english_word(word):
            return "❌ Пожалуйста, введите английское слово или фразу."
        
        return None
    
    async def _send_pronunciation_result(self, bot_context: BotContext, 
                                       word: str, pronunciation_result: str):
        """Send formatted pronunciation result"""
        message = f"""🔊 *Произношение: "{word}"*

{pronunciation_result}"""
        
        # Send result
        await bot_context.send_message(message)
        
        # Send action buttons
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🔊 Еще слово", callback_data="pronunciation_new"),
                InlineKeyboardButton("🔄 Перевести", callback_data="translate_word")
            ],
            [
                InlineKeyboardButton("📚 Фразы", callback_data="useful_phrases"),
                InlineKeyboardButton("📤 Поделиться", callback_data="pronunciation_share")
            ]
        ])
        
        await bot_context.send_message(
            "🎯 Хотите изучить произношение других слов?",
            reply_markup=keyboard
        )
    
    async def show_pronunciation_tips(self, bot_context: BotContext):
        """Show general pronunciation tips"""
        tips_message = """🔊 *Советы по произношению для русскоговорящих*

🎯 *Общие правила:*
• Английские звуки короче русских
• Ударение может падать на любой слог
• Не оглушайте звонкие согласные в конце слов

🗣️ *Проблемные звуки:*
• **[θ]** (th) - кончик языка между зубами
• **[w]** - губы трубочкой, не касаются зубов
• **[r]** - язык не касается неба
• **[æ]** - между [а] и [э]

📚 *Полезные упражнения:*
• Читайте вслух каждый день
• Повторяйте за носителями языка
• Записывайте свою речь и сравнивайте
• Изучайте транскрипцию IPA

💡 *Мнемоники:*
• **Thought** [θɔːt] - "ТОТ" с языком между зубов
• **Work** [wɜːk] - "ВЁРК" с округленными губами
• **Cat** [kæt] - между "КЭТ" и "КАТ"

🎵 *Интонация:*
• Вопросы - тон повышается
• Утверждения - тон понижается
• Незаконченная мысль - тон остается высоким"""
        
        await bot_context.send_message(tips_message)


class TranslationPronunciationHandler:
    """Combined handler for translation and pronunciation features"""
    
    def __init__(self):
        self.translation_handler = TranslationHandler()
        self.pronunciation_handler = PronunciationHandler()
    
    async def handle_text_input(self, bot_context: BotContext, text: str, 
                               session_context: Dict[str, any]) -> bool:
        """Handle text input based on session context"""
        try:
            waiting_for = session_context.get("waiting_for")
            
            if waiting_for == "translation_text":
                direction_str = session_context.get("direction", "ru-en")
                direction = TranslationDirection(direction_str)
                return await self.translation_handler.handle_translation_request(
                    bot_context, text, direction
                )
            
            elif waiting_for == "pronunciation_text":
                return await self.pronunciation_handler.handle_pronunciation_request(
                    bot_context, text
                )
            
            else:
                # Auto-detect and process
                return await self.translation_handler.auto_detect_and_translate(
                    bot_context, text
                )
                
        except Exception as e:
            handlers_logger.error(f"Error handling text input: {e}")
            await bot_context.send_message("❌ Ошибка при обработке текста.")
            return False


# Global handler instances
translation_handler = TranslationHandler()
pronunciation_handler = PronunciationHandler()
translation_pronunciation_handler = TranslationPronunciationHandler()