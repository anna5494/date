"""
Specialized lesson plan handlers for English Teacher Bot
Provides comprehensive lesson planning functionality with templates and customization
"""

import re
from typing import Dict, List, Any, Optional
from dataclasses import dataclass

from bot.main_bot import BotContext
from bot.services.gpt_service import gpt_service
from bot.services.analytics_service import analytics_service
from bot.models.database import activity_repo, ActivityType
from bot.utils.logger import handlers_logger
from bot.config.settings import config


@dataclass
class LessonPlanParams:
    """Lesson plan parameters"""
    topic: str
    level: str
    duration: int
    students_age: str
    goals: str
    additional_info: str = ""
    template_type: str = ""


class LessonPlanTemplates:
    """Pre-defined lesson plan templates"""
    
    @staticmethod
    def get_grammar_template() -> LessonPlanParams:
        return LessonPlanParams(
            topic="Грамматическая структура",
            level="B1",
            duration=45,
            students_age="12-15 лет",
            goals="Изучить новую грамматическую структуру, научиться использовать её в речи",
            additional_info="Урок с акцентом на практическое применение грамматики",
            template_type="grammar"
        )
    
    @staticmethod
    def get_speaking_template() -> LessonPlanParams:
        return LessonPlanParams(
            topic="Развитие разговорных навыков",
            level="B1",
            duration=45,
            students_age="14-17 лет",
            goals="Развить навыки спонтанной речи, увеличить словарный запас",
            additional_info="Интерактивный урок с ролевыми играми и дискуссиями",
            template_type="speaking"
        )
    
    @staticmethod
    def get_reading_template() -> LessonPlanParams:
        return LessonPlanParams(
            topic="Развитие навыков чтения",
            level="A2",
            duration=45,
            students_age="10-13 лет",
            goals="Улучшить понимание прочитанного, изучить новую лексику",
            additional_info="Работа с адаптированным текстом",
            template_type="reading"
        )
    
    @staticmethod
    def get_writing_template() -> LessonPlanParams:
        return LessonPlanParams(
            topic="Развитие письменной речи",
            level="B2",
            duration=45,
            students_age="15-18 лет",
            goals="Научиться писать структурированные тексты, использовать связующие слова",
            additional_info="Написание эссе и личных писем",
            template_type="writing"
        )
    
    @staticmethod
    def get_listening_template() -> LessonPlanParams:
        return LessonPlanParams(
            topic="Развитие навыков аудирования",
            level="A2",
            duration=45,
            students_age="12-15 лет",
            goals="Улучшить понимание английской речи на слух",
            additional_info="Использование аудио и видео материалов",
            template_type="listening"
        )
    
    @staticmethod
    def get_vocabulary_template() -> LessonPlanParams:
        return LessonPlanParams(
            topic="Изучение новой лексики",
            level="A1",
            duration=45,
            students_age="8-12 лет",
            goals="Изучить новые слова по теме, научиться использовать их в контексте",
            additional_info="Игровой формат изучения лексики",
            template_type="vocabulary"
        )


class LessonPlanHandler:
    """Advanced lesson plan handler with templates and customization"""
    
    def __init__(self):
        self.templates = {
            "grammar": LessonPlanTemplates.get_grammar_template,
            "speaking": LessonPlanTemplates.get_speaking_template,
            "reading": LessonPlanTemplates.get_reading_template,
            "writing": LessonPlanTemplates.get_writing_template,
            "listening": LessonPlanTemplates.get_listening_template,
            "vocabulary": LessonPlanTemplates.get_vocabulary_template,
        }
    
    async def handle_template_selection(self, bot_context: BotContext, template_name: str) -> bool:
        """Handle template-based lesson plan creation"""
        try:
            if template_name not in self.templates:
                await bot_context.send_message("❌ Неизвестный шаблон")
                return False
            
            # Get template parameters
            template_params = self.templates[template_name]()
            
            await bot_context.send_message("⏳ Создаю план урока на основе шаблона...")
            
            # Create lesson plan using GPT
            lesson_plan = await gpt_service.create_lesson_plan(
                template_params.__dict__, 
                bot_context.user.id
            )
            
            # Send the lesson plan
            await self._send_formatted_lesson_plan(
                bot_context, 
                lesson_plan, 
                template_params
            )
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.LESSON_PLAN,
                {
                    "template": template_name,
                    "topic": template_params.topic,
                    "level": template_params.level
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error creating template lesson plan: {e}")
            await bot_context.send_message("❌ Ошибка при создании плана урока")
            return False
    
    async def handle_quick_lesson_plan(self, bot_context: BotContext, user_input: str) -> bool:
        """Handle quick lesson plan creation"""
        try:
            params = self._parse_quick_input(user_input)
            if not params:
                await bot_context.send_message(
                    "❌ Пожалуйста, укажите тему и уровень в правильном формате:\n\n"
                    "`Тема: [ваша тема]\\nУровень: [A1/A2/B1/B2/C1/C2]`"
                )
                return False
            
            await bot_context.send_message("⏳ Создаю быстрый план урока...")
            
            # Create lesson plan
            lesson_plan = await gpt_service.create_lesson_plan(
                params.__dict__, 
                bot_context.user.id
            )
            
            # Send formatted plan
            await self._send_formatted_lesson_plan(bot_context, lesson_plan, params)
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.LESSON_PLAN,
                {
                    "type": "quick",
                    "topic": params.topic,
                    "level": params.level
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error creating quick lesson plan: {e}")
            await bot_context.send_message("❌ Ошибка при создании плана урока")
            return False
    
    async def handle_detailed_lesson_plan(self, bot_context: BotContext, user_input: str) -> bool:
        """Handle detailed lesson plan creation"""
        try:
            params = self._parse_detailed_input(user_input)
            
            await bot_context.send_message("⏳ Создаю детальный план урока...")
            
            # Create lesson plan
            lesson_plan = await gpt_service.create_lesson_plan(
                params.__dict__, 
                bot_context.user.id
            )
            
            # Send formatted plan
            await self._send_formatted_lesson_plan(bot_context, lesson_plan, params)
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.LESSON_PLAN,
                {
                    "type": "detailed",
                    "topic": params.topic,
                    "level": params.level,
                    "duration": params.duration
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error creating detailed lesson plan: {e}")
            await bot_context.send_message("❌ Ошибка при создании плана урока")
            return False
    
    def _parse_quick_input(self, text: str) -> Optional[LessonPlanParams]:
        """Parse quick lesson plan input"""
        topic_match = re.search(r'тема:\s*(.+)', text, re.IGNORECASE | re.MULTILINE)
        level_match = re.search(r'уровень:\s*([A-C][1-2])', text, re.IGNORECASE)
        
        if not topic_match or not level_match:
            return None
        
        return LessonPlanParams(
            topic=topic_match.group(1).strip(),
            level=level_match.group(1).upper(),
            duration=45,
            students_age="12-15 лет",
            goals="Изучить новую тему, закрепить знания на практике",
            additional_info=""
        )
    
    def _parse_detailed_input(self, text: str) -> LessonPlanParams:
        """Parse detailed lesson plan input"""
        # Extract various parameters from text
        topic = self._extract_field(text, ['тема', 'topic']) or "Не указана"
        level = self._extract_level(text) or "B1"
        duration_str = self._extract_field(text, ['продолжительность', 'время', 'duration']) or "45"
        students_age = self._extract_field(text, ['возраст', 'age']) or "12-15 лет"
        goals = self._extract_field(text, ['цели', 'цель', 'goals', 'goal']) or "Изучить новую тему"
        additional_info = self._extract_field(text, ['дополнительно', 'дополнительная информация', 'заметки']) or ""
        
        # Parse duration
        try:
            duration = int(re.search(r'(\d+)', duration_str).group(1))
        except (AttributeError, ValueError):
            duration = 45
        
        return LessonPlanParams(
            topic=topic,
            level=level,
            duration=duration,
            students_age=students_age,
            goals=goals,
            additional_info=additional_info
        )
    
    def _extract_field(self, text: str, keywords: List[str]) -> Optional[str]:
        """Extract field value from text by keywords"""
        for keyword in keywords:
            pattern = rf'{keyword}:?\s*(.+?)(?=\n|$|[а-яё]+:|[a-z]+:)'
            match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
            if match:
                return match.group(1).strip()
        return None
    
    def _extract_level(self, text: str) -> Optional[str]:
        """Extract English level from text"""
        level_match = re.search(r'\b([A-C][1-2])\b', text, re.IGNORECASE)
        return level_match.group(1).upper() if level_match else None
    
    async def _send_formatted_lesson_plan(self, bot_context: BotContext, 
                                        lesson_plan: str, params: LessonPlanParams):
        """Send formatted lesson plan with metadata"""
        # Create header with plan details
        header = f"""📚 *План урока создан!*

📝 *Тема:* {params.topic}
🎯 *Уровень:* {params.level}
⏰ *Продолжительность:* {params.duration} мин
👥 *Возраст:* {params.students_age}
🎪 *Цели:* {params.goals}

─────────────────────────

"""
        
        # Combine header and content
        full_message = header + lesson_plan
        
        # Check message length and split if necessary
        if len(full_message) > config.MAX_MESSAGE_LENGTH:
            # Send header first
            await bot_context.send_message(header)
            
            # Split and send lesson plan content
            chunks = self._split_lesson_plan(lesson_plan)
            for i, chunk in enumerate(chunks):
                is_last = (i == len(chunks) - 1)
                
                if is_last:
                    # Add action buttons to the last message
                    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
                    keyboard = InlineKeyboardMarkup([
                        [
                            InlineKeyboardButton("📥 Сохранить", callback_data="lesson_save"),
                            InlineKeyboardButton("📤 Поделиться", callback_data="lesson_share")
                        ],
                        [
                            InlineKeyboardButton("🔄 Создать новый", callback_data="lesson_new"),
                            InlineKeyboardButton("✏️ Изменить", callback_data="lesson_modify")
                        ]
                    ])
                    
                    await bot_context.send_message(chunk, reply_markup=keyboard)
                else:
                    await bot_context.send_message(chunk)
        else:
            # Send complete message with buttons
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            keyboard = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("📥 Сохранить", callback_data="lesson_save"),
                    InlineKeyboardButton("📤 Поделиться", callback_data="lesson_share")
                ],
                [
                    InlineKeyboardButton("🔄 Создать новый", callback_data="lesson_new"),
                    InlineKeyboardButton("✏️ Изменить", callback_data="lesson_modify")
                ]
            ])
            
            await bot_context.send_message(full_message, reply_markup=keyboard)
        
        # Offer additional suggestions
        await self._send_lesson_suggestions(bot_context, params)
    
    def _split_lesson_plan(self, lesson_plan: str) -> List[str]:
        """Split lesson plan into chunks respecting message limits"""
        max_chunk_size = config.MAX_MESSAGE_LENGTH - 100  # Leave some buffer
        chunks = []
        current_chunk = ""
        
        lines = lesson_plan.split('\n')
        for line in lines:
            if len(current_chunk + line + '\n') > max_chunk_size and current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = line + '\n'
            else:
                current_chunk += line + '\n'
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    async def _send_lesson_suggestions(self, bot_context: BotContext, params: LessonPlanParams):
        """Send additional suggestions based on the lesson plan"""
        suggestions = []
        
        # Level-based suggestions
        if params.level in ['A1', 'A2']:
            suggestions.append("💡 Для начинающих учеников добавьте больше визуальных материалов")
        elif params.level in ['C1', 'C2']:
            suggestions.append("💡 Для продвинутых учеников можно добавить дискуссионные вопросы")
        
        # Topic-based suggestions
        if 'грамматик' in params.topic.lower():
            suggestions.append("📝 Рекомендуем создать викторину для закрепления грамматики")
        elif 'говорение' in params.topic.lower() or 'разговор' in params.topic.lower():
            suggestions.append("🗣️ Попробуйте создать диалоги для практики")
        
        # Duration-based suggestions
        if params.duration > 60:
            suggestions.append("⏰ Для длинного урока добавьте перерыв в середине")
        
        if suggestions:
            suggestion_text = "🎯 *Дополнительные рекомендации:*\n" + "\n".join(suggestions)
            
            from telegram import InlineKeyboardButton, InlineKeyboardMarkup
            keyboard = InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("🧩 Создать викторину", callback_data="create_quiz"),
                    InlineKeyboardButton("💬 Создать диалог", callback_data="create_dialogue")
                ]
            ])
            
            await bot_context.send_message(suggestion_text, reply_markup=keyboard)
    
    async def save_lesson_plan(self, bot_context: BotContext, lesson_plan: str, params: LessonPlanParams):
        """Save lesson plan to database"""
        try:
            # Save to database using the activity repository
            activity_repo.track_activity(
                user_id=bot_context.user.id,
                activity_type=ActivityType.LESSON_PLAN,
                activity_data={
                    "title": params.topic,
                    "content": lesson_plan[:500],  # Store truncated content
                    "level": params.level,
                    "duration": params.duration,
                    "template_type": getattr(params, 'template_type', '')
                }
            )
            
            await bot_context.send_message("✅ План урока сохранен в вашей истории!")
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error saving lesson plan: {e}")
            await bot_context.send_message("❌ Ошибка при сохранении плана урока")
            return False


# Global lesson plan handler instance
lesson_plan_handler = LessonPlanHandler()