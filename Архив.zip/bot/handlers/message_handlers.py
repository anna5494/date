"""
Обработчики сообщений для English Teacher Bot
"""

import re
from telegram import Update
from telegram.ext import ContextTypes, MessageHandler, filters

from bot.main_bot import BotContext
from bot.services.gpt_service import gpt_service
from bot.services.analytics_service import analytics_service
from bot.models.database import activity_repo, ActivityType
from bot.utils.logger import handlers_logger
from bot.config.settings import Messages

# Import specialized handlers
from bot.handlers.grammar_handler import grammar_handler
from bot.handlers.lesson_plan_handler import lesson_plan_handler, LessonPlanParams
from bot.handlers.quiz_handler import quiz_generator
from bot.handlers.translation_pronunciation_handler import (
    translation_handler, 
    pronunciation_handler,
    TranslationDirection
)


async def handle_text_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик текстовых сообщений"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    text = update.message.text.strip()
    
    # Проверяем, не является ли это кнопкой клавиатуры
    keyboard_buttons = [
        "📚 План урока", "📝 Грамматика", "🧩 Викторина", 
        "🔄 Перевод", "🔊 Произношение", "📊 Прогресс"
    ]
    
    if text in keyboard_buttons:
        await handle_keyboard_button(bot_context, text)
        return
    
    # Проверяем, есть ли активная сессия
    if bot_context.session and bot_context.session.get("waiting_for"):
        await handle_session_message(bot_context, text)
    else:
        # Обрабатываем как общий запрос
        await handle_general_query(bot_context, text)


async def handle_keyboard_button(bot_context: BotContext, button_text: str):
    """Обрабатывает нажатия кнопок клавиатуры"""
    if button_text == "📚 План урока":
        from bot.handlers.command_handlers import lesson_command
        await lesson_command(bot_context.update, bot_context.context)
    elif button_text == "📝 Грамматика":
        from bot.handlers.command_handlers import grammar_command
        await grammar_command(bot_context.update, bot_context.context)
    elif button_text == "🧩 Викторина":
        from bot.handlers.command_handlers import quiz_command
        await quiz_command(bot_context.update, bot_context.context)
    elif button_text == "🔄 Перевод":
        from bot.handlers.command_handlers import translate_command
        await translate_command(bot_context.update, bot_context.context)
    elif button_text == "🔊 Произношение":
        from bot.handlers.command_handlers import pronunciation_command
        await pronunciation_command(bot_context.update, bot_context.context)
    elif button_text == "📊 Прогресс":
        from bot.handlers.command_handlers import progress_command
        await progress_command(bot_context.update, bot_context.context)


async def handle_session_message(bot_context: BotContext, text: str):
    """Handles messages in context of active session using specialized handlers"""
    if not bot_context.session:
        await handle_general_query(bot_context, text)
        return
        
    waiting_for = bot_context.session.get("waiting_for")
    flow = bot_context.session.get("flow")
    
    try:
        if waiting_for == "grammar_text":
            await grammar_handler.check_grammar_text(bot_context, text)
        elif waiting_for == "pronunciation_text":
            await pronunciation_handler.handle_pronunciation_request(bot_context, text)
        elif waiting_for == "lesson_quick_details":
            await lesson_plan_handler.handle_quick_lesson_plan(bot_context, text)
        elif waiting_for == "lesson_detailed_info":
            await lesson_plan_handler.handle_detailed_lesson_plan(bot_context, text)
        elif waiting_for == "quiz_quick_topic":
            await quiz_generator.create_quick_quiz(bot_context, text)
        elif waiting_for == "quiz_details":
            await quiz_generator.create_custom_quiz(bot_context, text)
        elif waiting_for == "translation_text":
            direction_str = bot_context.session.get("direction", "ru-en")
            direction = TranslationDirection(direction_str)
            await translation_handler.handle_translation_request(bot_context, text, direction)
        else:
            await handle_general_query(bot_context, text)
    
    except Exception as e:
        handlers_logger.error(f"Error handling session message: {e}")
        await bot_context.send_message(Messages.ERROR)
        await bot_context.clear_session()


async def handle_grammar_text(bot_context: BotContext, text: str):
    """Handles grammar checking using specialized grammar handler"""
    await grammar_handler.check_grammar_text(bot_context, text)


async def handle_pronunciation_text(bot_context: BotContext, text: str):
    """Handles pronunciation requests using specialized pronunciation handler"""
    await pronunciation_handler.handle_pronunciation_request(bot_context, text)


async def handle_lesson_quick(bot_context: BotContext, text: str):
    """Handles quick lesson plan creation using specialized lesson plan handler"""
    await lesson_plan_handler.handle_quick_lesson_plan(bot_context, text)


async def create_lesson_plan(bot_context: BotContext, requirements: dict):
    """Creates lesson plan using specialized lesson plan handler"""
    # Ensure user is available
    if not bot_context.user or not bot_context.user.id:
        await bot_context.send_message("❌ Ошибка пользователя. Попробуйте еще раз.")
        return
        
    # Convert dict to LessonPlanParams format
    params = LessonPlanParams(
        topic=requirements.get('topic', ''),
        level=requirements.get('level', 'B1'),
        duration=int(requirements.get('duration', 45)),
        students_age=requirements.get('students_age', '12-15 лет'),
        goals=requirements.get('goals', ''),
        additional_info=requirements.get('additional_info', '')
    )
    
    await lesson_plan_handler._send_formatted_lesson_plan(
        bot_context, 
        await gpt_service.create_lesson_plan(requirements, bot_context.user.id),
        params
    )


async def handle_general_query(bot_context: BotContext, text: str):
    """Handles general queries using GPT with enhanced analytics"""
    await bot_context.send_message(Messages.PROCESSING)
    
    try:
        # Ensure user is available
        if not bot_context.user or not bot_context.user.id:
            await bot_context.send_message("❌ Ошибка пользователя. Попробуйте еще раз.")
            return
            
        response = await gpt_service.process_general_query(text, bot_context.user.id)
        await bot_context.send_message(response)
        
        # Track general query usage
        analytics_service.track_feature_usage(
            bot_context.user.id,
            "general_query",
            {
                "query_length": len(text),
                "word_count": len(text.split())
            }
        )
        
    except Exception as e:
        handlers_logger.error(f"Error in general query: {e}")
        await bot_context.send_message(Messages.NOT_UNDERSTOOD)


# Заглушки для других обработчиков - теперь интегрированы с специализированными обработчиками
async def handle_lesson_detailed(bot_context: BotContext, text: str):
    """Handles detailed lesson plan creation using specialized lesson plan handler"""
    await lesson_plan_handler.handle_detailed_lesson_plan(bot_context, text)


async def handle_quiz_quick(bot_context: BotContext, text: str):
    """Handles quick quiz creation using specialized quiz handler"""
    await quiz_generator.create_quick_quiz(bot_context, text)


async def handle_quiz_detailed(bot_context: BotContext, text: str):
    """Handles detailed quiz creation using specialized quiz handler"""
    await quiz_generator.create_custom_quiz(bot_context, text)


async def handle_translation_text(bot_context: BotContext, text: str):
    """Handles translation requests using specialized translation handler"""
    if not bot_context.session:
        await bot_context.send_message("❌ Сессия истекла. Начните заново.")
        return
        
    direction_str = bot_context.session.get("direction", "ru-en")
    direction = TranslationDirection(direction_str)
    await translation_handler.handle_translation_request(bot_context, text, direction)


def setup_message_handlers(application):
    """Sets up message handlers with comprehensive functionality"""
    handlers_logger.info("Setting up enhanced message handlers...")
    
    # Text message handler with specialized routing
    application.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, handle_text_message)
    )
    
    handlers_logger.info("Enhanced message handlers configured")