"""
Quiz generation handlers for English Teacher Bot
Provides comprehensive quiz creation with multiple question types and difficulty levels
"""

import re
import random
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from enum import Enum

from bot.main_bot import BotContext
from bot.services.gpt_service import gpt_service
from bot.services.analytics_service import analytics_service
from bot.models.database import ActivityType
from bot.utils.logger import handlers_logger
from bot.config.settings import config


class QuizType(Enum):
    """Quiz types enumeration"""
    MULTIPLE_CHOICE = "multiple_choice"
    FILL_BLANKS = "fill_blanks"
    TRANSLATION = "translation"
    MATCHING = "matching"
    VOCABULARY = "vocabulary"
    TRUE_FALSE = "true_false"
    MIXED = "mixed"


@dataclass
class QuizParams:
    """Quiz parameters structure"""
    topic: str
    level: str
    question_count: int
    quiz_type: QuizType
    language_direction: str = "en-ru"  # For translation quizzes
    include_explanations: bool = True


class QuizTemplates:
    """Pre-defined quiz templates for common topics"""
    
    @staticmethod
    def get_templates() -> Dict[str, QuizParams]:
        return {
            "irregular_verbs": QuizParams(
                topic="Irregular Verbs",
                level="A2",
                question_count=10,
                quiz_type=QuizType.FILL_BLANKS
            ),
            "present_perfect": QuizParams(
                topic="Present Perfect Tense",
                level="B1",
                question_count=8,
                quiz_type=QuizType.MULTIPLE_CHOICE
            ),
            "prepositions": QuizParams(
                topic="Prepositions of Time and Place",
                level="A2",
                question_count=10,
                quiz_type=QuizType.MULTIPLE_CHOICE
            ),
            "articles": QuizParams(
                topic="Articles (a, an, the)",
                level="A1",
                question_count=12,
                quiz_type=QuizType.FILL_BLANKS
            ),
            "past_simple": QuizParams(
                topic="Past Simple Tense",
                level="A2",
                question_count=10,
                quiz_type=QuizType.MIXED
            ),
            "conditionals": QuizParams(
                topic="Conditional Sentences",
                level="B2",
                question_count=8,
                quiz_type=QuizType.MULTIPLE_CHOICE
            ),
            "phrasal_verbs": QuizParams(
                topic="Common Phrasal Verbs",
                level="B1",
                question_count=10,
                quiz_type=QuizType.MATCHING
            ),
            "business_english": QuizParams(
                topic="Business English Vocabulary",
                level="B2",
                question_count=12,
                quiz_type=QuizType.VOCABULARY
            ),
            "food_vocabulary": QuizParams(
                topic="Food and Drinks",
                level="A1",
                question_count=10,
                quiz_type=QuizType.VOCABULARY
            ),
            "travel_english": QuizParams(
                topic="Travel and Tourism",
                level="B1",
                question_count=10,
                quiz_type=QuizType.MIXED
            )
        }


class QuizGenerator:
    """Advanced quiz generation system"""
    
    def __init__(self):
        self.templates = QuizTemplates.get_templates()
        self.difficulty_levels = {
            "A1": "Beginner",
            "A2": "Elementary", 
            "B1": "Intermediate",
            "B2": "Upper-Intermediate",
            "C1": "Advanced",
            "C2": "Proficiency"
        }
    
    async def create_quick_quiz(self, bot_context: BotContext, topic: str) -> bool:
        """Create a quick quiz on specified topic"""
        try:
            # Use default parameters for quick quiz
            params = QuizParams(
                topic=topic,
                level="B1",
                question_count=5,
                quiz_type=QuizType.MIXED
            )
            
            await bot_context.send_message("⏳ Создаю быструю викторину...")
            
            # Generate quiz
            quiz_content = await self._generate_quiz_content(params, bot_context.user.id)
            
            # Send quiz
            await self._send_formatted_quiz(bot_context, quiz_content, params)
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.QUIZ,
                {
                    "type": "quick",
                    "topic": topic,
                    "level": params.level,
                    "question_count": params.question_count
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error creating quick quiz: {e}")
            await bot_context.send_message("❌ Ошибка при создании викторины. Попробуйте еще раз.")
            return False
    
    async def create_custom_quiz(self, bot_context: BotContext, user_input: str) -> bool:
        """Create custom quiz based on user specifications"""
        try:
            params = self._parse_quiz_params(user_input)
            if not params:
                await bot_context.send_message(
                    "❌ Пожалуйста, укажите параметры в правильном формате:\n\n"
                    "`Тема: [тема]\\nУровень: [A1-C2]\\nКоличество: [1-20]`"
                )
                return False
            
            await bot_context.send_message("⏳ Создаю викторину...")
            
            # Generate quiz
            quiz_content = await self._generate_quiz_content(params, bot_context.user.id)
            
            # Send quiz
            await self._send_formatted_quiz(bot_context, quiz_content, params)
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.QUIZ,
                {
                    "type": "custom",
                    "topic": params.topic,
                    "level": params.level,
                    "question_count": params.question_count,
                    "quiz_type": params.quiz_type.value
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error creating custom quiz: {e}")
            await bot_context.send_message("❌ Ошибка при создании викторины.")
            return False
    
    async def create_template_quiz(self, bot_context: BotContext, template_name: str) -> bool:
        """Create quiz from predefined template"""
        try:
            if template_name not in self.templates:
                await bot_context.send_message("❌ Шаблон не найден")
                return False
            
            params = self.templates[template_name]
            
            await bot_context.send_message(f"⏳ Создаю викторину: {params.topic}...")
            
            # Generate quiz
            quiz_content = await self._generate_quiz_content(params, bot_context.user.id)
            
            # Send quiz
            await self._send_formatted_quiz(bot_context, quiz_content, params)
            
            # Track activity
            analytics_service.track_feature_usage(
                bot_context.user.id,
                ActivityType.QUIZ,
                {
                    "type": "template",
                    "template": template_name,
                    "topic": params.topic,
                    "level": params.level,
                    "question_count": params.question_count
                }
            )
            
            return True
            
        except Exception as e:
            handlers_logger.error(f"Error creating template quiz: {e}")
            await bot_context.send_message("❌ Ошибка при создании викторины.")
            return False
    
    def _parse_quiz_params(self, text: str) -> Optional[QuizParams]:
        """Parse quiz parameters from user input"""
        topic = self._extract_field(text, ['тема', 'topic']) or "General English"
        level = self._extract_level(text) or "B1"
        count_str = self._extract_field(text, ['количество', 'вопросов', 'count']) or "5"
        quiz_type_str = self._extract_field(text, ['тип', 'type']) or "mixed"
        
        # Parse question count
        try:
            question_count = int(re.search(r'(\d+)', count_str).group(1))
            question_count = max(1, min(question_count, 20))  # Limit between 1-20
        except (AttributeError, ValueError):
            question_count = 5
        
        # Parse quiz type
        quiz_type = self._parse_quiz_type(quiz_type_str)
        
        return QuizParams(
            topic=topic,
            level=level,
            question_count=question_count,
            quiz_type=quiz_type
        )
    
    def _extract_field(self, text: str, keywords: List[str]) -> Optional[str]:
        """Extract field value from text by keywords"""
        for keyword in keywords:
            pattern = rf'{keyword}:?\s*(.+?)(?=\n|$|[а-яё]+:|[a-z]+:)'
            match = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
            if match:
                return match.group(1).strip()
        return None
    
    def _extract_level(self, text: str) -> Optional[str]:
        """Extract English level from text"""
        level_match = re.search(r'\b([A-C][1-2])\b', text, re.IGNORECASE)
        return level_match.group(1).upper() if level_match else None
    
    def _parse_quiz_type(self, type_str: str) -> QuizType:
        """Parse quiz type from string"""
        type_mapping = {
            "множественный выбор": QuizType.MULTIPLE_CHOICE,
            "multiple choice": QuizType.MULTIPLE_CHOICE,
            "заполнение пропусков": QuizType.FILL_BLANKS,
            "fill blanks": QuizType.FILL_BLANKS,
            "перевод": QuizType.TRANSLATION,
            "translation": QuizType.TRANSLATION,
            "сопоставление": QuizType.MATCHING,
            "matching": QuizType.MATCHING,
            "словарь": QuizType.VOCABULARY,
            "vocabulary": QuizType.VOCABULARY,
            "верно/неверно": QuizType.TRUE_FALSE,
            "true false": QuizType.TRUE_FALSE,
            "смешанный": QuizType.MIXED,
            "mixed": QuizType.MIXED
        }
        
        for key, quiz_type in type_mapping.items():
            if key in type_str.lower():
                return quiz_type
        
        return QuizType.MIXED
    
    async def _generate_quiz_content(self, params: QuizParams, user_id: int) -> str:
        """Generate quiz content using GPT"""
        # Create specific prompt based on quiz type
        if params.quiz_type == QuizType.MULTIPLE_CHOICE:
            quiz_type_desc = "Множественный выбор (4 варианта ответа)"
        elif params.quiz_type == QuizType.FILL_BLANKS:
            quiz_type_desc = "Заполнение пропусков"
        elif params.quiz_type == QuizType.TRANSLATION:
            quiz_type_desc = "Перевод с русского на английский"
        elif params.quiz_type == QuizType.MATCHING:
            quiz_type_desc = "Сопоставление слов и определений"
        elif params.quiz_type == QuizType.VOCABULARY:
            quiz_type_desc = "Словарный запас"
        elif params.quiz_type == QuizType.TRUE_FALSE:
            quiz_type_desc = "Верно/Неверно"
        else:
            quiz_type_desc = "Смешанный (разные типы вопросов)"
        
        # Generate quiz using GPT service
        quiz_content = await gpt_service.create_quiz(
            topic=params.topic,
            level=params.level,
            num_questions=params.question_count,
            quiz_type=quiz_type_desc,
            user_id=user_id
        )
        
        return quiz_content
    
    async def _send_formatted_quiz(self, bot_context: BotContext, 
                                 quiz_content: str, params: QuizParams):
        """Send formatted quiz with metadata and controls"""
        # Create header
        header = f"""🧩 *Викторина создана!*

📚 *Тема:* {params.topic}
🎯 *Уровень:* {params.level} ({self.difficulty_levels.get(params.level, 'Unknown')})
🔢 *Вопросов:* {params.question_count}
📝 *Тип:* {self._get_quiz_type_name(params.quiz_type)}

─────────────────────────

"""
        
        # Combine header and content
        full_message = header + quiz_content
        
        # Send quiz (split if necessary)
        if len(full_message) > config.MAX_MESSAGE_LENGTH:
            # Send header first
            await bot_context.send_message(header)
            
            # Split and send content
            chunks = self._split_text(quiz_content)
            for i, chunk in enumerate(chunks):
                is_last = (i == len(chunks) - 1)
                
                if is_last:
                    # Add action buttons to last message
                    await self._send_quiz_with_buttons(bot_context, chunk)
                else:
                    await bot_context.send_message(chunk)
        else:
            # Send complete message with buttons
            await self._send_quiz_with_buttons(bot_context, full_message)
        
        # Send additional suggestions
        await self._send_quiz_suggestions(bot_context, params)
    
    async def _send_quiz_with_buttons(self, bot_context: BotContext, content: str):
        """Send quiz content with action buttons"""
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        
        keyboard = InlineKeyboardMarkup([
            [
                InlineKeyboardButton("📥 Сохранить", callback_data="quiz_save"),
                InlineKeyboardButton("📤 Поделиться", callback_data="quiz_share")
            ],
            [
                InlineKeyboardButton("🔄 Создать новую", callback_data="quiz_new"),
                InlineKeyboardButton("📊 Показать ответы", callback_data="quiz_answers")
            ],
            [
                InlineKeyboardButton("📚 Создать план урока", callback_data="create_lesson"),
                InlineKeyboardButton("📝 Создать словарь", callback_data="create_vocabulary")
            ]
        ])
        
        await bot_context.send_message(content, reply_markup=keyboard)
    
    def _get_quiz_type_name(self, quiz_type: QuizType) -> str:
        """Get readable quiz type name"""
        type_names = {
            QuizType.MULTIPLE_CHOICE: "Множественный выбор",
            QuizType.FILL_BLANKS: "Заполнение пропусков",
            QuizType.TRANSLATION: "Перевод",
            QuizType.MATCHING: "Сопоставление",
            QuizType.VOCABULARY: "Словарный запас",
            QuizType.TRUE_FALSE: "Верно/Неверно",
            QuizType.MIXED: "Смешанный"
        }
        return type_names.get(quiz_type, "Неизвестный")
    
    async def _send_quiz_suggestions(self, bot_context: BotContext, params: QuizParams):
        """Send suggestions based on quiz parameters"""
        suggestions = []
        
        # Level-based suggestions
        if params.level in ['A1', 'A2']:
            suggestions.append("💡 Для начинающих: добавьте картинки к вопросам")
        elif params.level in ['C1', 'C2']:
            suggestions.append("💡 Для продвинутых: используйте реальные ситуации")
        
        # Topic-based suggestions
        topic_lower = params.topic.lower()
        if 'grammar' in topic_lower or 'грамматик' in topic_lower:
            suggestions.append("📝 Дополните викторину упражнениями на письмо")
        elif 'vocabulary' in topic_lower or 'словар' in topic_lower:
            suggestions.append("🎯 Создайте карточки для запоминания слов")
        
        # Quiz type suggestions
        if params.quiz_type == QuizType.MULTIPLE_CHOICE:
            suggestions.append("🔄 Попробуйте создать викторину с заполнением пропусков")
        
        if suggestions:
            suggestion_text = "🎯 *Дополнительные идеи:*\n" + "\n".join(suggestions)
            await bot_context.send_message(suggestion_text)
    
    def _split_text(self, text: str) -> List[str]:
        """Split long text into manageable chunks"""
        max_length = config.MAX_MESSAGE_LENGTH - 200  # Buffer for buttons
        chunks = []
        current_chunk = ""
        
        lines = text.split('\n')
        for line in lines:
            if len(current_chunk + line + '\n') > max_length and current_chunk:
                chunks.append(current_chunk.strip())
                current_chunk = line + '\n'
            else:
                current_chunk += line + '\n'
        
        if current_chunk:
            chunks.append(current_chunk.strip())
        
        return chunks
    
    async def show_quiz_templates(self, bot_context: BotContext):
        """Show available quiz templates"""
        template_message = "📋 *Готовые шаблоны викторин:*\n\n"
        
        template_descriptions = {
            "irregular_verbs": "🔤 Неправильные глаголы (A2)",
            "present_perfect": "⏰ Present Perfect (B1)",
            "prepositions": "🔗 Предлоги времени и места (A2)",
            "articles": "📄 Артикли a, an, the (A1)",
            "past_simple": "⏮️ Past Simple (A2)",
            "conditionals": "🎭 Условные предложения (B2)",
            "phrasal_verbs": "🔄 Фразовые глаголы (B1)",
            "business_english": "💼 Деловой английский (B2)",
            "food_vocabulary": "🍽️ Еда и напитки (A1)",
            "travel_english": "✈️ Путешествия (B1)"
        }
        
        for template_id, description in template_descriptions.items():
            template_message += f"• {description}\n"
        
        template_message += "\n💡 Выберите шаблон из меню или создайте свою викторину!"
        
        # Create template selection buttons
        from telegram import InlineKeyboardButton, InlineKeyboardMarkup
        
        keyboard_rows = []
        template_items = list(template_descriptions.items())
        
        # Create rows of 2 buttons each
        for i in range(0, len(template_items), 2):
            row = []
            for j in range(2):
                if i + j < len(template_items):
                    template_id, description = template_items[i + j]
                    # Truncate description for button
                    button_text = description.split('(')[0].strip()[:20]
                    row.append(InlineKeyboardButton(
                        button_text, 
                        callback_data=f"quiz_template_{template_id}"
                    ))
            keyboard_rows.append(row)
        
        keyboard = InlineKeyboardMarkup(keyboard_rows)
        
        await bot_context.send_message(template_message, reply_markup=keyboard)


# Global quiz generator instance
quiz_generator = QuizGenerator()