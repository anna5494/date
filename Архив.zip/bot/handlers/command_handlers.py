"""
Обработчики команд для English Teacher Bot
"""

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup
from telegram.ext import ContextTypes, CommandHandler

from bot.config.settings import Messages
from bot.main_bot import BotContext
from bot.utils.logger import handlers_logger
from bot.models.database import activity_repo, ActivityType


async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /start"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    # Создаем клавиатуру
    keyboard = [
        ["📚 План урока", "📝 Грамматика"],
        ["🧩 Викторина", "🔄 Перевод"],
        ["🔊 Произношение", "📊 Прогресс"]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True, one_time_keyboard=False)
    
    await bot_context.send_message(
        Messages.WELCOME,
        reply_markup=reply_markup
    )
    
    handlers_logger.info(f"Пользователь {bot_context.user.id} запустил бота")


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /help"""
    bot_context = BotContext(update, context)
    await bot_context.send_message(Messages.HELP)


async def lesson_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /lesson"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    keyboard = [
        [
            InlineKeyboardButton("⚡ Быстрый план", callback_data="lesson_quick"),
            InlineKeyboardButton("🎯 Детальный план", callback_data="lesson_detailed")
        ],
        [
            InlineKeyboardButton("📋 Шаблоны планов", callback_data="lesson_templates")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = """📚 *Создание плана урока*

Выберите тип плана:
⚡ *Быстрый план* - укажите только тему и уровень
🎯 *Детальный план* - полная настройка урока
📋 *Шаблоны* - готовые шаблоны планов"""
    
    await bot_context.send_message(message, reply_markup=reply_markup)


async def grammar_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /grammar"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    keyboard = [
        [
            InlineKeyboardButton("📋 Примеры текстов", callback_data="grammar_examples"),
            InlineKeyboardButton("📚 Правила грамматики", callback_data="grammar_rules")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = """📝 *Проверка грамматики*

Отправьте мне английский текст, и я:
✅ Найду и исправлю ошибки
📖 Объясню правила грамматики
💡 Дам советы по улучшению

Вы можете отправить:
• Предложение или абзац
• Эссе или письмо
• Упражнение для проверки

*Пример:*
`I am go to school yesterday`"""
    
    await bot_context.send_message(message, reply_markup=reply_markup)
    
    # Устанавливаем сессию ожидания текста
    await bot_context.set_session({
        "waiting_for": "grammar_text",
        "flow": "grammar_check"
    })


async def quiz_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /quiz"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    keyboard = [
        [
            InlineKeyboardButton("📝 Множественный выбор", callback_data="quiz_multiple_choice"),
            InlineKeyboardButton("✏️ Заполнить пропуски", callback_data="quiz_fill_blanks")
        ],
        [
            InlineKeyboardButton("🔄 Перевод", callback_data="quiz_translation"),
            InlineKeyboardButton("🎯 Сопоставление", callback_data="quiz_matching")
        ],
        [
            InlineKeyboardButton("📚 Словарный запас", callback_data="quiz_vocabulary"),
            InlineKeyboardButton("⚡ Быстрая викторина", callback_data="quiz_quick")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = """🧩 *Создание викторины*

Я помогу вам создать викторину или упражнения для учеников!

Выберите тип викторины:"""
    
    await bot_context.send_message(message, reply_markup=reply_markup)


async def translate_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /translate"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    keyboard = [
        [
            InlineKeyboardButton("🇷🇺➡️🇺🇸 Русский → Английский", callback_data="translate_ru_en"),
            InlineKeyboardButton("🇺🇸➡️🇷🇺 Английский → Русский", callback_data="translate_en_ru")
        ],
        [
            InlineKeyboardButton("🔊 Произношение", callback_data="pronunciation_help"),
            InlineKeyboardButton("📚 Изучить фразы", callback_data="useful_phrases")
        ]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    message = """🔄 *Перевод и произношение*

Выберите, что вы хотите сделать:"""
    
    await bot_context.send_message(message, reply_markup=reply_markup)


async def pronunciation_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /pronunciation"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    message = """🔊 *Помощь с произношением*

Отправьте английское слово или фразу, и я объясню произношение с транскрипцией и советами."""
    
    await bot_context.send_message(message)
    
    # Устанавливаем сессию ожидания текста
    await bot_context.set_session({
        "waiting_for": "pronunciation_text",
        "flow": "pronunciation"
    })


async def progress_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /progress"""
    bot_context = BotContext(update, context)
    await bot_context.load_user_data()
    
    try:
        # Получаем статистику пользователя
        stats = activity_repo.get_user_stats(bot_context.user.id)
        
        activity_counts = stats.get('activity_counts', {})
        total_activities = sum(activity_counts.values())
        daily_activity = stats.get('daily_activity', [])
        
        # Определяем уровень пользователя
        level = "Новичок"
        next_level_progress = 0
        
        if total_activities >= 100:
            level = "Эксперт"
        elif total_activities >= 50:
            level = "Продвинутый"
        elif total_activities >= 20:
            level = "Опытный"
        elif total_activities >= 5:
            level = "Начинающий"
        
        next_level_progress = min(100, (total_activities % 20) * 5)
        
        activity_labels = {
            ActivityType.LESSON_PLAN: "📖 Планы уроков",
            ActivityType.GRAMMAR_CHECK: "📝 Проверки грамматики",
            ActivityType.QUIZ: "🧩 Викторины",
            ActivityType.TRANSLATION: "🔄 Переводы",
            ActivityType.PRONUNCIATION: "🔊 Произношение",
            ActivityType.VOCABULARY: "📚 Словарь"
        }
        
        message = f"""📊 *Ваш прогресс в изучении английского*

👤 *Пользователь:* {bot_context.user.first_name or 'Пользователь'}
🏆 *Уровень:* {level}
📈 *Прогресс до следующего уровня:* {next_level_progress}%
📅 *Активных дней:* {len(daily_activity)}
🎯 *Всего активностей:* {total_activities}

📚 *Статистика по активностям:*"""
        
        for activity_type, count in activity_counts.items():
            label = activity_labels.get(activity_type, activity_type)
            message += f"\n• {label}: {count}"
        
        # Рекомендации
        message += "\n\n💡 *Рекомендации:*"
        
        if activity_counts.get(ActivityType.LESSON_PLAN, 0) < 5:
            message += "\n• Создайте больше планов уроков для структурированного обучения"
        
        if activity_counts.get(ActivityType.GRAMMAR_CHECK, 0) < 10:
            message += "\n• Проверяйте грамматику чаще для улучшения письменной речи"
        
        if activity_counts.get(ActivityType.PRONUNCIATION, 0) < 5:
            message += "\n• Изучайте произношение для улучшения устной речи"
        
        if len(daily_activity) < 7:
            message += "\n• Занимайтесь регулярно для лучших результатов"
        
        await bot_context.send_message(message)
        
    except Exception as e:
        handlers_logger.error(f"Ошибка получения прогресса: {e}")
        await bot_context.send_message("❌ Ошибка при получении статистики прогресса")


async def settings_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Обработчик команды /settings"""
    bot_context = BotContext(update, context)
    
    keyboard = [
        [InlineKeyboardButton("🌍 Язык интерфейса", callback_data="settings_language")],
        [InlineKeyboardButton("🎯 Уровень по умолчанию", callback_data="settings_level")],
        [InlineKeyboardButton("⚙️ Сбросить настройки", callback_data="settings_reset")]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await bot_context.send_message("⚙️ Настройки бота:", reply_markup=reply_markup)


def setup_command_handlers(application):
    """Настраивает обработчики команд"""
    handlers_logger.info("Настройка обработчиков команд...")
    
    # Основные команды
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("lesson", lesson_command))
    application.add_handler(CommandHandler("grammar", grammar_command))
    application.add_handler(CommandHandler("quiz", quiz_command))
    application.add_handler(CommandHandler("translate", translate_command))
    application.add_handler(CommandHandler("pronunciation", pronunciation_command))
    application.add_handler(CommandHandler("progress", progress_command))
    application.add_handler(CommandHandler("settings", settings_command))
    
    handlers_logger.info("Обработчики команд настроены")