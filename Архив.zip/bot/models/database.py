"""
Модели базы данных для English Teacher Bot
"""

import sqlite3
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass

from bot.config.settings import config
from bot.utils.logger import models_logger


@dataclass
class User:
    """Модель пользователя"""
    id: Optional[int] = None
    telegram_id: int = 0
    username: Optional[str] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    language_code: str = "ru"
    is_teacher: bool = False
    created_at: Optional[datetime] = None
    last_activity: Optional[datetime] = None


@dataclass
class UserSession:
    """Модель сессии пользователя"""
    id: Optional[int] = None
    user_id: int = 0
    session_data: Dict[str, Any] = None
    expires_at: Optional[datetime] = None
    created_at: Optional[datetime] = None


@dataclass
class LessonPlan:
    """Модель плана урока"""
    id: Optional[int] = None
    user_id: int = 0
    title: str = ""
    content: str = ""
    level: str = ""
    duration: int = 45
    topic: str = ""
    created_at: Optional[datetime] = None


@dataclass
class GrammarCheck:
    """Модель проверки грамматики"""
    id: Optional[int] = None
    user_id: int = 0
    original_text: str = ""
    corrected_text: str = ""
    explanation: str = ""
    created_at: Optional[datetime] = None


@dataclass
class Quiz:
    """Модель викторины"""
    id: Optional[int] = None
    user_id: int = 0
    title: str = ""
    questions: str = ""  # JSON строка
    topic: str = ""
    difficulty: str = ""
    created_at: Optional[datetime] = None


@dataclass
class UserProgress:
    """Модель прогресса пользователя"""
    id: Optional[int] = None
    user_id: int = 0
    activity_type: str = ""
    activity_data: Dict[str, Any] = None
    score: Optional[int] = None
    created_at: Optional[datetime] = None


class DatabaseManager:
    """Менеджер базы данных"""
    
    def __init__(self, db_path: str = None):
        self.db_path = db_path or config.DATABASE_URL
        self._ensure_directory()
        self._init_database()
    
    def _ensure_directory(self):
        """Создает директорию для базы данных"""
        db_dir = Path(self.db_path).parent
        db_dir.mkdir(parents=True, exist_ok=True)
    
    def _get_connection(self) -> sqlite3.Connection:
        """Получает соединение с базой данных"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row  # Для доступа к колонкам по имени
        return conn
    
    def _init_database(self):
        """Инициализирует базу данных и создает таблицы"""
        models_logger.info(f"Инициализация базы данных: {self.db_path}")
        
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Создаем таблицы
            self._create_users_table(cursor)
            self._create_sessions_table(cursor)
            self._create_lesson_plans_table(cursor)
            self._create_grammar_checks_table(cursor)
            self._create_quizzes_table(cursor)
            self._create_user_progress_table(cursor)
            
            conn.commit()
            models_logger.info("База данных инициализирована успешно")
    
    def _create_users_table(self, cursor: sqlite3.Cursor):
        """Создает таблицу пользователей"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                telegram_id INTEGER UNIQUE NOT NULL,
                username TEXT,
                first_name TEXT,
                last_name TEXT,
                language_code TEXT DEFAULT 'ru',
                is_teacher BOOLEAN DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_activity TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Создаем индексы
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id)")
    
    def _create_sessions_table(self, cursor: sqlite3.Cursor):
        """Создает таблицу сессий"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                session_data TEXT,
                expires_at TIMESTAMP,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON user_sessions(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_sessions_expires ON user_sessions(expires_at)")
    
    def _create_lesson_plans_table(self, cursor: sqlite3.Cursor):
        """Создает таблицу планов уроков"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS lesson_plans (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                level TEXT,
                duration INTEGER DEFAULT 45,
                topic TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_lesson_plans_user_id ON lesson_plans(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_lesson_plans_topic ON lesson_plans(topic)")
    
    def _create_grammar_checks_table(self, cursor: sqlite3.Cursor):
        """Создает таблицу проверок грамматики"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS grammar_checks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                original_text TEXT NOT NULL,
                corrected_text TEXT,
                explanation TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_grammar_checks_user_id ON grammar_checks(user_id)")
    
    def _create_quizzes_table(self, cursor: sqlite3.Cursor):
        """Создает таблицу викторин"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS quizzes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                questions TEXT NOT NULL,
                topic TEXT,
                difficulty TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_quizzes_user_id ON quizzes(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_quizzes_topic ON quizzes(topic)")
    
    def _create_user_progress_table(self, cursor: sqlite3.Cursor):
        """Создает таблицу прогресса пользователей"""
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS user_progress (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                activity_type TEXT NOT NULL,
                activity_data TEXT,
                score INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        """)
        
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_progress_user_id ON user_progress(user_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_progress_activity_type ON user_progress(activity_type)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_progress_created_at ON user_progress(created_at)")


class UserRepository:
    """Репозиторий для работы с пользователями"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
    
    def find_or_create_user(self, telegram_user) -> User:
        """Находит или создает пользователя по данным Telegram"""
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            
            # Ищем существующего пользователя
            cursor.execute("SELECT * FROM users WHERE telegram_id = ?", (telegram_user.id,))
            row = cursor.fetchone()
            
            if row:
                # Обновляем время последней активности
                cursor.execute(
                    "UPDATE users SET last_activity = CURRENT_TIMESTAMP WHERE id = ?",
                    (row['id'],)
                )
                conn.commit()
                
                return User(
                    id=row['id'],
                    telegram_id=row['telegram_id'],
                    username=row['username'],
                    first_name=row['first_name'],
                    last_name=row['last_name'],
                    language_code=row['language_code'],
                    is_teacher=bool(row['is_teacher']),
                    created_at=datetime.fromisoformat(row['created_at']) if row['created_at'] else None,
                    last_activity=datetime.fromisoformat(row['last_activity']) if row['last_activity'] else None
                )
            else:
                # Создаем нового пользователя
                cursor.execute("""
                    INSERT INTO users (telegram_id, username, first_name, last_name, language_code)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    telegram_user.id,
                    getattr(telegram_user, 'username', None),
                    getattr(telegram_user, 'first_name', None),
                    getattr(telegram_user, 'last_name', None),
                    getattr(telegram_user, 'language_code', 'ru')
                ))
                
                user_id = cursor.lastrowid
                conn.commit()
                
                models_logger.info(f"Создан новый пользователь: {user_id} ({telegram_user.id})")
                
                return User(
                    id=user_id,
                    telegram_id=telegram_user.id,
                    username=getattr(telegram_user, 'username', None),
                    first_name=getattr(telegram_user, 'first_name', None),
                    last_name=getattr(telegram_user, 'last_name', None),
                    language_code=getattr(telegram_user, 'language_code', 'ru'),
                    is_teacher=False,
                    created_at=datetime.now(),
                    last_activity=datetime.now()
                )
    
    def update_user(self, user_id: int, **updates) -> bool:
        """Обновляет данные пользователя"""
        if not updates:
            return False
        
        fields = []
        values = []
        
        for field, value in updates.items():
            fields.append(f"{field} = ?")
            values.append(value)
        
        values.append(user_id)
        
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                f"UPDATE users SET {', '.join(fields)} WHERE id = ?",
                values
            )
            conn.commit()
            return cursor.rowcount > 0


class SessionRepository:
    """Репозиторий для работы с сессиями"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
    
    def get_session(self, user_id: int) -> Optional[Dict[str, Any]]:
        """Получает активную сессию пользователя"""
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT session_data FROM user_sessions 
                WHERE user_id = ? AND expires_at > CURRENT_TIMESTAMP
                ORDER BY created_at DESC LIMIT 1
            """, (user_id,))
            
            row = cursor.fetchone()
            if row and row['session_data']:
                try:
                    return json.loads(row['session_data'])
                except json.JSONDecodeError:
                    models_logger.error(f"Ошибка парсинга сессии для пользователя {user_id}")
                    return None
            return None
    
    def set_session(self, user_id: int, session_data: Dict[str, Any], 
                   expires_in: int = None) -> bool:
        """Устанавливает сессию пользователя"""
        expires_in = expires_in or config.SESSION_TIMEOUT
        expires_at = datetime.now() + timedelta(seconds=expires_in)
        
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            
            # Удаляем старые сессии
            cursor.execute("DELETE FROM user_sessions WHERE user_id = ?", (user_id,))
            
            # Создаем новую сессию
            cursor.execute("""
                INSERT INTO user_sessions (user_id, session_data, expires_at)
                VALUES (?, ?, ?)
            """, (user_id, json.dumps(session_data), expires_at.isoformat()))
            
            conn.commit()
            return True
    
    def clear_session(self, user_id: int) -> bool:
        """Очищает сессию пользователя"""
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM user_sessions WHERE user_id = ?", (user_id,))
            conn.commit()
            return cursor.rowcount > 0
    
    def cleanup_expired_sessions(self):
        """Удаляет истекшие сессии"""
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM user_sessions WHERE expires_at <= CURRENT_TIMESTAMP")
            deleted_count = cursor.rowcount
            conn.commit()
            
            if deleted_count > 0:
                models_logger.info(f"Удалено {deleted_count} истекших сессий")


class ActivityRepository:
    """Репозиторий для работы с активностью пользователей"""
    
    def __init__(self, db_manager: DatabaseManager):
        self.db = db_manager
    
    def track_activity(self, user_id: int, activity_type: str, 
                      activity_data: Dict[str, Any] = None, score: int = None) -> int:
        """Записывает активность пользователя"""
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO user_progress (user_id, activity_type, activity_data, score)
                VALUES (?, ?, ?, ?)
            """, (
                user_id,
                activity_type,
                json.dumps(activity_data) if activity_data else None,
                score
            ))
            
            activity_id = cursor.lastrowid
            conn.commit()
            return activity_id
    
    def get_user_stats(self, user_id: int) -> Dict[str, Any]:
        """Получает статистику пользователя"""
        with self.db._get_connection() as conn:
            cursor = conn.cursor()
            
            # Подсчет активностей по типам
            cursor.execute("""
                SELECT activity_type, COUNT(*) as count
                FROM user_progress
                WHERE user_id = ?
                GROUP BY activity_type
            """, (user_id,))
            
            activity_counts = {row['activity_type']: row['count'] for row in cursor.fetchall()}
            
            # Активность по дням (последние 30 дней)
            cursor.execute("""
                SELECT DATE(created_at) as date, COUNT(*) as count
                FROM user_progress
                WHERE user_id = ? AND created_at >= date('now', '-30 days')
                GROUP BY DATE(created_at)
                ORDER BY date
            """, (user_id,))
            
            daily_activity = [
                {'date': row['date'], 'count': row['count']}
                for row in cursor.fetchall()
            ]
            
            # Последние активности
            cursor.execute("""
                SELECT activity_type, activity_data, score, created_at
                FROM user_progress
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT 10
            """, (user_id,))
            
            recent_activities = []
            for row in cursor.fetchall():
                activity_data = None
                if row['activity_data']:
                    try:
                        activity_data = json.loads(row['activity_data'])
                    except json.JSONDecodeError:
                        pass
                
                recent_activities.append({
                    'activity_type': row['activity_type'],
                    'activity_data': activity_data,
                    'score': row['score'],
                    'created_at': row['created_at']
                })
            
            return {
                'activity_counts': activity_counts,
                'daily_activity': daily_activity,
                'recent_activities': recent_activities
            }


# Глобальные экземпляры
db_manager = DatabaseManager()
user_repo = UserRepository(db_manager)
session_repo = SessionRepository(db_manager)
activity_repo = ActivityRepository(db_manager)


# Константы для типов активности
class ActivityType:
    LESSON_PLAN = "lesson_plan"
    GRAMMAR_CHECK = "grammar_check"
    QUIZ = "quiz"
    TRANSLATION = "translation"
    PRONUNCIATION = "pronunciation"
    VOCABULARY = "vocabulary"
    DIALOGUE = "dialogue"