"""
English Teacher Telegram Bot
==========================

Telegram бот для учителей английского языка в России с интеграцией GPT.

Основные модули:
- config: Конфигурация приложения
- handlers: Обработчики команд и сообщений
- models: Модели данных и база данных
- services: Сервисы (GPT, аналитика)
- utils: Утилиты и вспомогательные функции
"""

__version__ = "2.0.0"
__author__ = "English Teacher Bot Team"
__description__ = "Telegram бот для учителей английского языка"