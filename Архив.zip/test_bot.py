#!/usr/bin/env python3
"""
Простой тест для проверки работы English Teacher Bot
"""

import sys
from pathlib import Path

# Добавляем путь к проекту
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

def test_imports():
    """Тестирует импорты основных модулей"""
    try:
        from bot.config.settings import config, Messages
        print("✅ Конфигурация загружена")
        
        from bot.utils.logger import main_logger
        print("✅ Логгер инициализирован")
        
        from bot.models.database import db_manager, user_repo
        print("✅ База данных готова")
        
        from bot.services.gpt_service import gpt_service
        print("✅ GPT сервис загружен")
        
        return True
    except Exception as e:
        print(f"❌ Ошибка импорта: {e}")
        return False


def test_config():
    """Тестирует конфигурацию"""
    try:
        from bot.config.settings import config
        
        # Базовые проверки
        assert hasattr(config, 'TELEGRAM_BOT_TOKEN')
        assert hasattr(config, 'OPENAI_API_KEY')
        assert hasattr(config, 'PORT')
        
        print("✅ Структура конфигурации корректна")
        return True
    except Exception as e:
        print(f"❌ Ошибка конфигурации: {e}")
        return False


def test_database():
    """Тестирует базу данных"""
    try:
        from bot.models.database import db_manager
        
        # Проверяем, что база данных инициализирована
        print("✅ База данных инициализирована")
        return True
    except Exception as e:
        print(f"❌ Ошибка базы данных: {e}")
        return False


def main():
    """Основная функция тестирования"""
    print("🧪 Тестирование English Teacher Telegram Bot (Python)")
    print("=" * 55)
    
    tests = [
        ("Импорты модулей", test_imports),
        ("Конфигурация", test_config),
        ("База данных", test_database),
    ]
    
    passed = 0
    total = len(tests)
    
    for test_name, test_func in tests:
        print(f"\n🔍 Тест: {test_name}")
        if test_func():
            passed += 1
        else:
            print(f"   Тест '{test_name}' провален")
    
    print("\n" + "=" * 55)
    print(f"📊 Результаты: {passed}/{total} тестов прошли")
    
    if passed == total:
        print("🎉 Все тесты пройдены! Бот готов к работе.")
        print("\n💡 Следующие шаги:")
        print("1. Настройте .env файл с вашими API ключами")
        print("2. Запустите: python main.py")
    else:
        print("⚠️ Некоторые тесты провалились. Проверьте установку.")
    
    return passed == total


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)