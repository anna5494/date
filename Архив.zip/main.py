#!/usr/bin/env python3
"""
English Teacher Telegram Bot - Main Entry Point
==============================================

Главная точка входа для запуска бота.
"""

import asyncio
import sys
from pathlib import Path

# Добавляем путь к проекту в sys.path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from bot.main_bot import create_bot
from bot.utils.logger import main_logger, log_error
from bot.config.settings import config


async def main():
    """Главная функция запуска бота"""
    bot = None
    try:
        main_logger.info("🚀 Запуск English Teacher Telegram Bot...")
        
        # Создаем и инициализируем бота
        bot = await create_bot()
        
        # Запускаем бота
        await bot.start()
        
        # Ожидаем завершения (бесконечный цикл)
        if not config.is_production():
            # В режиме разработки ждем сигнал остановки
            try:
                while bot.is_running:
                    await asyncio.sleep(1)
            except KeyboardInterrupt:
                main_logger.info("Получен сигнал остановки от пользователя")
        
    except KeyboardInterrupt:
        main_logger.info("Получен сигнал остановки (Ctrl+C)")
    except Exception as e:
        log_error(e, "главная функция")
        sys.exit(1)
    finally:
        if bot is not None:
            await bot.stop()


def run_bot():
    """Синхронная обертка для запуска бота"""
    try:
        # Запускаем основную асинхронную функцию
        asyncio.run(main())
    except KeyboardInterrupt:
        main_logger.info("Бот остановлен пользователем")
    except Exception as e:
        main_logger.error(f"Критическая ошибка: {e}")
        sys.exit(1)


if __name__ == "__main__":
    run_bot()