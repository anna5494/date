#!/bin/bash

# English Teacher Telegram Bot - Setup Script
echo "🤖 Setting up English Teacher Telegram Bot..."

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js is not installed. Please install Node.js first:"
    echo "   macOS: brew install node"
    echo "   Ubuntu: sudo apt install nodejs npm"
    echo "   Visit: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js found: $(node --version)"

# Check if npm is available
if ! command -v npm &> /dev/null; then
    echo "❌ npm is not installed. Please install npm."
    exit 1
fi

echo "✅ npm found: $(npm --version)"

# Install dependencies
echo "📦 Installing dependencies..."
npm install

if [ $? -ne 0 ]; then
    echo "❌ Failed to install dependencies"
    exit 1
fi

echo "✅ Dependencies installed successfully"

# Create .env file if it doesn't exist
if [ ! -f .env ]; then
    echo "⚙️ Creating .env file..."
    cp .env.example .env
    echo "✅ .env file created. Please edit it with your API keys:"
    echo "   - TELEGRAM_BOT_TOKEN (get from @BotFather)"
    echo "   - OPENAI_API_KEY (get from OpenAI)"
else
    echo "✅ .env file already exists"
fi

# Create data directory
mkdir -p data
mkdir -p logs

echo "📁 Directories created"

echo ""
echo "🎉 Setup completed successfully!"
echo ""
echo "Next steps:"
echo "1. Edit .env file with your API keys"
echo "2. Run 'npm run dev' to start in development mode"
echo "3. Run 'npm start' to start in production mode"
echo ""
echo "Need help? Check README.md for detailed instructions."