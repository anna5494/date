require('dotenv').config();

const config = {
  // Telegram Bot Configuration
  telegram: {
    botToken: process.env.TELEGRAM_BOT_TOKEN,
    webhookUrl: process.env.TELEGRAM_WEBHOOK_URL,
    botUsername: process.env.BOT_USERNAME,
    adminChatId: process.env.ADMIN_CHAT_ID,
  },

  // OpenAI Configuration
  openai: {
    apiKey: process.env.OPENAI_API_KEY,
    model: 'gpt-3.5-turbo',
    maxTokens: 1000,
    temperature: 0.7,
  },

  // Server Configuration
  server: {
    port: process.env.PORT || 3000,
    nodeEnv: process.env.NODE_ENV || 'development',
  },

  // Database Configuration
  database: {
    url: process.env.DATABASE_URL || './data/bot.db',
  },

  // Language Configuration
  language: {
    default: process.env.DEFAULT_LANGUAGE || 'ru',
    supported: (process.env.SUPPORTED_LANGUAGES || 'ru,en').split(','),
  },

  // Bot Features Configuration
  features: {
    maxLessonPlanLength: 2000,
    maxExerciseQuestions: 10,
    sessionTimeout: 3600000, // 1 hour in milliseconds
    maxTranslationLength: 500,
  },

  // Rate Limiting
  rateLimiting: {
    maxRequestsPerMinute: 20,
    maxRequestsPerHour: 100,
  },
};

// Validation function
function validateConfig() {
  const required = [
    'telegram.botToken',
    'openai.apiKey',
  ];

  const missing = required.filter(path => {
    const value = path.split('.').reduce((obj, key) => obj?.[key], config);
    return !value;
  });

  if (missing.length > 0) {
    throw new Error(`Missing required configuration: ${missing.join(', ')}`);
  }
}

module.exports = {
  config,
  validateConfig,
};