const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const { config } = require('../config');
const { logger } = require('../utils/logger');

let db = null;

const initDatabase = async () => {
  return new Promise((resolve, reject) => {
    const dbPath = path.resolve(config.database.url);
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    const fs = require('fs');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    db = new sqlite3.Database(dbPath, (err) => {
      if (err) {
        logger.error('Error opening database:', err);
        reject(err);
        return;
      }

      logger.info('Connected to SQLite database');
      createTables()
        .then(resolve)
        .catch(reject);
    });
  });
};

const createTables = async () => {
  return new Promise((resolve, reject) => {
    const tables = [
      // Users table
      `CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        telegram_id INTEGER UNIQUE NOT NULL,
        username TEXT,
        first_name TEXT,
        last_name TEXT,
        language_code TEXT DEFAULT 'ru',
        is_teacher BOOLEAN DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        last_activity DATETIME DEFAULT CURRENT_TIMESTAMP
      )`,
      
      // User sessions table
      `CREATE TABLE IF NOT EXISTS user_sessions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        session_data TEXT,
        expires_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )`,
      
      // Lesson plans table
      `CREATE TABLE IF NOT EXISTS lesson_plans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        content TEXT NOT NULL,
        level TEXT,
        duration INTEGER,
        topic TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )`,
      
      // Grammar checks table
      `CREATE TABLE IF NOT EXISTS grammar_checks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        original_text TEXT NOT NULL,
        corrected_text TEXT,
        explanation TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )`,
      
      // Quizzes table
      `CREATE TABLE IF NOT EXISTS quizzes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        questions TEXT NOT NULL,
        topic TEXT,
        difficulty TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )`,
      
      // User progress table
      `CREATE TABLE IF NOT EXISTS user_progress (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        activity_type TEXT NOT NULL,
        activity_data TEXT,
        score INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id)
      )`
    ];

    let completed = 0;
    tables.forEach((sql) => {
      db.run(sql, (err) => {
        if (err) {
          logger.error('Error creating table:', err);
          reject(err);
          return;
        }
        
        completed++;
        if (completed === tables.length) {
          logger.info('All database tables created successfully');
          resolve();
        }
      });
    });
  });
};

const getDatabase = () => {
  if (!db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return db;
};

// User operations
const userOperations = {
  async findOrCreate(telegramUser) {
    return new Promise((resolve, reject) => {
      const { id, username, first_name, last_name, language_code } = telegramUser;
      
      db.get(
        'SELECT * FROM users WHERE telegram_id = ?',
        [id],
        (err, row) => {
          if (err) {
            reject(err);
            return;
          }
          
          if (row) {
            // Update last activity
            db.run(
              'UPDATE users SET last_activity = CURRENT_TIMESTAMP WHERE id = ?',
              [row.id]
            );
            resolve(row);
          } else {
            // Create new user
            db.run(
              `INSERT INTO users (telegram_id, username, first_name, last_name, language_code) 
               VALUES (?, ?, ?, ?, ?)`,
              [id, username, first_name, last_name, language_code || 'ru'],
              function(err) {
                if (err) {
                  reject(err);
                  return;
                }
                
                db.get(
                  'SELECT * FROM users WHERE id = ?',
                  [this.lastID],
                  (err, newRow) => {
                    if (err) reject(err);
                    else resolve(newRow);
                  }
                );
              }
            );
          }
        }
      );
    });
  },

  async updateUser(userId, updates) {
    return new Promise((resolve, reject) => {
      const fields = Object.keys(updates).map(key => `${key} = ?`).join(', ');
      const values = Object.values(updates);
      
      db.run(
        `UPDATE users SET ${fields} WHERE id = ?`,
        [...values, userId],
        function(err) {
          if (err) reject(err);
          else resolve(this.changes > 0);
        }
      );
    });
  }
};

// Session operations
const sessionOperations = {
  async getSession(userId) {
    return new Promise((resolve, reject) => {
      db.get(
        'SELECT * FROM user_sessions WHERE user_id = ? AND expires_at > CURRENT_TIMESTAMP',
        [userId],
        (err, row) => {
          if (err) reject(err);
          else resolve(row ? JSON.parse(row.session_data) : null);
        }
      );
    });
  },

  async setSession(userId, sessionData, expiresIn = 3600000) {
    return new Promise((resolve, reject) => {
      const expiresAt = new Date(Date.now() + expiresIn).toISOString();
      
      db.run(
        `INSERT OR REPLACE INTO user_sessions (user_id, session_data, expires_at) 
         VALUES (?, ?, ?)`,
        [userId, JSON.stringify(sessionData), expiresAt],
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });
  },

  async clearSession(userId) {
    return new Promise((resolve, reject) => {
      db.run(
        'DELETE FROM user_sessions WHERE user_id = ?',
        [userId],
        (err) => {
          if (err) reject(err);
          else resolve();
        }
      );
    });
  }
};

module.exports = {
  initDatabase,
  getDatabase,
  userOperations,
  sessionOperations
};