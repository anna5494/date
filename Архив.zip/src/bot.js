const TelegramBot = require('node-telegram-bot-api');
const express = require('express');
const { config, validateConfig } = require('./config');
const { setupHandlers } = require('./handlers');
const { initDatabase } = require('./models/database');
const { logger } = require('./utils/logger');

class EnglishTeacherBot {
  constructor() {
    this.bot = null;
    this.app = null;
    this.isRunning = false;
  }

  async initialize() {
    try {
      // Validate configuration
      validateConfig();
      
      // Initialize database
      await initDatabase();
      
      // Create bot instance
      this.bot = new TelegramBot(config.telegram.botToken, {
        polling: config.server.nodeEnv === 'development',
        webHook: config.server.nodeEnv === 'production'
      });

      // Setup Express app for webhooks
      this.app = express();
      this.app.use(express.json());

      // Setup webhook endpoint
      if (config.server.nodeEnv === 'production') {
        this.app.post(`/webhook/${config.telegram.botToken}`, (req, res) => {
          this.bot.processUpdate(req.body);
          res.sendStatus(200);
        });

        // Set webhook
        await this.bot.setWebHook(`${config.telegram.webhookUrl}/webhook/${config.telegram.botToken}`);
      }

      // Setup bot handlers
      setupHandlers(this.bot);

      logger.info('Bot initialized successfully');
      return this;
    } catch (error) {
      logger.error('Failed to initialize bot:', error);
      throw error;
    }
  }

  async start() {
    if (this.isRunning) {
      logger.warn('Bot is already running');
      return;
    }

    try {
      // Start Express server
      this.app.listen(config.server.port, () => {
        logger.info(`Server running on port ${config.server.port}`);
      });

      // Set bot commands
      await this.setupCommands();

      this.isRunning = true;
      logger.info('English Teacher Bot started successfully');

      // Handle graceful shutdown
      process.on('SIGINT', () => this.stop());
      process.on('SIGTERM', () => this.stop());

    } catch (error) {
      logger.error('Failed to start bot:', error);
      throw error;
    }
  }

  async setupCommands() {
    const commands = [
      { command: 'start', description: '🚀 Начать работу с ботом' },
      { command: 'help', description: '❓ Получить помощь' },
      { command: 'lesson', description: '📚 Создать план урока' },
      { command: 'grammar', description: '📝 Проверить грамматику' },
      { command: 'quiz', description: '🧩 Создать викторину' },
      { command: 'translate', description: '🔄 Перевести текст' },
      { command: 'pronunciation', description: '🔊 Помощь с произношением' },
      { command: 'progress', description: '📊 Посмотреть прогресс' },
      { command: 'settings', description: '⚙️ Настройки' }
    ];

    await this.bot.setMyCommands(commands);
    logger.info('Bot commands set successfully');
  }

  async stop() {
    if (!this.isRunning) {
      return;
    }

    try {
      if (config.server.nodeEnv === 'production') {
        await this.bot.deleteWebHook();
      }
      
      this.isRunning = false;
      logger.info('Bot stopped successfully');
      process.exit(0);
    } catch (error) {
      logger.error('Error stopping bot:', error);
      process.exit(1);
    }
  }

  getBotInstance() {
    return this.bot;
  }
}

module.exports = EnglishTeacherBot;