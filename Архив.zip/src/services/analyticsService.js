const { getDatabase } = require('../models/database');
const { logger } = require('../utils/logger');

class AnalyticsService {
  constructor() {
    this.db = null;
  }

  getDb() {
    if (!this.db) {
      this.db = getDatabase();
    }
    return this.db;
  }

  async trackActivity(userId, activityType, activityData = {}, score = null) {
    return new Promise((resolve, reject) => {
      const db = this.getDb();
      
      db.run(
        `INSERT INTO user_progress (user_id, activity_type, activity_data, score) 
         VALUES (?, ?, ?, ?)`,
        [userId, activityType, JSON.stringify(activityData), score],
        function(err) {
          if (err) {
            logger.error('Error tracking activity:', err);
            reject(err);
          } else {
            resolve(this.lastID);
          }
        }
      );
    });
  }

  async getUserStats(userId) {
    return new Promise((resolve, reject) => {
      const db = this.getDb();
      
      const queries = [
        // Total activities
        `SELECT activity_type, COUNT(*) as count 
         FROM user_progress 
         WHERE user_id = ? 
         GROUP BY activity_type`,
        
        // Activities by date
        `SELECT DATE(created_at) as date, COUNT(*) as count 
         FROM user_progress 
         WHERE user_id = ? AND created_at >= date('now', '-30 days')
         GROUP BY DATE(created_at) 
         ORDER BY date`,
         
        // Recent activities
        `SELECT activity_type, activity_data, score, created_at 
         FROM user_progress 
         WHERE user_id = ? 
         ORDER BY created_at DESC 
         LIMIT 10`,
         
        // User info
        `SELECT * FROM users WHERE id = ?`
      ];

      const results = {};
      let completed = 0;

      // Activity counts
      db.all(queries[0], [userId], (err, rows) => {
        if (err) {
          reject(err);
          return;
        }
        
        results.activityCounts = {};
        rows.forEach(row => {
          results.activityCounts[row.activity_type] = row.count;
        });
        
        completed++;
        if (completed === 4) resolve(results);
      });

      // Daily activities
      db.all(queries[1], [userId], (err, rows) => {
        if (err) {
          reject(err);
          return;
        }
        
        results.dailyActivity = rows;
        
        completed++;
        if (completed === 4) resolve(results);
      });

      // Recent activities
      db.all(queries[2], [userId], (err, rows) => {
        if (err) {
          reject(err);
          return;
        }
        
        results.recentActivities = rows.map(row => ({
          ...row,
          activity_data: JSON.parse(row.activity_data || '{}')
        }));
        
        completed++;
        if (completed === 4) resolve(results);
      });

      // User info
      db.get(queries[3], [userId], (err, row) => {
        if (err) {
          reject(err);
          return;
        }
        
        results.userInfo = row;
        
        completed++;
        if (completed === 4) resolve(results);
      });
    });
  }

  async getGlobalStats() {
    return new Promise((resolve, reject) => {
      const db = this.getDb();
      
      const queries = [
        // Total users
        `SELECT COUNT(*) as total_users FROM users`,
        
        // Active users (last 7 days)
        `SELECT COUNT(DISTINCT user_id) as active_users 
         FROM user_progress 
         WHERE created_at >= date('now', '-7 days')`,
         
        // Total activities
        `SELECT activity_type, COUNT(*) as count 
         FROM user_progress 
         GROUP BY activity_type`,
         
        // Activities by day (last 30 days)
        `SELECT DATE(created_at) as date, COUNT(*) as count 
         FROM user_progress 
         WHERE created_at >= date('now', '-30 days')
         GROUP BY DATE(created_at) 
         ORDER BY date`
      ];

      const results = {};
      let completed = 0;

      queries.forEach((query, index) => {
        const method = index === 0 || index === 1 ? 'get' : 'all';
        
        db[method](query, [], (err, result) => {
          if (err) {
            reject(err);
            return;
          }
          
          switch (index) {
            case 0:
              results.totalUsers = result.total_users;
              break;
            case 1:
              results.activeUsers = result.active_users;
              break;
            case 2:
              results.activityCounts = {};
              result.forEach(row => {
                results.activityCounts[row.activity_type] = row.count;
              });
              break;
            case 3:
              results.dailyActivities = result;
              break;
          }
          
          completed++;
          if (completed === queries.length) resolve(results);
        });
      });
    });
  }

  async generateProgressReport(userId) {
    try {
      const stats = await this.getUserStats(userId);
      
      const activityCounts = stats.activityCounts || {};
      const recentActivities = stats.recentActivities || [];
      const userInfo = stats.userInfo || {};
      
      const totalActivities = Object.values(activityCounts).reduce((sum, count) => sum + count, 0);
      const daysActive = stats.dailyActivity ? stats.dailyActivity.length : 0;
      
      // Calculate user level based on activity
      let level = 'Новичок';
      let nextLevelProgress = 0;
      
      if (totalActivities >= 100) level = 'Эксперт';
      else if (totalActivities >= 50) level = 'Продвинутый';
      else if (totalActivities >= 20) level = 'Опытный';
      else if (totalActivities >= 5) level = 'Начинающий';
      
      nextLevelProgress = Math.min(100, (totalActivities % 20) * 5);
      
      let report = `📊 *Ваш прогресс в изучении английского*\n\n`;
      report += `👤 *Пользователь:* ${userInfo.first_name || 'Пользователь'}\n`;
      report += `🏆 *Уровень:* ${level}\n`;
      report += `📈 *Прогресс до следующего уровня:* ${nextLevelProgress}%\n`;
      report += `📅 *Активных дней:* ${daysActive}\n`;
      report += `🎯 *Всего активностей:* ${totalActivities}\n\n`;
      
      report += `📚 *Статистика по активностям:*\n`;
      
      const activityLabels = {
        'lesson_plan': '📖 Планы уроков',
        'grammar_check': '📝 Проверки грамматики',
        'quiz': '🧩 Викторины',
        'translation': '🔄 Переводы',
        'pronunciation': '🔊 Произношение',
        'vocabulary': '📚 Словарь'
      };
      
      Object.entries(activityCounts).forEach(([type, count]) => {
        const label = activityLabels[type] || type;
        report += `• ${label}: ${count}\n`;
      });
      
      if (recentActivities.length > 0) {
        report += `\n🕐 *Последние активности:*\n`;
        recentActivities.slice(0, 5).forEach(activity => {
          const date = new Date(activity.created_at).toLocaleDateString('ru-RU');
          const label = activityLabels[activity.activity_type] || activity.activity_type;
          report += `• ${date} - ${label}\n`;
        });
      }
      
      // Recommendations
      report += `\n💡 *Рекомендации:*\n`;
      
      if (!activityCounts.lesson_plan || activityCounts.lesson_plan < 5) {
        report += `• Создайте больше планов уроков для структурированного обучения\n`;
      }
      
      if (!activityCounts.grammar_check || activityCounts.grammar_check < 10) {
        report += `• Проверяйте грамматику чаще для улучшения письменной речи\n`;
      }
      
      if (!activityCounts.pronunciation || activityCounts.pronunciation < 5) {
        report += `• Изучайте произношение для улучшения устной речи\n`;
      }
      
      if (daysActive < 7) {
        report += `• Занимайтесь регулярно для лучших результатов\n`;
      }
      
      return report;
      
    } catch (error) {
      logger.error('Error generating progress report:', error);
      throw new Error('Ошибка при создании отчета о прогрессе');
    }
  }

  async getTeacherAnalytics(userId) {
    try {
      const stats = await this.getUserStats(userId);
      const globalStats = await this.getGlobalStats();
      
      let report = `👩‍🏫 *Аналитика для учителя*\n\n`;
      
      // Personal stats
      const lessonPlans = stats.activityCounts.lesson_plan || 0;
      const grammarChecks = stats.activityCounts.grammar_check || 0;
      const quizzes = stats.activityCounts.quiz || 0;
      
      report += `📚 *Ваша активность:*\n`;
      report += `• Планов уроков создано: ${lessonPlans}\n`;
      report += `• Текстов проверено: ${grammarChecks}\n`;
      report += `• Викторин создано: ${quizzes}\n\n`;
      
      // Productivity metrics
      const daysActive = stats.dailyActivity ? stats.dailyActivity.length : 0;
      const avgActivitiesPerDay = daysActive > 0 ? 
        Object.values(stats.activityCounts).reduce((sum, count) => sum + count, 0) / daysActive : 0;
      
      report += `📈 *Продуктивность:*\n`;
      report += `• Активных дней: ${daysActive}\n`;
      report += `• Среднее активностей в день: ${avgActivitiesPerDay.toFixed(1)}\n\n`;
      
      // Most used features
      const sortedActivities = Object.entries(stats.activityCounts)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 3);
      
      if (sortedActivities.length > 0) {
        report += `🏆 *Самые используемые функции:*\n`;
        sortedActivities.forEach(([type, count], index) => {
          const label = {
            'lesson_plan': 'Планы уроков',
            'grammar_check': 'Проверка грамматики',
            'quiz': 'Викторины',
            'translation': 'Переводы',
            'pronunciation': 'Произношение'
          }[type] || type;
          
          report += `${index + 1}. ${label}: ${count}\n`;
        });
        report += '\n';
      }
      
      // Global context
      report += `🌍 *Общая статистика:*\n`;
      report += `• Всего пользователей: ${globalStats.totalUsers || 0}\n`;
      report += `• Активных пользователей (7 дней): ${globalStats.activeUsers || 0}\n\n`;
      
      // Suggestions
      report += `💡 *Рекомендации:*\n`;
      
      if (lessonPlans < 10) {
        report += `• Попробуйте создать планы уроков для разных уровней\n`;
      }
      
      if (quizzes < 5) {
        report += `• Создавайте больше викторин для интерактивного обучения\n`;
      }
      
      if (daysActive < 14) {
        report += `• Используйте бота регулярно для максимальной эффективности\n`;
      }
      
      return report;
      
    } catch (error) {
      logger.error('Error generating teacher analytics:', error);
      throw new Error('Ошибка при создании аналитики');
    }
  }

  // Activity type constants for consistent tracking
  static get ACTIVITY_TYPES() {
    return {
      LESSON_PLAN: 'lesson_plan',
      GRAMMAR_CHECK: 'grammar_check',
      QUIZ: 'quiz',
      TRANSLATION: 'translation',
      PRONUNCIATION: 'pronunciation',
      VOCABULARY: 'vocabulary',
      DIALOGUE: 'dialogue'
    };
  }
}

const analyticsService = new AnalyticsService();
module.exports = { analyticsService, AnalyticsService };