const EnglishTeacherBot = require('./bot');
const { logger } = require('./utils/logger');

async function main() {
  try {
    logger.info('Starting English Teacher Telegram Bot...');
    
    const bot = new EnglishTeacherBot();
    await bot.initialize();
    await bot.start();
    
    logger.info('Bot is running and ready to help English teachers!');
  } catch (error) {
    logger.error('Failed to start the bot:', error);
    process.exit(1);
  }
}

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});

// Start the application
main();