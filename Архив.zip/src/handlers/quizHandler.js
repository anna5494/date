const { gptService } = require('../services/gptService');
const { userOperations, sessionOperations } = require('../models/database');
const { logger } = require('../utils/logger');

class QuizHandler {
  async handle(bot, msg) {
    try {
      const user = await userOperations.findOrCreate(msg.from);
      
      const instructionMessage = `🧩 *Создание викторины*

Я помогу вам создать викторину или упражнения для учеников!

Выберите тип викторины:`;

      await bot.sendMessage(msg.chat.id, instructionMessage, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📝 Множественный выбор', callback_data: 'quiz_multiple_choice' },
              { text: '✏️ Заполнить пропуски', callback_data: 'quiz_fill_blanks' }
            ],
            [
              { text: '🔄 Перевод', callback_data: 'quiz_translation' },
              { text: '🎯 Сопоставление', callback_data: 'quiz_matching' }
            ],
            [
              { text: '📚 Словарный запас', callback_data: 'quiz_vocabulary' },
              { text: '⚡ Быстрая викторина', callback_data: 'quiz_quick' }
            ]
          ]
        }
      });

    } catch (error) {
      logger.error('Error in quiz handler:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при создании викторины');
    }
  }

  async handleCallback(bot, msg, data) {
    try {
      const user = await userOperations.findOrCreate({ id: msg.chat.id });
      
      const quizTypes = {
        'quiz_multiple_choice': 'Множественный выбор',
        'quiz_fill_blanks': 'Заполнение пропусков',
        'quiz_translation': 'Перевод',
        'quiz_matching': 'Сопоставление',
        'quiz_vocabulary': 'Словарный запас'
      };

      if (data === 'quiz_quick') {
        await this.createQuickQuiz(bot, msg, user);
      } else if (quizTypes[data]) {
        await this.startQuizCreation(bot, msg, user, quizTypes[data]);
      }
    } catch (error) {
      logger.error('Error in quiz callback:', error);
    }
  }

  async startQuizCreation(bot, msg, user, quizType) {
    await bot.editMessageText(
      `🧩 *Создание викторины: ${quizType}*

Пожалуйста, укажите:
📚 *Тема:* (например, "Past Simple", "Family", "Food")
🎯 *Уровень:* (A1, A2, B1, B2, C1, C2)
🔢 *Количество вопросов:* (1-20)

*Пример:*
\`Тема: Present Simple
Уровень: A2  
Количество: 5\``,
      {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: 'Markdown'
      }
    );

    await sessionOperations.setSession(user.id, {
      waitingFor: 'quiz_details',
      flow: 'quiz_creation',
      quiz_type: quizType
    });
  }

  async createQuickQuiz(bot, msg, user) {
    await bot.editMessageText(
      `⚡ *Быстрая викторина*

Просто назовите тему, и я создам викторину из 5 вопросов уровня B1:

*Примеры тем:*
• Irregular verbs
• Present Perfect
• Food and drinks  
• Daily routines
• Weather

Напишите тему:`,
      {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: 'Markdown'
      }
    );

    await sessionOperations.setSession(user.id, {
      waitingFor: 'quiz_quick_topic',
      flow: 'quiz_creation'
    });
  }

  async handleTopic(bot, msg, user) {
    try {
      const session = await sessionOperations.getSession(user.id);
      
      if (session?.waitingFor === 'quiz_quick_topic') {
        await this.processQuickQuiz(bot, msg, user);
      } else if (session?.waitingFor === 'quiz_details') {
        await this.processDetailedQuiz(bot, msg, user, session.quiz_type);
      }
    } catch (error) {
      logger.error('Error handling quiz topic:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при обработке темы викторины');
    }
  }

  async processQuickQuiz(bot, msg, user) {
    const topic = msg.text.trim();
    
    if (topic.length < 2) {
      await bot.sendMessage(msg.chat.id, '❌ Тема слишком короткая. Пожалуйста, укажите тему.');
      return;
    }

    await bot.sendMessage(msg.chat.id, '⏳ Создаю быструю викторину...');

    try {
      const quiz = await gptService.createQuiz(topic, 'B1', 5, 'Смешанный');
      await this.sendQuiz(bot, msg.chat.id, quiz, { topic, level: 'B1', count: 5 });
      
      await sessionOperations.clearSession(user.id);
    } catch (error) {
      logger.error('Error creating quick quiz:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при создании викторины. Попробуйте еще раз.');
    }
  }

  async processDetailedQuiz(bot, msg, user, quizType) {
    const text = msg.text;
    
    const topic = this.extractInfo(text, ['тема', 'topic']) || 'Общая тема';
    const level = this.extractLevel(text) || 'B1';
    const count = this.extractNumber(text) || 5;

    if (count > 20) {
      await bot.sendMessage(msg.chat.id, '❌ Максимальное количество вопросов: 20');
      return;
    }

    await bot.sendMessage(msg.chat.id, '⏳ Создаю викторину...');

    try {
      const quiz = await gptService.createQuiz(topic, level, count, quizType);
      await this.sendQuiz(bot, msg.chat.id, quiz, { topic, level, count, type: quizType });
      
      // Save to database
      await this.saveQuiz(user.id, { topic, level, count, type: quizType }, quiz);
      
      await sessionOperations.clearSession(user.id);
    } catch (error) {
      logger.error('Error creating detailed quiz:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при создании викторины. Попробуйте еще раз.');
    }
  }

  extractInfo(text, keywords) {
    for (const keyword of keywords) {
      const regex = new RegExp(`${keyword}:?\\s*(.+?)(?=\\n|$|[а-яё]+:|[a-z]+:|количество|уровень)`, 'gi');
      const match = text.match(regex);
      if (match && match[0]) {
        return match[0].replace(new RegExp(`${keyword}:?\\s*`, 'i'), '').trim();
      }
    }
    return null;
  }

  extractLevel(text) {
    const levelMatch = text.match(/\b([A-C][1-2])\b/i);
    return levelMatch ? levelMatch[1].toUpperCase() : null;
  }

  extractNumber(text) {
    const numberMatch = text.match(/количество:?\s*(\d+)|(\d+)\s*вопрос/i);
    if (numberMatch) {
      return parseInt(numberMatch[1] || numberMatch[2]);
    }
    
    const simpleNumberMatch = text.match(/\b(\d+)\b/);
    return simpleNumberMatch ? parseInt(simpleNumberMatch[1]) : null;
  }

  async sendQuiz(bot, chatId, quiz, params) {
    const maxLength = 4000;
    
    let header = `🧩 *Викторина создана!*\n\n`;
    header += `📚 *Тема:* ${params.topic}\n`;
    header += `🎯 *Уровень:* ${params.level}\n`;
    header += `🔢 *Вопросов:* ${params.count}\n`;
    if (params.type) {
      header += `📝 *Тип:* ${params.type}\n`;
    }
    header += `\n─────────────────\n\n`;

    const fullMessage = header + quiz;

    if (fullMessage.length <= maxLength) {
      await bot.sendMessage(chatId, fullMessage, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📥 Сохранить', callback_data: 'quiz_save' },
              { text: '📤 Поделиться', callback_data: 'quiz_share' }
            ],
            [
              { text: '🔄 Создать новую', callback_data: 'quiz_new' },
              { text: '📊 Создать ответы', callback_data: 'quiz_answers' }
            ]
          ]
        }
      });
    } else {
      // Send header
      await bot.sendMessage(chatId, header, { parse_mode: 'Markdown' });
      
      // Split and send quiz content
      const chunks = this.splitText(quiz, maxLength - 100);
      for (let i = 0; i < chunks.length; i++) {
        const isLast = i === chunks.length - 1;
        await bot.sendMessage(chatId, chunks[i], {
          parse_mode: 'Markdown',
          reply_markup: isLast ? {
            inline_keyboard: [
              [
                { text: '📥 Сохранить', callback_data: 'quiz_save' },
                { text: '📤 Поделиться', callback_data: 'quiz_share' }
              ],
              [
                { text: '🔄 Создать новую', callback_data: 'quiz_new' },
                { text: '📊 Создать ответы', callback_data: 'quiz_answers' }
              ]
            ]
          } : undefined
        });
      }
    }

    // Offer to create vocabulary exercise
    setTimeout(async () => {
      await bot.sendMessage(chatId, 
        '💡 *Дополнительно можно создать:*\n• Словарные упражнения\n• Диалоги по теме\n• Грамматические упражнения', 
        {
          parse_mode: 'Markdown',
          reply_markup: {
            inline_keyboard: [
              [
                { text: '📝 Словарь', callback_data: 'create_vocabulary' },
                { text: '💬 Диалог', callback_data: 'create_dialogue' }
              ]
            ]
          }
        }
      );
    }, 2000);
  }

  splitText(text, maxLength) {
    const chunks = [];
    let current = '';
    
    const lines = text.split('\n');
    for (const line of lines) {
      if ((current + line + '\n').length > maxLength && current) {
        chunks.push(current.trim());
        current = line + '\n';
      } else {
        current += line + '\n';
      }
    }
    
    if (current) {
      chunks.push(current.trim());
    }
    
    return chunks;
  }

  async saveQuiz(userId, params, content) {
    const db = require('../models/database').getDatabase();
    
    return new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO quizzes (user_id, title, questions, topic, difficulty) 
         VALUES (?, ?, ?, ?, ?)`,
        [
          userId,
          `${params.topic} - ${params.type || 'Викторина'}`,
          content,
          params.topic,
          params.level
        ],
        function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        }
      );
    });
  }
}

const quizHandler = new QuizHandler();
module.exports = { quizHandler };