const { gptService } = require('../services/gptService');
const { userOperations, sessionOperations } = require('../models/database');
const { logger } = require('../utils/logger');

class LessonPlanHandler {
  async handle(bot, msg) {
    try {
      const user = await userOperations.findOrCreate(msg.from);
      
      // Show lesson plan creation options
      const keyboard = {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '⚡ Быстрый план', callback_data: 'lesson_quick' },
              { text: '🎯 Детальный план', callback_data: 'lesson_detailed' }
            ],
            [
              { text: '📋 Шаблоны планов', callback_data: 'lesson_templates' }
            ]
          ]
        }
      };

      await bot.sendMessage(msg.chat.id, 
        `📚 *Создание плана урока*

Выберите тип плана:
⚡ *Быстрый план* - укажите только тему и уровень
🎯 *Детальный план* - полная настройка урока
📋 *Шаблоны* - готовые шаблоны планов`, 
        { 
          parse_mode: 'Markdown',
          ...keyboard 
        }
      );
      
    } catch (error) {
      logger.error('Error in lesson plan handler:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при создании плана урока');
    }
  }

  async handleCallback(bot, msg, data) {
    try {
      const user = await userOperations.findOrCreate({ id: msg.chat.id });
      
      switch (data) {
        case 'lesson_quick':
          await this.startQuickPlan(bot, msg, user);
          break;
        case 'lesson_detailed':
          await this.startDetailedPlan(bot, msg, user);
          break;
        case 'lesson_templates':
          await this.showTemplates(bot, msg, user);
          break;
        default:
          if (data.startsWith('template_')) {
            await this.useTemplate(bot, msg, user, data.replace('template_', ''));
          }
      }
    } catch (error) {
      logger.error('Error in lesson plan callback:', error);
    }
  }

  async startQuickPlan(bot, msg, user) {
    await bot.editMessageText(
      `⚡ *Быстрый план урока*

Напишите тему урока и уровень учеников в формате:
\`Тема: [ваша тема]
Уровень: [A1/A2/B1/B2/C1/C2]\`

Например:
\`Тема: Прошедшее время (Past Simple)
Уровень: A2\``,
      {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: 'Markdown'
      }
    );

    await sessionOperations.setSession(user.id, {
      waitingFor: 'lesson_quick_details',
      flow: 'lesson_plan'
    });
  }

  async startDetailedPlan(bot, msg, user) {
    await bot.editMessageText(
      `🎯 *Детальный план урока*

Пожалуйста, укажите следующую информацию:

📝 *Тема урока:*
🎯 *Уровень учеников:* (A1/A2/B1/B2/C1/C2)
⏰ *Продолжительность:* (в минутах)
👥 *Возраст учеников:*
🎪 *Цели урока:*
📌 *Дополнительная информация:* (опционально)

Напишите всё в свободной форме.`,
      {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: 'Markdown'
      }
    );

    await sessionOperations.setSession(user.id, {
      waitingFor: 'lesson_detailed_info',
      flow: 'lesson_plan'
    });
  }

  async showTemplates(bot, msg, user) {
    const templatesKeyboard = {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '📖 Грамматика', callback_data: 'template_grammar' },
            { text: '💬 Разговорная речь', callback_data: 'template_speaking' }
          ],
          [
            { text: '📚 Чтение', callback_data: 'template_reading' },
            { text: '✍️ Письмо', callback_data: 'template_writing' }
          ],
          [
            { text: '🎵 Аудирование', callback_data: 'template_listening' },
            { text: '📝 Лексика', callback_data: 'template_vocabulary' }
          ],
          [
            { text: '⬅️ Назад', callback_data: 'lesson_back' }
          ]
        ]
      }
    };

    await bot.editMessageText(
      `📋 *Шаблоны планов уроков*

Выберите тип урока для получения готового шаблона:`,
      {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: 'Markdown',
        ...templatesKeyboard
      }
    );
  }

  async useTemplate(bot, msg, user, templateType) {
    const templates = {
      grammar: {
        topic: 'Грамматическая структура',
        level: 'B1',
        duration: '45',
        students_age: '12-15 лет',
        goals: 'Изучить новую грамматическую структуру, научиться использовать её в речи',
        additional_info: 'Урок с акцентом на практическое применение грамматики'
      },
      speaking: {
        topic: 'Развитие разговорных навыков',
        level: 'B1',
        duration: '45',
        students_age: '14-17 лет',
        goals: 'Развить навыки спонтанной речи, увеличить словарный запас',
        additional_info: 'Интерактивный урок с ролевыми играми и дискуссиями'
      },
      reading: {
        topic: 'Развитие навыков чтения',
        level: 'A2',
        duration: '45',
        students_age: '10-13 лет',
        goals: 'Улучшить понимание прочитанного, изучить новую лексику',
        additional_info: 'Работа с адаптированным текстом'
      },
      writing: {
        topic: 'Развитие письменной речи',
        level: 'B2',
        duration: '45',
        students_age: '15-18 лет',
        goals: 'Научиться писать структурированные тексты, использовать связующие слова',
        additional_info: 'Написание эссе и личных писем'
      },
      listening: {
        topic: 'Развитие навыков аудирования',
        level: 'A2',
        duration: '45',
        students_age: '12-15 лет',
        goals: 'Улучшить понимание английской речи на слух',
        additional_info: 'Использование аудио и видео материалов'
      },
      vocabulary: {
        topic: 'Изучение новой лексики',
        level: 'A1',
        duration: '45',
        students_age: '8-12 лет',
        goals: 'Изучить новые слова по теме, научиться использовать их в контексте',
        additional_info: 'Игровой формат изучения лексики'
      }
    };

    const template = templates[templateType];
    if (!template) {
      await bot.answerCallbackQuery(msg.callback_query?.id, 'Шаблон не найден');
      return;
    }

    await bot.editMessageText('⏳ Создаю план урока на основе шаблона...', {
      chat_id: msg.chat.id,
      message_id: msg.message_id
    });

    try {
      const lessonPlan = await gptService.createLessonPlan(template);
      await this.sendLessonPlan(bot, msg.chat.id, lessonPlan, template);
    } catch (error) {
      logger.error('Error creating template lesson plan:', error);
      await bot.editMessageText('❌ Ошибка при создании плана урока', {
        chat_id: msg.chat.id,
        message_id: msg.message_id
      });
    }
  }

  async handleDetails(bot, msg, user) {
    try {
      const session = await sessionOperations.getSession(user.id);
      
      if (session?.waitingFor === 'lesson_quick_details') {
        await this.processQuickPlan(bot, msg, user);
      } else if (session?.waitingFor === 'lesson_detailed_info') {
        await this.processDetailedPlan(bot, msg, user);
      }
    } catch (error) {
      logger.error('Error handling lesson details:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при обработке деталей урока');
    }
  }

  async processQuickPlan(bot, msg, user) {
    const text = msg.text;
    const topicMatch = text.match(/тема:\s*(.+)/i);
    const levelMatch = text.match(/уровень:\s*([A-C][1-2])/i);

    if (!topicMatch || !levelMatch) {
      await bot.sendMessage(msg.chat.id, 
        `❌ Пожалуйста, укажите тему и уровень в правильном формате:
        
\`Тема: [ваша тема]
Уровень: [A1/A2/B1/B2/C1/C2]\``);
      return;
    }

    const requirements = {
      topic: topicMatch[1].trim(),
      level: levelMatch[1].toUpperCase(),
      duration: '45',
      students_age: '12-15 лет',
      goals: 'Изучить новую тему, закрепить знания на практике',
      additional_info: ''
    };

    await this.createAndSendPlan(bot, msg, user, requirements);
  }

  async processDetailedPlan(bot, msg, user) {
    const text = msg.text;
    
    // Extract information using simple parsing
    const requirements = {
      topic: this.extractInfo(text, ['тема', 'topic']) || 'Не указана',
      level: this.extractLevel(text) || 'B1',
      duration: this.extractInfo(text, ['продолжительность', 'время', 'duration']) || '45',
      students_age: this.extractInfo(text, ['возраст', 'age']) || '12-15 лет',
      goals: this.extractInfo(text, ['цели', 'цель', 'goals', 'goal']) || 'Изучить новую тему',
      additional_info: this.extractInfo(text, ['дополнительно', 'дополнительная информация', 'заметки']) || ''
    };

    await this.createAndSendPlan(bot, msg, user, requirements);
  }

  extractInfo(text, keywords) {
    for (const keyword of keywords) {
      const regex = new RegExp(`${keyword}:?\\s*(.+?)(?=\\n|$|[а-яё]+:|[a-z]+:)`, 'gi');
      const match = text.match(regex);
      if (match && match[0]) {
        return match[0].replace(new RegExp(`${keyword}:?\\s*`, 'i'), '').trim();
      }
    }
    return null;
  }

  extractLevel(text) {
    const levelMatch = text.match(/\b([A-C][1-2])\b/i);
    return levelMatch ? levelMatch[1].toUpperCase() : null;
  }

  async createAndSendPlan(bot, msg, user, requirements) {
    await bot.sendMessage(msg.chat.id, '⏳ Создаю план урока...');

    try {
      const lessonPlan = await gptService.createLessonPlan(requirements);
      await this.sendLessonPlan(bot, msg.chat.id, lessonPlan, requirements);
      
      // Save to database
      await this.saveLessonPlan(user.id, requirements, lessonPlan);
      
      // Clear session
      await sessionOperations.clearSession(user.id);
      
    } catch (error) {
      logger.error('Error creating lesson plan:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при создании плана урока. Попробуйте еще раз.');
    }
  }

  async sendLessonPlan(bot, chatId, lessonPlan, requirements) {
    // Split long messages if needed
    const maxLength = 4000;
    
    let header = `📚 *План урока*\n\n`;
    header += `📝 *Тема:* ${requirements.topic}\n`;
    header += `🎯 *Уровень:* ${requirements.level}\n`;
    header += `⏰ *Продолжительность:* ${requirements.duration} мин\n\n`;

    if ((header + lessonPlan).length <= maxLength) {
      await bot.sendMessage(chatId, header + lessonPlan, { 
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📥 Сохранить', callback_data: 'lesson_save' },
              { text: '📤 Поделиться', callback_data: 'lesson_share' }
            ],
            [
              { text: '🔄 Создать новый', callback_data: 'lesson_new' }
            ]
          ]
        }
      });
    } else {
      // Send header
      await bot.sendMessage(chatId, header, { parse_mode: 'Markdown' });
      
      // Split and send content
      const chunks = this.splitText(lessonPlan, maxLength - 100);
      for (let i = 0; i < chunks.length; i++) {
        const isLast = i === chunks.length - 1;
        await bot.sendMessage(chatId, chunks[i], {
          parse_mode: 'Markdown',
          reply_markup: isLast ? {
            inline_keyboard: [
              [
                { text: '📥 Сохранить', callback_data: 'lesson_save' },
                { text: '📤 Поделиться', callback_data: 'lesson_share' }
              ],
              [
                { text: '🔄 Создать новый', callback_data: 'lesson_new' }
              ]
            ]
          } : undefined
        });
      }
    }
  }

  splitText(text, maxLength) {
    const chunks = [];
    let current = '';
    
    const lines = text.split('\n');
    for (const line of lines) {
      if ((current + line + '\n').length > maxLength && current) {
        chunks.push(current.trim());
        current = line + '\n';
      } else {
        current += line + '\n';
      }
    }
    
    if (current) {
      chunks.push(current.trim());
    }
    
    return chunks;
  }

  async saveLessonPlan(userId, requirements, content) {
    const db = require('../models/database').getDatabase();
    
    return new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO lesson_plans (user_id, title, content, level, duration, topic) 
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          userId,
          requirements.topic,
          content,
          requirements.level,
          parseInt(requirements.duration),
          requirements.topic
        ],
        function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        }
      );
    });
  }
}

const lessonPlanHandler = new LessonPlanHandler();
module.exports = { lessonPlanHandler };