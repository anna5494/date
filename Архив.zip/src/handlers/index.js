const { userOperations, sessionOperations } = require('../models/database');
const { gptService } = require('../services/gptService');
const { lessonPlanHandler } = require('./lessonPlanHandler');
const { grammarHandler } = require('./grammarHandler');
const { quizHandler } = require('./quizHandler');
const { translationHandler } = require('./translationHandler');
const { logger } = require('../utils/logger');

const messages = {
  ru: {
    welcome: `🎉 Добро пожаловать в помощник учителя английского языка!

Я помогу вам:
📚 Создавать планы уроков
📝 Проверять грамматику
🧩 Генерировать викторины и упражнения
🔄 Переводить тексты
🔊 Объяснять произношение
📊 Отслеживать прогресс учеников

Используйте команды или просто пишите мне на русском языке!`,
    
    help: `❓ Доступные команды:

/lesson - 📚 Создать план урока
/grammar - 📝 Проверить грамматику
/quiz - 🧩 Создать викторину
/translate - 🔄 Перевести текст
/pronunciation - 🔊 Помощь с произношением
/progress - 📊 Посмотреть прогресс
/settings - ⚙️ Настройки

Также вы можете просто написать мне вопрос или текст для проверки!`,
    
    processing: '⏳ Обрабатываю ваш запрос...',
    error: '❌ Произошла ошибка. Попробуйте еще раз.',
    notUnderstood: '🤔 Не понял ваш запрос. Используйте /help для списка команд.'
  }
};

const setupHandlers = (bot) => {
  // Start command
  bot.onText(/\/start/, async (msg) => {
    try {
      const user = await userOperations.findOrCreate(msg.from);
      await bot.sendMessage(msg.chat.id, messages.ru.welcome, {
        reply_markup: {
          keyboard: [
            ['📚 План урока', '📝 Грамматика'],
            ['🧩 Викторина', '🔄 Перевод'],
            ['🔊 Произношение', '📊 Прогресс']
          ],
          resize_keyboard: true,
          one_time_keyboard: false
        }
      });
      
      logger.info(`User started bot: ${user.telegram_id}`);
    } catch (error) {
      logger.error('Error in start command:', error);
      await bot.sendMessage(msg.chat.id, messages.ru.error);
    }
  });

  // Help command
  bot.onText(/\/help/, async (msg) => {
    await bot.sendMessage(msg.chat.id, messages.ru.help);
  });

  // Lesson plan command
  bot.onText(/\/lesson|📚 План урока/, async (msg) => {
    await lessonPlanHandler.handle(bot, msg);
  });

  // Grammar check command
  bot.onText(/\/grammar|📝 Грамматика/, async (msg) => {
    await grammarHandler.handle(bot, msg);
  });

  // Quiz command
  bot.onText(/\/quiz|🧩 Викторина/, async (msg) => {
    await quizHandler.handle(bot, msg);
  });

  // Translation command
  bot.onText(/\/translate|🔄 Перевод/, async (msg) => {
    await translationHandler.handle(bot, msg);
  });

  // Pronunciation command
  bot.onText(/\/pronunciation|🔊 Произношение/, async (msg) => {
    await handlePronunciation(bot, msg);
  });

  // Progress command
  bot.onText(/\/progress|📊 Прогресс/, async (msg) => {
    await handleProgress(bot, msg);
  });

  // Settings command
  bot.onText(/\/settings/, async (msg) => {
    await handleSettings(bot, msg);
  });

  // Handle all other messages
  bot.on('message', async (msg) => {
    if (msg.text && !msg.text.startsWith('/') && !isKeyboardButton(msg.text)) {
      await handleFreeTextMessage(bot, msg);
    }
  });

  // Handle callback queries (inline keyboard responses)
  bot.on('callback_query', async (callbackQuery) => {
    await handleCallbackQuery(bot, callbackQuery);
  });
};

const isKeyboardButton = (text) => {
  const buttons = ['📚 План урока', '📝 Грамматика', '🧩 Викторина', '🔄 Перевод', '🔊 Произношение', '📊 Прогресс'];
  return buttons.includes(text);
};

const handleFreeTextMessage = async (bot, msg) => {
  try {
    await bot.sendMessage(msg.chat.id, messages.ru.processing);
    
    const user = await userOperations.findOrCreate(msg.from);
    const session = await sessionOperations.getSession(user.id);
    
    // Check if user is in a specific flow
    if (session && session.waitingFor) {
      switch (session.waitingFor) {
        case 'lesson_details':
          await lessonPlanHandler.handleDetails(bot, msg, user);
          break;
        case 'grammar_text':
          await grammarHandler.handleText(bot, msg, user);
          break;
        case 'quiz_topic':
          await quizHandler.handleTopic(bot, msg, user);
          break;
        case 'translation_text':
          await translationHandler.handleText(bot, msg, user);
          break;
        default:
          await handleGeneralQuery(bot, msg, user);
      }
    } else {
      await handleGeneralQuery(bot, msg, user);
    }
  } catch (error) {
    logger.error('Error handling free text message:', error);
    await bot.sendMessage(msg.chat.id, messages.ru.error);
  }
};

const handleGeneralQuery = async (bot, msg, user) => {
  try {
    const response = await gptService.processGeneralQuery(msg.text, user);
    await bot.sendMessage(msg.chat.id, response, { parse_mode: 'Markdown' });
  } catch (error) {
    logger.error('Error in general query:', error);
    await bot.sendMessage(msg.chat.id, messages.ru.notUnderstood);
  }
};

const handlePronunciation = async (bot, msg) => {
  await bot.sendMessage(msg.chat.id, 
    '🔊 Отправьте мне английское слово или фразу, и я объясню произношение с транскрипцией и советами.'
  );
  
  const user = await userOperations.findOrCreate(msg.from);
  await sessionOperations.setSession(user.id, { waitingFor: 'pronunciation_text' });
};

const handleProgress = async (bot, msg) => {
  try {
    const user = await userOperations.findOrCreate(msg.from);
    // Get user's activity statistics
    const stats = await getUserProgress(user.id);
    
    const progressMessage = `📊 Ваш прогресс:

📚 Планов уроков создано: ${stats.lessonPlans}
📝 Текстов проверено: ${stats.grammarChecks}
🧩 Викторин создано: ${stats.quizzes}
🔄 Переводов выполнено: ${stats.translations}

Продолжайте в том же духе! 🎉`;

    await bot.sendMessage(msg.chat.id, progressMessage);
  } catch (error) {
    logger.error('Error getting progress:', error);
    await bot.sendMessage(msg.chat.id, messages.ru.error);
  }
};

const handleSettings = async (bot, msg) => {
  const settingsKeyboard = {
    reply_markup: {
      inline_keyboard: [
        [{ text: '🌍 Язык интерфейса', callback_data: 'settings_language' }],
        [{ text: '🎯 Уровень по умолчанию', callback_data: 'settings_level' }],
        [{ text: '⚙️ Сбросить настройки', callback_data: 'settings_reset' }]
      ]
    }
  };

  await bot.sendMessage(msg.chat.id, '⚙️ Настройки бота:', settingsKeyboard);
};

const handleCallbackQuery = async (bot, callbackQuery) => {
  const data = callbackQuery.data;
  const msg = callbackQuery.message;
  
  try {
    await bot.answerCallbackQuery(callbackQuery.id);
    
    if (data.startsWith('settings_')) {
      await handleSettingsCallback(bot, msg, data);
    } else if (data.startsWith('lesson_')) {
      await lessonPlanHandler.handleCallback(bot, msg, data);
    } else if (data.startsWith('quiz_')) {
      await quizHandler.handleCallback(bot, msg, data);
    }
  } catch (error) {
    logger.error('Error handling callback query:', error);
  }
};

const handleSettingsCallback = async (bot, msg, data) => {
  switch (data) {
    case 'settings_language':
      await bot.editMessageText('🌍 Выберите язык интерфейса:', {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        reply_markup: {
          inline_keyboard: [
            [{ text: '🇷🇺 Русский', callback_data: 'lang_ru' }],
            [{ text: '🇺🇸 English', callback_data: 'lang_en' }],
            [{ text: '⬅️ Назад', callback_data: 'settings_back' }]
          ]
        }
      });
      break;
    case 'settings_level':
      await bot.editMessageText('🎯 Выберите уровень по умолчанию:', {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        reply_markup: {
          inline_keyboard: [
            [{ text: 'A1 Beginner', callback_data: 'level_a1' }],
            [{ text: 'A2 Elementary', callback_data: 'level_a2' }],
            [{ text: 'B1 Intermediate', callback_data: 'level_b1' }],
            [{ text: 'B2 Upper-Intermediate', callback_data: 'level_b2' }],
            [{ text: 'C1 Advanced', callback_data: 'level_c1' }],
            [{ text: '⬅️ Назад', callback_data: 'settings_back' }]
          ]
        }
      });
      break;
  }
};

const getUserProgress = async (userId) => {
  // This would typically query the database for user statistics
  return {
    lessonPlans: 0,
    grammarChecks: 0,
    quizzes: 0,
    translations: 0
  };
};

module.exports = {
  setupHandlers
};