const { gptService } = require('../services/gptService');
const { userOperations, sessionOperations } = require('../models/database');
const { logger } = require('../utils/logger');

class GrammarHandler {
  async handle(bot, msg) {
    try {
      const user = await userOperations.findOrCreate(msg.from);
      
      const instructionMessage = `📝 *Проверка грамматики*

Отправьте мне английский текст, и я:
✅ Найду и исправлю ошибки
📖 Объясню правила грамматики
💡 Дам советы по улучшению

Вы можете отправить:
• Предложение или абзац
• Эссе или письмо
• Упражнение для проверки

*Пример:*
\`I am go to school yesterday\``;

      await bot.sendMessage(msg.chat.id, instructionMessage, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📋 Примеры текстов', callback_data: 'grammar_examples' },
              { text: '📚 Правила грамматики', callback_data: 'grammar_rules' }
            ]
          ]
        }
      });

      // Set session to wait for grammar text
      await sessionOperations.setSession(user.id, {
        waitingFor: 'grammar_text',
        flow: 'grammar_check'
      });

    } catch (error) {
      logger.error('Error in grammar handler:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при запуске проверки грамматики');
    }
  }

  async handleText(bot, msg, user) {
    try {
      const text = msg.text.trim();
      
      if (text.length < 3) {
        await bot.sendMessage(msg.chat.id, '❌ Текст слишком короткий. Пожалуйста, отправьте хотя бы несколько слов.');
        return;
      }

      if (text.length > 2000) {
        await bot.sendMessage(msg.chat.id, '❌ Текст слишком длинный. Максимум 2000 символов.');
        return;
      }

      // Check if text is in English (basic check)
      if (!this.isEnglishText(text)) {
        await bot.sendMessage(msg.chat.id, 
          '🤔 Похоже, что текст не на английском языке. Пожалуйста, отправьте английский текст для проверки.');
        return;
      }

      await bot.sendMessage(msg.chat.id, '⏳ Проверяю грамматику...');

      const grammarCheck = await gptService.checkGrammar(text);
      await this.sendGrammarResult(bot, msg.chat.id, text, grammarCheck);
      
      // Save to database
      await this.saveGrammarCheck(user.id, text, grammarCheck);
      
      // Clear session
      await sessionOperations.clearSession(user.id);

      // Ask if user wants to check more text
      await bot.sendMessage(msg.chat.id, 
        '✨ Хотите проверить еще один текст? Просто отправьте его мне!', {
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📝 Проверить еще', callback_data: 'grammar_new' },
              { text: '📚 Изучить правила', callback_data: 'grammar_rules' }
            ]
          ]
        }
      });

    } catch (error) {
      logger.error('Error checking grammar:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при проверке грамматики. Попробуйте еще раз.');
    }
  }

  async handleCallback(bot, msg, data) {
    try {
      const user = await userOperations.findOrCreate({ id: msg.chat.id });
      
      switch (data) {
        case 'grammar_examples':
          await this.showExamples(bot, msg);
          break;
        case 'grammar_rules':
          await this.showGrammarRules(bot, msg);
          break;
        case 'grammar_new':
          await this.handle(bot, { chat: msg.chat, from: { id: msg.chat.id } });
          break;
        default:
          if (data.startsWith('rule_')) {
            await this.explainRule(bot, msg, data.replace('rule_', ''));
          }
      }
    } catch (error) {
      logger.error('Error in grammar callback:', error);
    }
  }

  isEnglishText(text) {
    // Basic check for English text
    const englishPattern = /^[a-zA-Z0-9\s.,!?'"();:-]+$/;
    const cyrillicPattern = /[а-яё]/i;
    
    // If contains Cyrillic, probably not English
    if (cyrillicPattern.test(text)) {
      return false;
    }
    
    // Check if majority of characters are English
    const englishChars = text.match(/[a-zA-Z]/g) || [];
    return englishChars.length > text.length * 0.7;
  }

  async sendGrammarResult(bot, chatId, originalText, result) {
    const maxLength = 4000;
    
    let message = `📝 *Результат проверки грамматики*\n\n`;
    message += `📋 *Исходный текст:*\n\`${originalText}\`\n\n`;
    message += `${result}`;

    if (message.length <= maxLength) {
      await bot.sendMessage(chatId, message, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📤 Поделиться', callback_data: 'grammar_share' },
              { text: '📚 Изучить правила', callback_data: 'grammar_rules' }
            ]
          ]
        }
      });
    } else {
      // Split message
      const headerMsg = `📝 *Результат проверки грамматики*\n\n📋 *Исходный текст:*\n\`${originalText}\``;
      await bot.sendMessage(chatId, headerMsg, { parse_mode: 'Markdown' });
      
      const chunks = this.splitText(result, maxLength - 100);
      for (let i = 0; i < chunks.length; i++) {
        const isLast = i === chunks.length - 1;
        await bot.sendMessage(chatId, chunks[i], {
          parse_mode: 'Markdown',
          reply_markup: isLast ? {
            inline_keyboard: [
              [
                { text: '📤 Поделиться', callback_data: 'grammar_share' },
                { text: '📚 Изучить правила', callback_data: 'grammar_rules' }
              ]
            ]
          } : undefined
        });
      }
    }
  }

  async showExamples(bot, msg) {
    const examples = `📋 *Примеры текстов для проверки:*

*Простые предложения:*
• \`I go to school yesterday\`
• \`She don't like coffee\`
• \`They was happy\`

*Средний уровень:*
• \`I have been living in Moscow since 5 years\`
• \`If I would have money, I will buy a car\`

*Сложные конструкции:*
• \`Despite of being tired, he continued working\`
• \`The book what I read was interesting\`

Выберите любой пример или отправьте свой текст!`;

    await bot.editMessageText(examples, {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '⬅️ Назад', callback_data: 'grammar_back' }]
        ]
      }
    });
  }

  async showGrammarRules(bot, msg) {
    const rulesKeyboard = {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '⏰ Времена', callback_data: 'rule_tenses' },
            { text: '📄 Артикли', callback_data: 'rule_articles' }
          ],
          [
            { text: '🔗 Предлоги', callback_data: 'rule_prepositions' },
            { text: '🔄 Порядок слов', callback_data: 'rule_word_order' }
          ],
          [
            { text: '🎭 Условные предложения', callback_data: 'rule_conditionals' },
            { text: '📢 Пассивный залог', callback_data: 'rule_passive' }
          ],
          [
            { text: '⬅️ Назад', callback_data: 'grammar_back' }
          ]
        ]
      }
    };

    await bot.editMessageText(
      `📚 *Основные правила английской грамматики*

Выберите раздел для изучения:`,
      {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: 'Markdown',
        ...rulesKeyboard
      }
    );
  }

  async explainRule(bot, msg, ruleType) {
    const rules = {
      tenses: `⏰ *Времена в английском языке*

*Настоящее время:*
• Present Simple: I work (регулярные действия)
• Present Continuous: I am working (происходит сейчас)
• Present Perfect: I have worked (результат в настоящем)

*Прошедшее время:*
• Past Simple: I worked (законченное действие)
• Past Continuous: I was working (процесс в прошлом)
• Past Perfect: I had worked (действие до другого в прошлом)

*Будущее время:*
• Future Simple: I will work
• Future Continuous: I will be working
• Future Perfect: I will have worked`,

      articles: `📄 *Артикли в английском языке*

*A/An (неопределенный артикль):*
• Используется с исчисляемыми существительными в единственном числе
• A cat, an apple, a university

*The (определенный артикль):*
• Конкретный предмет: The book on the table
• Уникальные предметы: The sun, the moon
• Превосходная степень: The best student

*Без артикля:*
• Множественное число: Cats are animals
• Неисчисляемые: Water is important
• Имена собственные: Moscow, John`,

      prepositions: `🔗 *Предлоги в английском языке*

*Предлоги времени:*
• At: at 5 o'clock, at night
• In: in the morning, in January
• On: on Monday, on Christmas Day

*Предлоги места:*
• At: at home, at school
• In: in the room, in Moscow
• On: on the table, on the street

*Предлоги направления:*
• To: go to school
• Into: go into the room
• From: come from work`,

      word_order: `🔄 *Порядок слов в английском языке*

*Утвердительное предложение:*
Подлежащее + Сказуемое + Дополнение
I read books

*Вопросительное предложение:*
Вспомогательный глагол + Подлежащее + Основной глагол
Do you read books?

*Отрицательное предложение:*
Подлежащее + Вспомогательный глагол + not + Основной глагол
I do not read books`,

      conditionals: `🎭 *Условные предложения*

*First Conditional (реальное условие):*
If + Present Simple, will + Infinitive
If it rains, I will stay home

*Second Conditional (нереальное условие):*
If + Past Simple, would + Infinitive
If I had money, I would buy a car

*Third Conditional (нереальное условие в прошлом):*
If + Past Perfect, would have + Past Participle
If I had studied, I would have passed`,

      passive: `📢 *Пассивный залог*

*Образование:*
be + Past Participle

*Примеры:*
• Present: The letter is written
• Past: The letter was written
• Future: The letter will be written
• Present Perfect: The letter has been written

*Использование:*
• Когда неважно, кто выполняет действие
• Когда исполнитель неизвестен
• В формальном стиле`
    };

    const ruleText = rules[ruleType] || 'Правило не найдено';

    await bot.editMessageText(ruleText, {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: '⬅️ К правилам', callback_data: 'grammar_rules' }]
        ]
      }
    });
  }

  splitText(text, maxLength) {
    const chunks = [];
    let current = '';
    
    const lines = text.split('\n');
    for (const line of lines) {
      if ((current + line + '\n').length > maxLength && current) {
        chunks.push(current.trim());
        current = line + '\n';
      } else {
        current += line + '\n';
      }
    }
    
    if (current) {
      chunks.push(current.trim());
    }
    
    return chunks;
  }

  async saveGrammarCheck(userId, originalText, result) {
    const db = require('../models/database').getDatabase();
    
    return new Promise((resolve, reject) => {
      db.run(
        `INSERT INTO grammar_checks (user_id, original_text, corrected_text, explanation) 
         VALUES (?, ?, ?, ?)`,
        [userId, originalText, '', result],
        function(err) {
          if (err) reject(err);
          else resolve(this.lastID);
        }
      );
    });
  }
}

const grammarHandler = new GrammarHandler();
module.exports = { grammarHandler };