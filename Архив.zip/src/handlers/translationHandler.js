const { gptService } = require('../services/gptService');
const { userOperations, sessionOperations } = require('../models/database');
const { logger } = require('../utils/logger');

class TranslationHandler {
  async handle(bot, msg) {
    try {
      const user = await userOperations.findOrCreate(msg.from);
      
      const instructionMessage = `🔄 *Перевод и произношение*

Выберите, что вы хотите сделать:`;

      await bot.sendMessage(msg.chat.id, instructionMessage, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '🇷🇺➡️🇺🇸 Русский → Английский', callback_data: 'translate_ru_en' },
              { text: '🇺🇸➡️🇷🇺 Английский → Русский', callback_data: 'translate_en_ru' }
            ],
            [
              { text: '🔊 Произношение', callback_data: 'pronunciation_help' },
              { text: '📚 Изучить фразы', callback_data: 'useful_phrases' }
            ]
          ]
        }
      });

    } catch (error) {
      logger.error('Error in translation handler:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при запуске переводчика');
    }
  }

  async handleCallback(bot, msg, data) {
    try {
      const user = await userOperations.findOrCreate({ id: msg.chat.id });
      
      switch (data) {
        case 'translate_ru_en':
          await this.startTranslation(bot, msg, user, 'ru-en');
          break;
        case 'translate_en_ru':
          await this.startTranslation(bot, msg, user, 'en-ru');
          break;
        case 'pronunciation_help':
          await this.startPronunciation(bot, msg, user);
          break;
        case 'useful_phrases':
          await this.showUsefulPhrases(bot, msg, user);
          break;
      }
    } catch (error) {
      logger.error('Error in translation callback:', error);
    }
  }

  async startTranslation(bot, msg, user, direction) {
    const directions = {
      'ru-en': {
        title: 'Русский → Английский',
        instruction: 'Введите русский текст для перевода на английский:',
        example: 'Пример: "Я изучаю английский язык"'
      },
      'en-ru': {
        title: 'Английский → Русский', 
        instruction: 'Введите английский текст для перевода на русский:',
        example: 'Example: "I am learning English"'
      }
    };

    const directionInfo = directions[direction];

    await bot.editMessageText(
      `🔄 *${directionInfo.title}*

${directionInfo.instruction}

${directionInfo.example}

💡 Советы:
• Отправляйте предложения или короткие тексты
• Я объясню сложные фразы и идиомы
• Предложу альтернативные варианты перевода`,
      {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '⬅️ Назад', callback_data: 'translation_back' }]
          ]
        }
      }
    );

    await sessionOperations.setSession(user.id, {
      waitingFor: 'translation_text',
      flow: 'translation',
      direction: direction
    });
  }

  async startPronunciation(bot, msg, user) {
    await bot.editMessageText(
      `🔊 *Помощь с произношением*

Отправьте английское слово или фразу, и я объясню:
• 📝 Фонетическую транскрипцию
• 🗣️ Как произносить по-русски  
• 💡 Советы для запоминания
• ⚠️ Частые ошибки

*Примеры:*
• \`thought\`
• \`comfortable\`
• \`What time is it?\``,
      {
        chat_id: msg.chat.id,
        message_id: msg.message_id,
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [{ text: '⬅️ Назад', callback_data: 'translation_back' }]
          ]
        }
      }
    );

    await sessionOperations.setSession(user.id, {
      waitingFor: 'pronunciation_text',
      flow: 'pronunciation'
    });
  }

  async showUsefulPhrases(bot, msg, user) {
    const phrases = `📚 *Полезные фразы для учителя*

*В классе:*
• \`Let's start the lesson\` - Давайте начнем урок
• \`Open your books\` - Откройте учебники  
• \`Pay attention\` - Обратите внимание
• \`Any questions?\` - Есть вопросы?

*Объяснения:*
• \`For example\` - Например
• \`In other words\` - Другими словами
• \`Let me explain\` - Позвольте объяснить
• \`Do you understand?\` - Понятно?

*Поощрение:*
• \`Well done!\` - Отлично!
• \`Good job!\` - Хорошая работа!
• \`Keep it up!\` - Так держать!
• \`You're making progress\` - Вы делаете успехи

*Исправления:*
• \`Not quite\` - Не совсем
• \`Try again\` - Попробуйте еще раз
• \`Almost correct\` - Почти правильно
• \`Let me help you\` - Позвольте помочь`;

    await bot.editMessageText(phrases, {
      chat_id: msg.chat.id,
      message_id: msg.message_id,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [
            { text: '🔊 Произношение фраз', callback_data: 'phrases_pronunciation' },
            { text: '⬅️ Назад', callback_data: 'translation_back' }
          ]
        ]
      }
    });
  }

  async handleText(bot, msg, user) {
    try {
      const session = await sessionOperations.getSession(user.id);
      
      if (!session) {
        await bot.sendMessage(msg.chat.id, '❌ Сессия истекла. Начните заново.');
        return;
      }

      const text = msg.text.trim();

      if (text.length < 1) {
        await bot.sendMessage(msg.chat.id, '❌ Пожалуйста, введите текст для обработки.');
        return;
      }

      if (text.length > 500) {
        await bot.sendMessage(msg.chat.id, '❌ Текст слишком длинный. Максимум 500 символов.');
        return;
      }

      if (session.waitingFor === 'translation_text') {
        await this.processTranslation(bot, msg, user, text, session.direction);
      } else if (session.waitingFor === 'pronunciation_text') {
        await this.processPronunciation(bot, msg, user, text);
      }

    } catch (error) {
      logger.error('Error handling translation text:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при обработке текста. Попробуйте еще раз.');
    }
  }

  async processTranslation(bot, msg, user, text, direction) {
    await bot.sendMessage(msg.chat.id, '⏳ Перевожу текст...');

    try {
      const translation = await gptService.translateText(text, direction);
      await this.sendTranslationResult(bot, msg.chat.id, text, translation, direction);
      
      await sessionOperations.clearSession(user.id);

      // Offer additional options
      setTimeout(async () => {
        await bot.sendMessage(msg.chat.id, 
          '✨ Что еще хотите перевести?', {
          reply_markup: {
            inline_keyboard: [
              [
                { text: '🔄 Перевести еще', callback_data: 'translate_new' },
                { text: '🔊 Произношение', callback_data: 'pronunciation_help' }
              ]
            ]
          }
        });
      }, 1000);

    } catch (error) {
      logger.error('Error processing translation:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при переводе. Попробуйте еще раз.');
    }
  }

  async processPronunciation(bot, msg, user, text) {
    // Basic check for English text
    if (!/[a-zA-Z]/.test(text)) {
      await bot.sendMessage(msg.chat.id, '❌ Пожалуйста, введите английское слово или фразу.');
      return;
    }

    await bot.sendMessage(msg.chat.id, '⏳ Анализирую произношение...');

    try {
      const pronunciation = await gptService.explainPronunciation(text);
      await this.sendPronunciationResult(bot, msg.chat.id, text, pronunciation);
      
      await sessionOperations.clearSession(user.id);

      // Offer additional options
      setTimeout(async () => {
        await bot.sendMessage(msg.chat.id, 
          '🎯 Хотите изучить произношение других слов?', {
          reply_markup: {
            inline_keyboard: [
              [
                { text: '🔊 Еще слово', callback_data: 'pronunciation_help' },
                { text: '📚 Полезные фразы', callback_data: 'useful_phrases' }
              ]
            ]
          }
        });
      }, 1000);

    } catch (error) {
      logger.error('Error processing pronunciation:', error);
      await bot.sendMessage(msg.chat.id, '❌ Ошибка при анализе произношения. Попробуйте еще раз.');
    }
  }

  async sendTranslationResult(bot, chatId, originalText, translation, direction) {
    const directionEmoji = {
      'ru-en': '🇷🇺➡️🇺🇸',
      'en-ru': '🇺🇸➡️🇷🇺'
    };

    const maxLength = 4000;
    
    let message = `${directionEmoji[direction]} *Результат перевода*\n\n`;
    message += `📝 *Исходный текст:*\n\`${originalText}\`\n\n`;
    message += `${translation}`;

    if (message.length <= maxLength) {
      await bot.sendMessage(chatId, message, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📤 Поделиться', callback_data: 'translation_share' },
              { text: '🔊 Произношение', callback_data: 'pronunciation_help' }
            ]
          ]
        }
      });
    } else {
      // Split message
      const headerMsg = `${directionEmoji[direction]} *Результат перевода*\n\n📝 *Исходный текст:*\n\`${originalText}\``;
      await bot.sendMessage(chatId, headerMsg, { parse_mode: 'Markdown' });
      
      const chunks = this.splitText(translation, maxLength - 100);
      for (let i = 0; i < chunks.length; i++) {
        const isLast = i === chunks.length - 1;
        await bot.sendMessage(chatId, chunks[i], {
          parse_mode: 'Markdown',
          reply_markup: isLast ? {
            inline_keyboard: [
              [
                { text: '📤 Поделиться', callback_data: 'translation_share' },
                { text: '🔊 Произношение', callback_data: 'pronunciation_help' }
              ]
            ]
          } : undefined
        });
      }
    }
  }

  async sendPronunciationResult(bot, chatId, word, pronunciation) {
    const maxLength = 4000;
    
    let message = `🔊 *Произношение слова "${word}"*\n\n`;
    message += `${pronunciation}`;

    if (message.length <= maxLength) {
      await bot.sendMessage(chatId, message, {
        parse_mode: 'Markdown',
        reply_markup: {
          inline_keyboard: [
            [
              { text: '📤 Поделиться', callback_data: 'pronunciation_share' },
              { text: '🔄 Перевести', callback_data: 'translate_new' }
            ]
          ]
        }
      });
    } else {
      // Split message
      const headerMsg = `🔊 *Произношение слова "${word}"*`;
      await bot.sendMessage(chatId, headerMsg, { parse_mode: 'Markdown' });
      
      const chunks = this.splitText(pronunciation, maxLength - 100);
      for (let i = 0; i < chunks.length; i++) {
        const isLast = i === chunks.length - 1;
        await bot.sendMessage(chatId, chunks[i], {
          parse_mode: 'Markdown',
          reply_markup: isLast ? {
            inline_keyboard: [
              [
                { text: '📤 Поделиться', callback_data: 'pronunciation_share' },
                { text: '🔄 Перевести', callback_data: 'translate_new' }
              ]
            ]
          } : undefined
        });
      }
    }
  }

  splitText(text, maxLength) {
    const chunks = [];
    let current = '';
    
    const lines = text.split('\n');
    for (const line of lines) {
      if ((current + line + '\n').length > maxLength && current) {
        chunks.push(current.trim());
        current = line + '\n';
      } else {
        current += line + '\n';
      }
    }
    
    if (current) {
      chunks.push(current.trim());
    }
    
    return chunks;
  }
}

const translationHandler = new TranslationHandler();
module.exports = { translationHandler };