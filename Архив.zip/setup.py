from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="english-teacher-telegram-bot",
    version="2.0.0",
    author="English Teacher Bot Team",
    author_email="info@englishteacherbot.ru",
    description="Telegram бот для учителей английского языка в России с интеграцией GPT",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/username/english-teacher-telegram-bot",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Education",
        "Topic :: Education :: Testing",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
    ],
    python_requires=">=3.8",
    install_requires=requirements,
    entry_points={
        "console_scripts": [
            "english-teacher-bot=bot.main:main",
        ],
    },
)